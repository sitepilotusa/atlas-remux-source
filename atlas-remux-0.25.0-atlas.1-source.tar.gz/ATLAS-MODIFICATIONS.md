# Atlas modifications to Remux

Date: 2026-08-28

Atlas patches Remux v0.25.0 to enforce tenant ownership in a shared Remux process.
The patch records catalog/add-on provenance, scopes media reads and stream selection
to the authenticated user's explicit add-on assignment, requires authentication for
image, subtitle, and static playback routes, rejects URL-valued image tags, namespaces
the complete Stremio media/relation tree by add-on, binds playback-session IDs and
device capabilities to the authenticated user and device, and removes provider URLs,
headers, local paths, and access tokens from client DTOs.

Pathless V2 replaces supplied source, add-on, playback, relay, and media URLs with
fixed compiled backchannels. Non-secret source and extension markers are recognized
before ordinary URL normalization. Remux sends independently signed, bounded POSTs to
the fixed API source/media routes or fixed Worker extension/target routes, verifies the
raw signed responses, rejects redirects, and redacts URL, PoP, target-reference, and
response-body details. The extension response validator accepts only the closed
manifest/catalog/meta/stream/subtitle shapes and launch media types `movie | series`.
It rejects raw URLs, external URLs, info-hashes, arbitrary headers, proxy controls,
unknown keys, invalid target refs, and all explicit nulls except the contract's image
and target-format exceptions.

Opaque uploaded-media and extension target state is consumed into private database and
stream descriptors and is skipped by ordinary serialization and debug formatting.
After an owner check, Remux redeems the descriptor, validates the signed terminal URL,
and emits an empty temporary redirect. It never fetches, proxies, or transcodes provider
media in Atlas mode. Uploaded-media locations are restricted to the configured R2
origin, canonical object path, exact SigV4 query, original method and Range, and
90-second expiry. Provider locations require public HTTPS and cannot point to Atlas,
Flycast, R2, local, or internal origins. Indexed artwork retains only its matching body
target. Stale stream rows are replaced and each media item is capped at 1,024 streams
beneath the existing bounded Pathless response size.

Pathless requests use a fixed Remux user agent and request identity transfer encoding
so Cloudflare cannot transform a body whose exact bytes are covered by the response
signature. Stream presentation fields preserve an extension's bounded multi-line
formatter output (at most 16 lines) while rejecting every other control character,
bidirectional override/isolate character, raw URL, and oversized value.

Extension streams also carry one exact typed `AtlasStreamFacts` v1 sibling.
The extension relay alone synthesizes it from selected structured leaves and
bounded formatter output; Remux denies unknown or null fields, validates the
closed vocabulary and safety bounds, performs no provider-text interpretation,
and emits the public PascalCase object only when the independent cloud-only
`atlas_stream_facts_v1` flag is enabled. Direct Remux never advertises that
capability. Per-addon stream resolution now keeps succeeded-empty, succeeded
with rows, and failed outcomes distinct: mixed success survives, while only an
all-failed applicable set returns an error.

Atlas mode also adds authenticated `GET /Items/External/PlaybackInfo` for stream-only
extensions. It accepts only exact IMDb/TMDB/TVDB identity, plus bounded season and
episode coordinates when applicable; title/year lookup and provider URLs are absent.
The handler materializes deterministic hidden lookup rows, grants ownership only
through the user's currently assigned enabled stream add-ons, and returns the resolved
item UUID as `AtlasItemId` with the ordinary sanitized PlaybackInfo response. A
per-user sentinel catalog keeps these lookup-only rows out of normal library listings
without introducing a second ownership or stream cache.

The patch also adds one exact Fly-private control POST at
`/api/atlas/v2/control/reconcile`. The gateway authenticates with Remux's normal
administrator session extractor. The handler bounded-parses a closed 15-action union,
validates the canonical private-command digest, executes the other 14 commands
transactionally, enforces cardinality and readback equality, and journals
`(operationId, action, digest)` so a retry returns the original redacted result while a
conflicting command fails closed. The public lease `attemptId` is intentionally absent
from those commands, their digest, and journal so a replacement lease preserves the
same mutation identity. The read-only `probe_addon` exception copies its signed
operation and current attempt into one fixed extension manifest request after
exact persisted add-on ownership readback. It performs no mutation, database
transaction, reload, or journal write and returns only the normalized health boolean.
Only `create_user` briefly holds a credential; secret buffers are zeroized and no
credential appears in the journal or response. The former underscore-prefixed control
routes and legacy credential header are retired globally with identical empty `404`
responses.

Extension-marker create/update activation uses only the exact persisted marker and
the authorized closed resource/type arrays. It bypasses manifest `available_info`
before any Worker/provider request can start, emits no fallback warning or add-on/
provider identifier log, and does not add a reload/attempt wire field or alter digest
or journal identity. Exact marker equality remains mandatory for an existing row;
delete/get absence is idempotent only after that exact old-generation row is gone.
The add-on display name is the compatibility-sanitized manifest name authorized by
Atlas Cloud. Remux accepts bounded Unicode presentation text while rejecting leading
or trailing whitespace, control and bidi characters, URLs, and token-shaped values;
internal extension keys remain marker-only state and are never used as display text.

Atlas mode suppresses RemuxDB and segment-provider background probes, binds item detail
state to the authenticated user, and suppresses tenant/provider details from logs.

The patch adds one Fly-private, administrator-authenticated device-session POST at
`/api/atlas/v1/native/device-session`. Its closed actions issue, retrieve, or revoke
one deterministic `atlas-native-<device UUID>` row for one non-admin Atlas tenant.
Tenant validation and session readback select only the fields required to validate and
return that private session, avoiding unrelated user settings, device telemetry, and
optional DTO columns.
The command envelope uses canonical re-serialization for closed-field enforcement;
it does not combine Serde's unsupported outer `deny_unknown_fields` and flattened
tagged-command representation. Round-trip coverage includes issue, retrieve, and
revoke.
Only the gateway receives the Remux access token; the native client receives a
separate hash-bound Atlas gateway token. Public password authentication is not part
of this channel. First-party Atlas Cloud movie, series, and episode DTOs expose only
one bounded `ProviderIds.AtlasSourceRef` value (`atlas:<UUID>`) so the native app can
join a Remux item back to Atlas Cloud. Seasons and extension-provided items never
receive that field, and ordinary provider IDs remain independent.

Upstream release: `v0.25.0`, release commit
`83bcbd98d956347c2efec63d4c7a744f87696ba9`. The upstream OCI image was built from
its functionally identical parent `1949908d1dc4f506e5d4af89da2206bbf59d1714` and is
pinned by digest in `image-lock.json`.

The complete modified source, build instructions, and GNU AGPL v3 license must be
offered at the URL recorded in the final image's `org.opencontainers.image.source`
label. Atlas has not changed Remux's license or warranty terms.
