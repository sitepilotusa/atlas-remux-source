# Atlas modifications to Remux

Date: 2026-08-21

Atlas patches Remux v0.25.0 to enforce tenant ownership in a shared Remux process.
The patch records catalog/add-on provenance, scopes media reads and stream selection
to the authenticated user's explicit add-on assignment, requires authentication for
image, subtitle, and static playback routes, rejects URL-valued image tags, namespaces
the complete Stremio media/relation tree by add-on, binds playback-session IDs and
device capabilities to the authenticated user and device, and removes provider URLs,
headers, local paths, and access tokens from client DTOs.

Pathless V2 replaces supplied source, add-on, playback, relay, and media URLs with
fixed compiled backchannels. Non-secret source and extension markers are recognized
before ordinary URL normalization. Remux sends independently signed, bounded POSTs to
the fixed API source/media routes or fixed Worker extension/target routes, verifies the
raw signed responses, rejects redirects, and redacts URL, PoP, target-reference, and
response-body details. The extension response validator accepts only the closed
manifest/catalog/meta/stream/subtitle shapes and launch media types `movie | series`.
It rejects raw URLs, external URLs, info-hashes, arbitrary headers, proxy controls,
unknown keys, invalid target refs, and all explicit nulls except the contract's image
and target-format exceptions.

Opaque uploaded-media and extension target state is consumed into private database and
stream descriptors and is skipped by ordinary serialization and debug formatting.
After an owner check, Remux redeems the descriptor, validates the signed terminal URL,
and emits an empty temporary redirect. It never fetches, proxies, or transcodes provider
media in Atlas mode. Uploaded-media locations are restricted to the configured R2
origin, canonical object path, exact SigV4 query, original method and Range, and
90-second expiry. Provider locations require public HTTPS and cannot point to Atlas,
Flycast, R2, local, or internal origins. Indexed artwork retains only its matching body
target. Stale stream rows are replaced and each media item is capped at 64 streams.

The patch also adds one exact Fly-private control POST at
`/api/atlas/v2/control/reconcile`. The gateway authenticates with Remux's normal
administrator session extractor. The handler bounded-parses a closed 15-action union,
validates the canonical private-command digest, executes the other 14 commands
transactionally, enforces cardinality and readback equality, and journals
`(operationId, action, digest)` so a retry returns the original redacted result while a
conflicting command fails closed. The public lease `attemptId` is intentionally absent
from those commands, their digest, and journal so a replacement lease preserves the
same mutation identity. The read-only `probe_addon` exception copies its signed
operation and current attempt into one fixed extension manifest request after
exact persisted add-on ownership readback. It performs no mutation, database
transaction, reload, or journal write and returns only the normalized health boolean.
Only `create_user` briefly holds a credential; secret buffers are zeroized and no
credential appears in the journal or response. The former underscore-prefixed control
routes and legacy credential header are retired globally with identical empty `404`
responses.

Extension-marker create/update activation uses only the exact persisted marker and
the authorized closed resource/type arrays. It bypasses manifest `available_info`
before any Worker/provider request can start, emits no fallback warning or add-on/
provider identifier log, and does not add a reload/attempt wire field or alter digest
or journal identity. Exact marker equality remains mandatory for an existing row;
delete/get absence is idempotent only after that exact old-generation row is gone.

Atlas mode suppresses RemuxDB and segment-provider background probes, binds item detail
state to the authenticated user, and suppresses tenant/provider details from logs.

Upstream release: `v0.25.0`, release commit
`83bcbd98d956347c2efec63d4c7a744f87696ba9`. The upstream OCI image was built from
its functionally identical parent `1949908d1dc4f506e5d4af89da2206bbf59d1714` and is
pinned by digest in `image-lock.json`.

The complete modified source, build instructions, and GNU AGPL v3 license must be
offered at the URL recorded in the final image's `org.opencontainers.image.source`
label. Atlas has not changed Remux's license or warranty terms.
