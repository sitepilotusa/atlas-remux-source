use anyhow::{Result, anyhow};
use async_trait::async_trait;
use chrono::Utc;
use futures::{Stream, StreamExt};
use nutype::nutype;

use serde::{Deserialize, Deserializer};
use sqlx::SqlitePool;
use std::{
    pin::Pin,
    sync::Arc,
    time::{Duration, Instant},
};
use tracing::{debug, warn};
use uuid::Uuid;

use super::{
    AddonCapabilities, AddonKind, AddonMetadata, AddonOption, AddonOptionType,
    AddonPreset, AddonPresetRegistration, CatalogAddon, CatalogInfo, MediaKind,
    MetaAddon, ResourceType, SearchAddon, StreamAddon, SubtitleAddon, SubtitleInfo,
    TreeAddon, addon,
};
use crate::{
    AppContext, common, db, sdks,
    sdks::{CachedEndpoint, ClientError},
    services::stremio as stremio_service,
};

pub struct StremioPreset;

impl AddonPreset for StremioPreset {
    fn id(&self) -> &'static str {
        "stremio"
    }

    fn metadata(&self) -> AddonMetadata {
        AddonMetadata {
            id: "stremio".to_string(),
            display_name: "Stremio addon".to_string(),
            description: "Any addon that speaks the Stremio addon protocol \
                          (manifest.json + /catalog endpoints). Includes AIO."
                .to_string(),
            icon: None,
            supported_resources: vec![
                AddonMetadata::simple_resource(ResourceType::Catalog),
                AddonMetadata::simple_resource(ResourceType::Meta),
                AddonMetadata::simple_resource(ResourceType::Search),
                AddonMetadata::simple_resource(ResourceType::Subtitles),
                AddonMetadata::simple_resource(ResourceType::Stream),
            ],
            supported_types: vec![MediaKind::Movie, MediaKind::Series],
            supported_resources_user: vec![
                ResourceType::Search,
                ResourceType::Subtitles,
                ResourceType::Stream,
            ],
            supported_types_user: vec![MediaKind::Movie, MediaKind::Series],
            options: vec![AddonOption {
                id: "manifest_url".to_string(),
                name: "Manifest URL".to_string(),
                description: Some("Full URL to the addon's manifest.json".to_string()),
                required: true,
                default: None,
                kind: AddonOptionType::Url,
            }],
        }
    }

    fn from_cfg(
        &self,
        addon_id: Uuid,
        cfg: &serde_json::Value,
        config: &crate::Config,
    ) -> Result<AddonCapabilities> {
        let raw_url = cfg
            .get("manifest_url")
            .and_then(|v| v.as_str())
            .ok_or_else(|| anyhow!("Stremio addon missing manifest_url in config"))?
            .to_string();
        // Atlas validates the canonical capability-bearing manifest URL before
        // StremioManifestUrl strips `/manifest.json` for endpoint joining.
        // Validating the normalized base would reject every legitimate Atlas
        // source and would also lose the exact manifest-route proof.
        if config.atlas_remux_patched_tenant_auth
            && db::atlas_tenant::source_manifest_target(config, &raw_url).is_none()
        {
            return Err(anyhow!(
                "Atlas tenant mode requires an Atlas source manifest"
            ));
        }
        let manifest_url = StremioManifestUrl::try_new(raw_url.clone())
            .map_err(|e| anyhow!("Invalid manifest_url: {e}"))?;
        let addon = Arc::new(StremioAddon {
            addon_id,
            config: config.clone(),
            manifest_url,
            atlas_marker_url: config
                .atlas_remux_patched_tenant_auth
                .then_some(raw_url),
            medias_cache: Arc::new(std::sync::Mutex::new(
                std::collections::HashMap::new(),
            )),
        });
        Ok(AddonCapabilities {
            kind: Some(addon.clone()),
            catalog: Some(addon.clone()),
            meta: Some(addon.clone()),
            search: Some(addon.clone()),
            subtitle: Some(addon.clone()),
            stream: Some(addon.clone()),
            tree: Some(addon),
            ..Default::default()
        })
    }
}

inventory::submit! {
    AddonPresetRegistration(|| Box::new(StremioPreset))
}

pub(super) fn parse_manifest_info(
    manifest: &remux_sdks::stremio::Manifest,
) -> (
    Vec<remux_sdks::stremio::ResourceRef>,
    Vec<remux_sdks::stremio::MediaType>,
) {
    let mut seen_names: Vec<ResourceType> = Vec::new();
    let mut resources: Vec<remux_sdks::stremio::ResourceRef> = Vec::new();

    for res in manifest
        .resources
        .iter()
        .cloned()
    {
        let name = res.resource_type();
        if seen_names.contains(&name) {
            continue;
        }
        seen_names.push(name.clone());
        resources.push(res.into_ref());
    }

    // Detect search support via catalog extras and synthesise a Search resource if needed.
    if manifest
        .catalogs
        .iter()
        .any(|c| {
            c.extra
                .iter()
                .any(|e| e.name == "search")
        })
        && !seen_names.contains(&ResourceType::Search)
    {
        resources.push(remux_sdks::stremio::ResourceRef {
            name: ResourceType::Search,
            types: vec![],
            id_prefixes: None,
        });
    }

    let types = manifest
        .types
        .iter()
        .map(|s| {
            serde_json::from_value(serde_json::Value::String(s.clone()))
                .unwrap_or(remux_sdks::stremio::MediaType::Unknown(s.clone()))
        })
        .collect();
    (resources, types)
}

#[nutype(
    sanitize(trim, with = |s: String| {
        // Parse as a URL so we strip /manifest.json and /configure from the path
        // even when a query string is present (a plain suffix match would miss
        // "…/manifest.json?apikey=abc" because the string doesn't end with the suffix).
        if let Ok(mut url) = url::Url::parse(s.trim()) {
            let path = url
                .path()
                .trim_end_matches('/')
                .trim_end_matches("/manifest.json")
                .trim_end_matches("/configure")
                .to_string();
            url.set_path(&path);
            return url.to_string();
        }
        // Fallback for bare paths / non-URL strings.
        let s = s.trim_end_matches('/');
        let s = s.strip_suffix("/manifest.json").unwrap_or(s);
        s.strip_suffix("/configure").unwrap_or(s).to_string()
    }),
    validate(not_empty),
    derive(Debug, Clone, PartialEq, Display, Serialize, Deserialize, AsRef, Deref)
)]
pub struct StremioManifestUrl(String);

fn deserialize_option_aio_url<'de, D>(
    de: D,
) -> Result<Option<StremioManifestUrl>, D::Error>
where
    D: Deserializer<'de>,
{
    let raw: Option<String> = Option::deserialize(de)?;
    Ok(raw.and_then(|s| StremioManifestUrl::try_new(s).ok()))
}

pub struct StremioAddon {
    addon_id: Uuid,
    config: crate::Config,
    manifest_url: StremioManifestUrl,
    /// Full immutable marker retained separately from the ordinary Stremio
    /// base URL normalization. It is parsed into Pathless request state and is
    /// never used as an HTTP target.
    atlas_marker_url: Option<String>,
    /// Raw Stremio `Meta` cached per series lookup-id for the duration of one tree sync.
    /// Shared between the tree-children path and `stremio_meta_fetch` so the API is
    /// called exactly once per series. Evicted by `on_series_done`.
    medias_cache: Arc<
        std::sync::Mutex<std::collections::HashMap<String, Arc<sdks::stremio::Meta>>>,
    >,
}

impl StremioAddon {
    fn service(&self) -> Result<stremio_service::StremioService> {
        if self
            .config
            .atlas_remux_patched_tenant_auth
        {
            stremio_service::StremioService::from_atlas_marker(
                self.atlas_marker_url
                    .as_deref()
                    .ok_or_else(|| anyhow!("Atlas source marker unavailable"))?,
                self.addon_id,
                &self.config,
            )
        } else {
            stremio_service::StremioService::from_url(&self.manifest_url)
        }
    }
}

#[async_trait]
impl AddonKind for StremioAddon {
    fn id(&self) -> &'static str {
        "stremio"
    }

    async fn available_info(
        &self,
    ) -> Result<
        Option<(
            Vec<remux_sdks::stremio::ResourceRef>,
            Vec<remux_sdks::stremio::MediaType>,
        )>,
    > {
        let svc = self.service()?;
        let manifest = svc
            .get_manifest()
            .await?;
        Ok(Some(parse_manifest_info(&manifest)))
    }
}

#[async_trait]
impl CatalogAddon for StremioAddon {
    async fn catalog_list(&self, _ctx: &AppContext) -> Result<Vec<CatalogInfo>> {
        let svc = self.service()?;
        let manifest = svc
            .get_manifest()
            .await?;
        Ok(manifest
            .catalogs
            .into_iter()
            .filter(|c| {
                !c.id
                    .contains("search")
            })
            .map(|c| {
                let kind_label = {
                    let k = c
                        .kind
                        .trim();
                    let mut chars = k.chars();
                    match chars.next() {
                        Some(first) => {
                            first
                                .to_uppercase()
                                .collect::<String>()
                                + chars.as_str()
                        }
                        None => String::new(),
                    }
                };
                let stremio_kind: remux_sdks::stremio::MediaType =
                    serde_json::from_value(serde_json::Value::String(
                        c.kind
                            .clone(),
                    ))
                    .unwrap_or(
                        remux_sdks::stremio::MediaType::Unknown(
                            c.kind
                                .clone(),
                        ),
                    );
                CatalogInfo {
                    collection_media_kind: matches!(
                        c.kind
                            .trim()
                            .to_lowercase()
                            .as_str(),
                        "movie" | "series" | "episode" | "album" | "artist" | "track"
                    )
                    .then(|| {
                        c.kind
                            .as_str()
                            .into()
                    }),
                    media_kind: db::MediaKind::try_from(stremio_kind).ok(),
                    ..CatalogInfo::new(
                        format!("{}:{}", c.kind, c.id),
                        format!(
                            "{} — {} — {}",
                            manifest
                                .name
                                .trim(),
                            c.name
                                .trim(),
                            kind_label
                        ),
                    )
                }
            })
            .collect())
    }

    async fn catalog_stream(
        &self,
        ctx: &AppContext,
        local_id: &str,
    ) -> Result<Option<Pin<Box<dyn Stream<Item = db::Media> + Send>>>> {
        let svc = self.service()?;

        let (kind, id) = local_id
            .split_once(':')
            .ok_or_else(|| anyhow!("invalid stremio catalog id: '{}'", local_id))?;

        let manifest = svc
            .get_manifest()
            .await?;
        let supports_skip = manifest
            .get_catalog(id, &kind.to_string())
            .map(|cat| {
                cat.extra
                    .iter()
                    .any(|e| e.name == "skip")
            })
            .unwrap_or(false);

        let stream = svc
            .get_catalog_stream(kind.to_string(), id.to_string(), supports_skip)
            .await?;
        let tmdb_client = crate::common::tmdb_client(
            &ctx.db,
            &ctx.config
                .tmdb_base_url,
        )
        .await;

        let addon_id = self.addon_id;
        let pathless_extension_context = svc.pathless_extension_context();
        let pathless_source = svc.is_pathless_source();
        let pathless = svc.is_pathless();
        let atlas_config = ctx
            .config
            .clone();
        let stream = stream
            .map(move |mut meta| {
                let svc = svc.clone();
                let tmdb = tmdb_client.clone();
                let atlas_config = atlas_config.clone();
                async move {
                    if meta.is_error() {
                        if !pathless {
                            debug!(id = %meta.id, "catalog item is an error stub, skipping");
                        }
                        return vec![];
                    }
                    if !resolve_imdb_id(&mut meta, Some(&svc), tmdb.as_ref()).await {
                        if !pathless {
                            debug!(id = %meta.id, "could not resolve imdb_id, skipping");
                        }
                        return vec![];
                    }
                    sanitize_atlas_meta(&mut meta, &atlas_config);
                    let converted = match (pathless_source, pathless_extension_context) {
                        (true, None) => db::stremio_meta_to_medias_for_pathless_source(
                            meta,
                            addon_id,
                        ),
                        (false, Some(context)) => db::stremio_meta_to_medias_for_pathless_addon(
                            meta,
                            addon_id,
                            context,
                        ),
                        _ => db::stremio_meta_to_medias_for_addon(meta, addon_id),
                    };
                    match converted {
                        Ok(mut items) => {
                            // Only emit the top-level item (series/movie).
                            // Seasons and episodes are populated by sync_tree
                            // during RefreshLibrary, avoiding FK constraint
                            // failures when chunks are split across parents.
                            items.retain(|x| x.parent_id.is_none());
                            if let Some(top) = items.first_mut() {
                                top.parent_id = None;
                            }
                            items
                        }
                        Err(e) => {
                            if !pathless {
                                warn!(error = %e, "failed to convert stremio metadata, skipping");
                            }
                            vec![]
                        }
                    }
                }
            })
            .buffer_unordered(10)
            .flat_map(futures::stream::iter);

        Ok(Some(Box::pin(stream)))
    }
}

#[async_trait]
impl MetaAddon for StremioAddon {
    async fn supports(&self, media: &db::Media) -> bool {
        stremio_type_for_kind(&media.kind).is_some()
    }

    async fn meta_fetch(
        &self,
        media: &db::Media,
        ctx: &AppContext,
        _config: &crate::api::ServerConfiguration,
    ) -> Result<Option<db::Media>> {
        let svc = self.service()?;
        stremio_meta_fetch(&svc, media, ctx, &self.medias_cache, self.addon_id).await
    }

    fn on_series_done(&self, meta_id: &str) {
        self.medias_cache
            .lock()
            .unwrap()
            .remove(meta_id);
    }
}

#[async_trait]
impl TreeAddon for StremioAddon {
    fn supports(&self, root: &db::Media) -> bool {
        matches!(root.kind, db::MediaKind::Series | db::MediaKind::Season)
    }

    async fn get_children(
        &self,
        root: &db::Media,
        ctx: &AppContext,
    ) -> Result<Option<Vec<db::Media>>> {
        match root.kind {
            db::MediaKind::Series => {
                let svc = self.service()?;
                let meta_arc =
                    fetch_and_cache_meta(&svc, root, &self.medias_cache, ctx).await?;
                let seasons =
                    db::stremio_meta_seasons(&meta_arc, root.id, &root.external_ids);
                if seasons.is_empty() {
                    Ok(None)
                } else {
                    Ok(Some(seasons))
                }
            }
            db::MediaKind::Season => {
                // The series meta is cached under the series' own lookup ID.
                // Prefer grandparent (always set during process_tree_root) over
                // the season's own external_ids which carry no series-level ID.
                let meta_id = root
                    .grandparent
                    .as_deref()
                    .and_then(|gp| {
                        gp.external_ids
                            .stremio_lookup_id()
                    })
                    .or_else(|| {
                        root.external_ids
                            .stremio_lookup_id()
                    })
                    .ok_or_else(|| {
                        anyhow!("season {} has no resolvable meta id", root.id)
                    })?;
                let meta_arc = self
                    .medias_cache
                    .lock()
                    .unwrap()
                    .get(&meta_id)
                    .cloned();
                let Some(meta_arc) = meta_arc else {
                    return Ok(None);
                };
                let season_idx = match root.idx {
                    Some(i) => i,
                    None => return Ok(None),
                };
                let series_external_ids = root
                    .grandparent
                    .as_deref()
                    .map(|gp| {
                        gp.external_ids
                            .clone()
                    })
                    .ok_or_else(|| anyhow!("season {} missing grandparent", root.id))?;
                let series_id = root
                    .grandparent_id
                    .ok_or_else(|| {
                        anyhow!("season {} missing grandparent_id", root.id)
                    })?;
                let mut episodes = db::stremio_meta_season_episodes(
                    &meta_arc,
                    series_id,
                    root.id,
                    season_idx,
                    &series_external_ids,
                )?;
                let now = chrono::Utc::now().naive_utc();
                for ep in &mut episodes {
                    if let Some(ep_num) = ep.idx {
                        if let Some(s_num) = ep.parent_idx {
                            ep.title = format!("S{}E{} - {}", s_num, ep_num, ep.title);
                        } else {
                            ep.title = format!("E{} - {}", ep_num, ep.title);
                        }
                    }
                    // Mark refreshed so TMDB isn't called per-episode during tree sync.
                    ep.refreshed_at = Some(now);
                }
                if episodes.is_empty() {
                    Ok(None)
                } else {
                    Ok(Some(episodes))
                }
            }
            _ => Ok(None),
        }
    }
}

#[async_trait]
impl SearchAddon for StremioAddon {
    async fn search_supports(&self, kind: &db::MediaKind) -> bool {
        stremio_type_for_kind(kind).is_some()
    }

    async fn search(
        &self,
        kind: &db::MediaKind,
        query: &str,
        limit: usize,
        ctx: &AppContext,
    ) -> Result<Option<Vec<db::Media>>> {
        let svc = self.service()?;
        let results =
            stremio_search(&svc, kind, query, limit, ctx, self.addon_id).await?;
        Ok(Some(results))
    }
}

#[async_trait]
impl SubtitleAddon for StremioAddon {
    fn supports(&self, media: &db::Media) -> bool {
        matches!(media.kind, db::MediaKind::Movie | db::MediaKind::Episode)
    }

    async fn subtitle_fetch(
        &self,
        media: &db::Media,
        _db: &SqlitePool,
    ) -> Result<Vec<SubtitleInfo>> {
        let svc = self.service()?;
        let subs = stremio_subtitles(&svc, media).await?;
        if self
            .config
            .atlas_remux_patched_tenant_auth
        {
            let (extension_id, generation, remote_addon_id) = svc
                .pathless_extension_context()
                .ok_or_else(|| anyhow!("Atlas subtitle source unavailable"))?;
            return Ok(subs
                .into_iter()
                .filter_map(|subtitle| {
                    if !subtitle
                        .url
                        .is_empty()
                    {
                        return None;
                    }
                    let (kind, format, sealed_ref) = subtitle
                        .atlas_target_ref
                        .as_ref()?
                        .parts()?;
                    if kind != sdks::stremio::AtlasTargetKind::Subtitle {
                        return None;
                    }
                    let descriptor = crate::stream::AtlasExtensionDescriptor::new(
                        extension_id,
                        generation,
                        remote_addon_id,
                        kind,
                        format,
                        sealed_ref,
                    )?;
                    Some(SubtitleInfo {
                        id: subtitle.id,
                        url: Some(crate::stream::StreamDescriptor::AtlasExtension(
                            descriptor,
                        )),
                        lang: subtitle.lang,
                        is_forced: false,
                        is_hi: false,
                    })
                })
                .collect());
        }
        Ok(subs
            .into_iter()
            .map(|s| SubtitleInfo {
                id: s.id,
                url: Some(crate::stream::StreamDescriptor::http(s.url)),
                lang: s.lang,
                is_forced: false,
                is_hi: false,
            })
            .collect())
    }
}

#[async_trait]
impl StreamAddon for StremioAddon {
    fn supports(&self, media: &db::Media) -> bool {
        stremio_type_for_kind(&media.kind).is_some()
    }

    async fn get_streams(
        &self,
        media: &db::Media,
        _ctx: &AppContext,
        id_prefixes: Option<&[String]>,
    ) -> Result<Vec<crate::stream::StreamInfo>> {
        let svc = self.service()?;
        stremio_streams(
            &svc,
            &self.manifest_url,
            media,
            id_prefixes,
            &self.config,
            self.addon_id,
        )
        .await
    }
}

fn stremio_type_for_kind(kind: &db::MediaKind) -> Option<&'static str> {
    match kind {
        db::MediaKind::Movie => Some("movie"),
        db::MediaKind::Series | db::MediaKind::Season | db::MediaKind::Episode => {
            Some("series")
        }
        db::MediaKind::Track => Some("track"),
        db::MediaKind::Album => Some("album"),
        db::MediaKind::Artist => Some("artist"),
        _ => None,
    }
}

/// Pathless extension image authorizations are body-only sibling objects.
/// Revalidate them before persistence; raw string URLs are always stripped.
fn sanitize_atlas_meta(meta: &mut sdks::stremio::Meta, config: &crate::Config) {
    if !config.atlas_remux_patched_tenant_auth {
        return;
    }
    let retain_image = |value: &mut Option<sdks::stremio::StremioImage>| {
        if value
            .as_ref()
            .is_some_and(|image| {
                image
                    .atlas_target()
                    .and_then(|target| target.parts())
                    .is_none_or(|(kind, format, _)| {
                        kind != sdks::stremio::AtlasTargetKind::Image
                            || format.is_some()
                    })
            })
        {
            *value = None;
        }
    };
    retain_image(&mut meta.poster);
    retain_image(&mut meta.thumbnail);
    retain_image(&mut meta.logo);
    retain_image(&mut meta.background);
    meta.trailers = None;
    if let Some(videos) = &mut meta.videos {
        for episode in videos {
            retain_image(&mut episode.thumbnail);
            episode.cast = None;
        }
    }
    meta.app_extras = None;
}

// ---------------------------------------------------------------------------
// Catalog helpers
// ---------------------------------------------------------------------------

pub(crate) async fn resolve_imdb_id<A: sdks::Auth + Clone>(
    meta: &mut sdks::stremio::Meta,
    svc: Option<&stremio_service::StremioService>,
    tmdb_client: Option<&sdks::RestClient<A>>,
) -> bool {
    let t = Instant::now();
    let pathless = svc.is_some_and(stremio_service::StremioService::is_pathless);

    // Phase 1: build the richest possible ExternalIds before any TMDB calls.
    let mut ids = db::ExternalIds::from_stremio_id(&meta.id);
    if ids
        .imdb
        .is_none()
    {
        ids.imdb = meta
            .imdb_id
            .as_deref()
            .and_then(|s| db::NonEmptyString::try_new(s.to_string()).ok());
    }
    if ids
        .tmdb
        .is_none()
    {
        ids.tmdb = meta
            .moviedb_id
            .map(|n| n as i64);
    }

    // AIO resolve: the addon may map its own ID to an IMDB ID.
    if ids
        .imdb
        .is_none()
    {
        if let Some(svc) = svc {
            if let Some(client) = svc
                .client
                .as_ref()
            {
                match meta
                    .resolve(client)
                    .await
                {
                    Ok(()) => {}
                    Err(e) => warn!(id = %meta.id, error = %e, "AIO resolve failed"),
                }
            }
            if !pathless {
                debug!(id = %meta.id, elapsed = ?t.elapsed(), resolved = meta.imdb_id.is_some(), "after AIO resolve");
            }
            ids.imdb = meta
                .imdb_id
                .as_deref()
                .and_then(|s| db::NonEmptyString::try_new(s.to_string()).ok());
        }
    }

    // Phase 2: single TMDB resolution pass (TMDB/TVDB/Kitsu chains handled inside).
    if ids
        .imdb
        .is_none()
    {
        if let Some(client) = tmdb_client {
            if !ids.is_empty() {
                let is_tv = meta.media_type == sdks::stremio::MediaType::Series;
                ids.imdb =
                    crate::addons::tmdb::resolve_imdb_from_ids(&ids, is_tv, client)
                        .await;
                if !pathless {
                    debug!(id = %meta.id, elapsed = ?t.elapsed(), resolved = ids.imdb.is_some(), "after TMDB resolve");
                }
            }
        }
    }

    meta.imdb_id = ids
        .imdb
        .clone()
        .map(Into::into);

    if meta
        .imdb_id
        .is_none()
    {
        // Allow items that have a recognised non-IMDB identity (custom addon prefix or
        // kitsu ID that couldn't be resolved to IMDB — anime often isn't on IMDB).
        return ids
            .custom_stremio_id
            .is_some()
            || ids
                .kitsu
                .is_some();
    }

    true
}

fn is_404(e: &anyhow::Error) -> bool {
    matches!(
        e.downcast_ref::<ClientError>(),
        Some(ClientError::Http { status: 404, .. })
    )
}

// ---------------------------------------------------------------------------
// Meta helpers
// ---------------------------------------------------------------------------

/// Finds a working alternate Stremio type for `meta_id` by consulting the
/// addon's own manifest, for the case where `tried_type` (derived generically
/// from `MediaKind`) 404s. Only considers `meta` resources whose `idPrefixes`
/// match `meta_id` (or which have no prefix restriction), and probes each
/// candidate type with a real request — the manifest can list types that
/// don't apply to this specific ID, so a match here isn't guaranteed either.
/// Returns the successful fetch directly to avoid a redundant second request.
async fn manifest_meta_type_fallback(
    svc: &stremio_service::StremioService,
    tried_type: &sdks::stremio::MediaType,
    meta_id: &str,
) -> Option<sdks::stremio::Meta> {
    let manifest = svc
        .get_manifest()
        .await
        .ok()?;
    let tried = tried_type.to_string();
    let candidates: Vec<String> = manifest
        .resources
        .into_iter()
        .filter_map(|r| match r {
            sdks::stremio::Resource::Detailed(r) if r.name == ResourceType::Meta => {
                let prefix_ok = r
                    .id_prefixes
                    .as_ref()
                    .map(|prefixes| {
                        prefixes
                            .iter()
                            .any(|p| meta_id.starts_with(p.as_str()))
                    })
                    .unwrap_or(true);
                prefix_ok.then_some(r.types)
            }
            _ => None,
        })
        .flatten()
        .filter(|t| t != &tried)
        .collect();

    for candidate in candidates {
        let alt_type = sdks::stremio::MediaType::Unknown(candidate);
        if let Ok(meta) = svc
            .get_meta(alt_type, meta_id.to_string())
            .await
        {
            return Some(meta);
        }
    }
    None
}

/// Fetch the raw Stremio `Meta` for `media`, storing it in `cache` keyed by
/// the series-level lookup id. Returns the cached `Arc` immediately if present.
async fn fetch_and_cache_meta(
    svc: &stremio_service::StremioService,
    media: &db::Media,
    cache: &std::sync::Mutex<
        std::collections::HashMap<String, Arc<sdks::stremio::Meta>>,
    >,
    ctx: &AppContext,
) -> Result<Arc<sdks::stremio::Meta>> {
    // For Season/Episode, the series meta is cached under the series' ID.
    // Prefer grandparent lookup so Seasons/Episodes with empty own external_ids
    // still resolve to the correct cache entry.
    let meta_id: String = media
        .grandparent
        .as_deref()
        .and_then(|gp| {
            gp.external_ids
                .stremio_lookup_id()
        })
        .or_else(|| {
            media
                .external_ids
                .stremio_lookup_id()
        })
        .ok_or_else(|| anyhow!("no resolvable meta id for {}", media.id))?;

    if let Some(cached) = cache
        .lock()
        .unwrap()
        .get(&meta_id)
        .cloned()
    {
        return Ok(cached);
    }

    let series_imdb = media
        .grandparent
        .as_deref()
        .and_then(|gp| {
            gp.external_ids
                .imdb
                .clone()
        });
    let is_custom = media
        .external_ids
        .imdb
        .is_none()
        && series_imdb.is_none();
    let media_type = media
        .external_ids
        .stremio_media_type(&media.kind);
    let meta: Arc<sdks::stremio::Meta> = if let Some(stored) = ctx
        .store
        .get::<sdks::stremio::Meta>(
            media
                .id
                .to_string(),
        ) {
        stored
    } else {
        Arc::new(
            match svc
                .get_meta(media_type.clone(), meta_id.clone())
                .await
            {
                Ok(m) => m,
                // Custom-ID items (no IMDB/TMDB) have no `MediaKind`-derived type that's
                // guaranteed correct: a DB row imported before `custom_stremio_type` was
                // tracked (or a season/episode that never inherited it) falls back to a
                // generic type that may not match the addon's own non-standard one (e.g.
                // "anime"). Ask the addon's manifest what type(s) it actually serves for
                // this ID and retry, rather than failing permanently.
                Err(e)
                    if is_404(&e)
                        && is_custom
                        && media
                            .external_ids
                            .custom_stremio_type
                            .is_none() =>
                {
                    match manifest_meta_type_fallback(svc, &media_type, &meta_id).await
                    {
                        Some(m) => m,
                        None => return Err(e),
                    }
                }
                Err(e) if is_404(&e) && !is_custom => {
                    let series_tmdb = media
                        .grandparent
                        .as_deref()
                        .and_then(|gp| {
                            gp.external_ids
                                .tmdb
                        });
                    let tmdb_id = media
                        .external_ids
                        .tmdb
                        .or(series_tmdb);
                    if let Some(tid) = tmdb_id {
                        svc.get_meta(media_type, format!("tmdb:{}", tid))
                            .await?
                    } else {
                        return Err(e);
                    }
                }
                Err(e) => return Err(e),
            },
        )
    };

    let arc = if ctx
        .config
        .atlas_remux_patched_tenant_auth
    {
        let mut sanitized = (*meta).clone();
        sanitize_atlas_meta(&mut sanitized, &ctx.config);
        Arc::new(sanitized)
    } else {
        meta
    };
    cache
        .lock()
        .unwrap()
        .insert(meta_id, Arc::clone(&arc));
    Ok(arc)
}

async fn stremio_meta_fetch(
    svc: &stremio_service::StremioService,
    media: &db::Media,
    ctx: &AppContext,
    medias_cache: &std::sync::Mutex<
        std::collections::HashMap<String, Arc<sdks::stremio::Meta>>,
    >,
    addon_id: Uuid,
) -> Result<Option<db::Media>> {
    let imdb_id = media
        .grandparent
        .as_deref()
        .and_then(|gp| {
            gp.external_ids
                .imdb
                .clone()
        })
        .or(media
            .external_ids
            .imdb
            .clone());
    let is_custom = imdb_id.is_none();

    let meta_arc = fetch_and_cache_meta(svc, media, medias_cache, ctx).await?;

    match media.kind {
        db::MediaKind::Movie | db::MediaKind::Series => {
            // Patch imdb_id into a mutable clone for root-level conversion and
            // relations. Only the Movie/Series arm needs the owned copy — cloning
            // it unconditionally deep-copies every entry in `videos`, which is
            // ruinous for series with thousands of episodes.
            let mut meta_patched = (*meta_arc).clone();
            if meta_patched
                .imdb_id
                .is_none()
                && !is_custom
            {
                meta_patched.imdb_id =
                    db::ExternalIds::from_stremio_id(&meta_patched.id)
                        .imdb
                        .map(Into::into)
                        .or_else(|| imdb_id.map(Into::into));
            }
            if meta_patched.is_error() {
                if !svc.is_pathless() {
                    warn!(
                        id = %media.id,
                        error_title = %meta_patched.get_name().unwrap_or_default(),
                        error_description = %meta_patched.description.as_deref().unwrap_or(""),
                        "meta addon returned an error, skipping"
                    );
                }
                return Ok(None);
            }
            let mut found =
                db::Media::try_from(meta_patched.clone()).map_err(|e| anyhow!(e))?;
            found
                .external_ids
                .atlas_stremio_addon_id = Some(addon_id);
            found
                .external_ids
                .atlas_source_ref = media
                .external_ids
                .atlas_source_ref
                .clone();
            // Preserve the persisted ID — try_from recomputes it from external_ids.
            found.id = media.id;
            if let Some(context) = svc.pathless_extension_context() {
                db::apply_stremio_atlas_images(&mut found, &meta_patched, context);
            }
            let relations = build_relations(media, &meta_patched);
            if !relations.is_empty() {
                found.relations = Some(relations);
            }
            Ok(Some(found))
        }
        db::MediaKind::Season => {
            let series_id = media
                .grandparent_id
                .or(media.parent_id)
                .ok_or_else(|| anyhow!("season {} missing grandparent_id", media.id))?;
            let series_external_ids = media
                .grandparent
                .as_deref()
                .map(|gp| {
                    gp.external_ids
                        .clone()
                })
                .ok_or_else(|| anyhow!("season {} missing grandparent", media.id))?;
            let seasons =
                db::stremio_meta_seasons(&meta_arc, series_id, &series_external_ids);
            Ok(seasons
                .into_iter()
                .find(|s| s.idx == media.idx))
        }
        db::MediaKind::Episode => {
            let series_id = media
                .grandparent_id
                .ok_or_else(|| {
                    anyhow!("episode {} missing grandparent_id", media.id)
                })?;
            let season_id = media
                .parent_id
                .ok_or_else(|| anyhow!("episode {} missing parent_id", media.id))?;
            let season_idx = media
                .parent_idx
                .ok_or_else(|| anyhow!("episode {} missing parent_idx", media.id))?;
            let series_external_ids = media
                .grandparent
                .as_deref()
                .map(|gp| {
                    gp.external_ids
                        .clone()
                })
                .ok_or_else(|| anyhow!("episode {} missing grandparent", media.id))?;
            // Locate just this episode's video entry. Materialising the whole
            // season here and discarding all but one row made a season of N
            // episodes cost O(N^2) to refresh.
            let Some(meta_ep) = meta_arc
                .videos
                .as_ref()
                .and_then(|v| {
                    v.iter()
                        .find(|e| {
                            e.episode == media.idx && e.season == media.parent_idx
                        })
                })
            else {
                return Ok(None);
            };
            let mut found = db::stremio_meta_episode(
                meta_ep,
                series_id,
                season_id,
                season_idx,
                &series_external_ids,
            )?;
            if let Some(context) = svc.pathless_extension_context() {
                db::apply_stremio_episode_atlas_image(&mut found, meta_ep, context);
            }
            let relations = build_episode_relations(media, meta_ep);
            if !relations.is_empty() {
                found.relations = Some(relations);
            }
            Ok(Some(found))
        }
        _ => Ok(None),
    }
}

// ---------------------------------------------------------------------------
// Relation builders
// ---------------------------------------------------------------------------

pub(crate) fn build_relations(
    media: &db::Media,
    meta: &sdks::stremio::Meta,
) -> Vec<(db::MediaRelation, db::Media)> {
    let mut relations = Vec::new();
    let atlas_addon_id = media
        .external_ids
        .atlas_stremio_addon_id;

    if let Some(genres) = meta
        .genre
        .as_ref()
        .or(meta
            .genres
            .as_ref())
    {
        for genre_name in genres {
            let genre_id = tenant_relation_id(
                &db::MediaKind::Genre,
                &genre_name.to_lowercase(),
                atlas_addon_id,
            );
            relations.push((
                db::MediaRelation {
                    left_media_id: media.id,
                    right_media_id: genre_id,
                    role: None,
                    ..Default::default()
                },
                db::Media {
                    id: genre_id,
                    title: genre_name.clone(),
                    kind: db::MediaKind::Genre,
                    external_ids: db::ExternalIds {
                        atlas_stremio_addon_id: atlas_addon_id,
                        ..Default::default()
                    },
                    ..Default::default()
                },
            ));
        }
    }

    let mut rels = build_person_relations(
        media.id,
        meta.director
            .as_ref(),
        meta.writer
            .as_ref(),
        None,
        meta.cast
            .as_ref(),
        None,
        None,
        atlas_addon_id,
    );

    if let Some(extras) = &meta.app_extras {
        rels.extend(build_person_relations(
            media.id,
            None,
            None,
            extras
                .cast
                .as_ref(),
            None,
            extras
                .directors
                .as_ref(),
            extras
                .writers
                .as_ref(),
            atlas_addon_id,
        ));
    }

    relations.extend(rels);
    relations
}

pub(crate) fn build_episode_relations(
    media: &db::Media,
    ep: &sdks::stremio::Episode,
) -> Vec<(db::MediaRelation, db::Media)> {
    build_person_relations(
        media.id,
        ep.directors
            .as_ref(),
        ep.writers
            .as_ref(),
        None,
        None,
        None,
        None,
        media
            .external_ids
            .atlas_stremio_addon_id,
    )
}

fn build_person_relations(
    left_media_id: Uuid,
    directors: Option<&Vec<String>>,
    writers: Option<&Vec<String>>,
    cast_members: Option<&Vec<sdks::stremio::CastMember>>,
    cast_names: Option<&Vec<String>>,
    director_members: Option<&Vec<sdks::stremio::CastMember>>,
    writer_members: Option<&Vec<sdks::stremio::CastMember>>,
    atlas_addon_id: Option<Uuid>,
) -> Vec<(db::MediaRelation, db::Media)> {
    let mut relations = Vec::new();

    let split_names = |names: Option<&Vec<String>>| -> Vec<String> {
        names
            .map(|v| v.as_slice())
            .unwrap_or_default()
            .iter()
            .flat_map(|s| {
                s.split(',')
                    .map(|n| {
                        n.trim()
                            .to_string()
                    })
            })
            .filter(|s| !s.is_empty())
            .collect()
    };

    let mut add_members = |members: Option<&Vec<sdks::stremio::CastMember>>,
                           role: db::RelationRole,
                           offset: i64| {
        if let Some(list) = members {
            for (i, member) in list
                .iter()
                .enumerate()
            {
                if let Some(name) = &member.name {
                    let name = name
                        .trim()
                        .to_string();
                    if name.is_empty() {
                        continue;
                    }
                    let person_id = tenant_relation_id(
                        &db::MediaKind::Person,
                        &name.to_lowercase(),
                        atlas_addon_id,
                    );
                    let mut person = db::Media {
                        id: person_id,
                        title: name.clone(),
                        kind: db::MediaKind::Person,
                        external_ids: db::ExternalIds {
                            atlas_stremio_addon_id: atlas_addon_id,
                            ..Default::default()
                        },
                        ..Default::default()
                    };
                    if let Some(url) = member
                        .photo
                        .clone()
                    {
                        person.set_image(db::ImageKind::Primary, url);
                    }
                    relations.push((
                        db::MediaRelation {
                            left_media_id,
                            right_media_id: person_id,
                            weight: Some(offset + i as i64),
                            role: Some(role.clone()),
                            character: member
                                .character
                                .clone(),
                            ..Default::default()
                        },
                        person,
                    ));
                }
            }
        }
    };

    add_members(cast_members, db::RelationRole::Actor, 0);
    add_members(director_members, db::RelationRole::Director, 0);
    add_members(writer_members, db::RelationRole::Writer, 0);

    for (i, name) in split_names(cast_names)
        .into_iter()
        .enumerate()
    {
        let person_id = tenant_relation_id(
            &db::MediaKind::Person,
            &name.to_lowercase(),
            atlas_addon_id,
        );
        relations.push((
            db::MediaRelation {
                left_media_id,
                right_media_id: person_id,
                weight: Some(
                    (i + cast_members
                        .map(|c| c.len())
                        .unwrap_or(0)) as i64,
                ),
                role: Some(db::RelationRole::Actor),
                ..Default::default()
            },
            db::Media {
                id: person_id,
                title: name.clone(),
                kind: db::MediaKind::Person,
                external_ids: db::ExternalIds {
                    atlas_stremio_addon_id: atlas_addon_id,
                    ..Default::default()
                },
                ..Default::default()
            },
        ));
    }

    for (i, name) in split_names(directors)
        .into_iter()
        .enumerate()
    {
        let person_id = tenant_relation_id(
            &db::MediaKind::Person,
            &name.to_lowercase(),
            atlas_addon_id,
        );
        relations.push((
            db::MediaRelation {
                left_media_id,
                right_media_id: person_id,
                weight: Some(
                    (i + director_members
                        .map(|c| c.len())
                        .unwrap_or(0)) as i64,
                ),
                role: Some(db::RelationRole::Director),
                ..Default::default()
            },
            db::Media {
                id: person_id,
                title: name.clone(),
                kind: db::MediaKind::Person,
                external_ids: db::ExternalIds {
                    atlas_stremio_addon_id: atlas_addon_id,
                    ..Default::default()
                },
                ..Default::default()
            },
        ));
    }

    for (i, name) in split_names(writers)
        .into_iter()
        .enumerate()
    {
        let person_id = tenant_relation_id(
            &db::MediaKind::Person,
            &name.to_lowercase(),
            atlas_addon_id,
        );
        relations.push((
            db::MediaRelation {
                left_media_id,
                right_media_id: person_id,
                weight: Some(
                    (i + writer_members
                        .map(|c| c.len())
                        .unwrap_or(0)) as i64,
                ),
                role: Some(db::RelationRole::Writer),
                ..Default::default()
            },
            db::Media {
                id: person_id,
                title: name.clone(),
                kind: db::MediaKind::Person,
                external_ids: db::ExternalIds {
                    atlas_stremio_addon_id: atlas_addon_id,
                    ..Default::default()
                },
                ..Default::default()
            },
        ));
    }

    relations
}

fn tenant_relation_id(
    kind: &db::MediaKind,
    canonical: &str,
    atlas_addon_id: Option<Uuid>,
) -> Uuid {
    let scoped = atlas_addon_id
        .map(|addon_id| format!("atlas-stremio:{addon_id}:{canonical}"))
        .unwrap_or_else(|| canonical.to_string());
    common::stable_media_uuid(kind, &scoped)
}

// ---------------------------------------------------------------------------
// Search helpers
// ---------------------------------------------------------------------------

async fn stremio_search(
    svc: &stremio_service::StremioService,
    kind: &db::MediaKind,
    query: &str,
    limit: usize,
    ctx: &AppContext,
    addon_id: Uuid,
) -> Result<Vec<db::Media>> {
    use itertools::Itertools;

    let aio_type = match kind {
        db::MediaKind::Movie => sdks::stremio::MediaType::Movie,
        db::MediaKind::Series => sdks::stremio::MediaType::Series,
        _ => return Ok(vec![]),
    };

    let results = svc
        .search(aio_type, query.to_string())
        .await
        .unwrap_or_default();
    let pathless_extension_context = svc.pathless_extension_context();
    let pathless_source = svc.is_pathless_source();

    let mut media = results
        .into_iter()
        .unique_by(|m| {
            m.imdb_id
                .as_ref()
                .filter(|id| !id.is_empty())
                .map(|id| format!("imdb:{}", id))
                .unwrap_or_else(|| format!("{}:{}", m.media_type, m.id))
        })
        .take(limit)
        .filter(|meta| !meta.is_error())
        .filter_map(|mut meta| {
            sanitize_atlas_meta(&mut meta, &ctx.config);
            let mut m = db::Media::try_from(meta.clone()).ok()?;
            m.external_ids
                .atlas_stremio_addon_id = Some(addon_id);
            if pathless_source {
                m.external_ids
                    .atlas_source_ref = db::atlas_source_ref(&meta.id);
            }
            let raw = m.media_id_raw();
            if raw
                .canonical()
                .is_some()
            {
                m.id = Uuid::from(&raw);
            }
            if let Some(context) = pathless_extension_context {
                db::apply_stremio_atlas_images(&mut m, &meta, context);
            }
            let rels = build_relations(&m, &meta);
            m.relations = Some(rels);
            Some(m)
        })
        .collect();

    db::Media::preload_parents(&ctx.db, &mut media).await;

    Ok(media)
}

// ---------------------------------------------------------------------------
// Subtitle helpers
// ---------------------------------------------------------------------------

async fn stremio_subtitles(
    svc: &stremio_service::StremioService,
    media: &db::Media,
) -> Result<Vec<sdks::stremio::Subtitle>> {
    let (imdb_id, media_type, season, episode) = match media.kind {
        db::MediaKind::Movie => (
            media
                .external_ids
                .imdb
                .as_deref()
                .ok_or_else(|| anyhow!("no imdb_id"))?,
            sdks::stremio::MediaType::Movie,
            None,
            None,
        ),
        db::MediaKind::Episode => (
            media
                .grandparent
                .as_deref()
                .and_then(|gp| {
                    gp.external_ids
                        .imdb
                        .as_deref()
                })
                .ok_or_else(|| anyhow!("no grandparent imdb for subtitle lookup"))?,
            sdks::stremio::MediaType::Series,
            media.parent_idx,
            media.idx,
        ),
        _ => return Err(anyhow!("subtitles not supported for {:?}", media.kind)),
    };

    svc.get_subtitles(media_type, imdb_id, season, episode)
        .await
}

// ---------------------------------------------------------------------------
// Stream helpers
// ---------------------------------------------------------------------------

/// Rewrite a URL whose host is `aiostreams` to use the stremio addon's origin.
/// AIO running in Docker uses this internal hostname; we remap it at descriptor
/// construction time so callers never see the unresolvable internal address.
fn rewrite_aio_url(url: &str, manifest_url: &StremioManifestUrl) -> String {
    let Ok(mut parsed) = url::Url::parse(url) else {
        return url.to_string();
    };
    if !parsed
        .host_str()
        .map(|h| h.eq_ignore_ascii_case("aiostreams"))
        .unwrap_or(false)
    {
        return url.to_string();
    }
    let Ok(origin) = url::Url::parse(manifest_url.as_str()) else {
        return url.to_string();
    };
    let _ = parsed.set_scheme(origin.scheme());
    let _ = parsed.set_host(origin.host_str());
    let _ = parsed.set_port(origin.port());
    parsed.to_string()
}

async fn stremio_streams(
    svc: &stremio_service::StremioService,
    manifest_url: &StremioManifestUrl,
    media: &db::Media,
    id_prefixes: Option<&[String]>,
    config: &crate::Config,
    remote_addon_id: Uuid,
) -> Result<Vec<crate::stream::StreamInfo>> {
    let gp_ext = media
        .grandparent
        .as_deref()
        .map(|gp| &gp.external_ids);
    let all_candidates = media.candidate_ids(gp_ext);
    let ids_to_try: Vec<String> = match id_prefixes {
        Some(prefixes) => all_candidates
            .into_iter()
            .filter(|id| {
                prefixes
                    .iter()
                    .any(|p| id.starts_with(p.as_str()))
            })
            .collect(),
        None => all_candidates,
    };
    if ids_to_try.is_empty() {
        return Err(anyhow!("no resolvable ID for Stremio stream lookup"));
    }
    let media_type = media
        .external_ids
        .stremio_media_type(&media.kind);

    let mut last_err: Option<anyhow::Error> = None;
    let mut streams_opt: Option<Vec<sdks::stremio::Stream>> = None;
    for id in ids_to_try {
        match svc
            .get_streams(media_type.clone(), id)
            .await
        {
            Ok(s) => {
                streams_opt = Some(s);
                break;
            }
            Err(e) if is_404(&e) => {
                last_err = Some(e);
            }
            Err(e) => return Err(e),
        }
    }
    let streams = match streams_opt {
        Some(s) => s,
        None => return Err(last_err.unwrap_or_else(|| anyhow!("no streams found"))),
    };

    if config.atlas_remux_patched_tenant_auth {
        let extension_context = svc.pathless_extension_context();
        return Ok(streams
            .into_iter()
            .filter_map(|stream| {
                atlas_stream_info(stream, config, remote_addon_id, extension_context)
            })
            .collect());
    }

    Ok(streams
        .into_iter()
        .filter(|s| s.is_valid())
        .filter_map(|s| {
            let descriptor = if s.is_torrent() {
                crate::stream::StreamDescriptor::Torrent {
                    info_hash: s
                        .info_hash()?
                        .to_ascii_lowercase(),
                    file_hint: s
                        .filename
                        .clone(),
                    file_idx: s
                        .file_idx
                        .map(|i| i as usize),
                    trackers: s
                        .sources
                        .as_deref()
                        .unwrap_or_default()
                        .iter()
                        .filter_map(|src| src.strip_prefix("tracker:"))
                        .map(String::from)
                        .collect(),
                }
            } else {
                let url = s
                    .url
                    .clone()
                    .or_else(|| {
                        s.external_url
                            .clone()
                    })?;
                crate::stream::StreamDescriptor::Http {
                    url: rewrite_aio_url(&url, manifest_url),
                    request_headers: s
                        .request_headers
                        .clone(),
                    response_headers: s
                        .response_headers
                        .clone(),
                }
            };
            let (presentation_name, presentation_description) =
                stremio_presentation_fields(&s);
            let sd = s
                .stream_data
                .as_ref();
            // Prefer nzb_url from streamData (AIOStreams), fall back to top-level field
            let nzb_url = sd
                .and_then(|d| {
                    d.nzb_url
                        .clone()
                })
                .or_else(|| {
                    s.nzb_url
                        .clone()
                });
            let usenet_guid = nzb_url
                .as_deref()
                .and_then(|u| {
                    url::Url::parse(u)
                        .ok()?
                        .query_pairs()
                        .find_map(|(k, v)| (k == "id").then(|| v.into_owned()))
                });
            let torrent_info_hash = sd
                .and_then(|d| {
                    d.torrent
                        .as_ref()
                })
                .and_then(|t| {
                    t.info_hash
                        .as_deref()
                })
                .map(|h| h.to_ascii_lowercase());
            let torrent_file_idx = sd
                .and_then(|d| {
                    d.torrent
                        .as_ref()
                })
                .and_then(|t| t.file_idx)
                .filter(|&i| i >= 0);
            Some(crate::stream::StreamInfo {
                descriptor,
                name: presentation_name,
                description: presentation_description,
                filename: s
                    .behavior_hints
                    .as_ref()
                    .and_then(|bh| {
                        bh.filename
                            .clone()
                    })
                    .or_else(|| {
                        sd.and_then(|d| {
                            d.filename
                                .clone()
                        })
                    })
                    .or_else(|| {
                        s.filename
                            .clone()
                    }),
                seeders: s.seeders,
                size: sd
                    .and_then(|d| d.size)
                    .or(s.size),
                duration: s.duration,
                subtitles: s
                    .subtitles
                    .clone(),
                usenet_guid,
                usenet_indexer: sd
                    .and_then(|d| {
                        d.indexer
                            .clone()
                    })
                    .or_else(|| {
                        s.indexer
                            .clone()
                    }),
                nzb_url,
                torrent_info_hash,
                torrent_file_idx,
                service_id: sd
                    .and_then(|d| {
                        d.service
                            .as_ref()
                    })
                    .and_then(|s| {
                        s.id.as_deref()
                    })
                    .map(remux_sdks::remux::ServiceId::new),
                probe_data: s
                    .behavior_hints
                    .as_ref()
                    .and_then(|bh| {
                        bh.media_info
                            .as_ref()
                    })
                    .map(remux_sdks::remux::MediaSourceInfo::from),
                ..Default::default()
            })
        })
        .collect())
}

fn atlas_stream_info(
    stream: sdks::stremio::Stream,
    _config: &crate::Config,
    remote_addon_id: Uuid,
    extension_context: Option<(Uuid, u32, Uuid)>,
) -> Option<crate::stream::StreamInfo> {
    if stream
        .atlas_stream_facts
        .as_ref()
        .is_some_and(|facts| !facts.is_closed_and_safe())
    {
        return None;
    }
    if stream
        .atlas_stream_quality
        .as_ref()
        .is_some_and(|quality| !quality.is_closed_and_safe())
    {
        return None;
    }
    if stream
        .info_hash
        .is_some()
        || stream
            .external_url
            .is_some()
        || stream
            .yt_id
            .is_some()
        || stream
            .nzb_url
            .is_some()
        || stream
            .rar_urls
            .is_some()
        || stream
            .seven_zip_urls
            .is_some()
        || stream
            .tar_urls
            .is_some()
        || stream
            .tgz_urls
            .is_some()
        || stream
            .sources
            .is_some()
        || stream
            .stream_data
            .is_some()
        || stream.proxied
        || !stream
            .request_headers
            .is_empty()
        || !stream
            .response_headers
            .is_empty()
        || !stream
            .subtitles
            .is_empty()
    {
        return None;
    }
    let descriptor = if let Some(target) = stream
        .atlas_media_target
        .as_ref()
    {
        let (source_binding_id, generation, media_id) = target.parts()?;
        if stream
            .url
            .is_some()
            || stream
                .atlas_target_ref
                .is_some()
            || stream
                .atlas_stream_facts
                .is_some()
            || stream
                .atlas_stream_quality
                .is_some()
        {
            return None;
        }
        crate::stream::StreamDescriptor::AtlasMedia(
            crate::stream::AtlasMediaDescriptor {
                source_binding_id,
                generation,
                remote_addon_id,
                media_id,
            },
        )
    } else if let Some(target) = stream
        .atlas_target_ref
        .as_ref()
    {
        let (kind, format, sealed_ref) = target.parts()?;
        if kind != sdks::stremio::AtlasTargetKind::Stream
            || format.is_some()
            || stream
                .url
                .is_some()
            || stream
                .atlas_media_target
                .is_some()
        {
            return None;
        }
        let (extension_id, generation, context_addon_id) = extension_context?;
        if context_addon_id != remote_addon_id {
            return None;
        }
        crate::stream::StreamDescriptor::AtlasExtension(
            crate::stream::AtlasExtensionDescriptor::new(
                extension_id,
                generation,
                remote_addon_id,
                kind,
                format,
                sealed_ref,
            )?,
        )
    } else {
        return None;
    };
    if stream
        .thumbnail
        .as_ref()
        .is_some_and(|thumbnail| {
            thumbnail
                .atlas_target()
                .and_then(|target| target.parts())
                .is_none_or(|(kind, format, _)| {
                    kind != sdks::stremio::AtlasTargetKind::Image || format.is_some()
                })
        })
    {
        return None;
    }
    let (name, description) = stremio_presentation_fields(&stream);
    let atlas_stream_facts = stream.atlas_stream_facts;
    let atlas_stream_quality = stream.atlas_stream_quality;
    Some(crate::stream::StreamInfo {
        descriptor,
        name,
        description,
        atlas_stream_facts,
        atlas_stream_quality,
        duration: stream.duration,
        size: stream.size,
        subtitles: Vec::new(),
        ..Default::default()
    })
}

fn stremio_presentation_fields(
    stream: &sdks::stremio::Stream,
) -> (Option<String>, Option<String>) {
    (
        stream
            .name
            .clone(),
        stream
            .description
            .clone()
            .or_else(|| {
                stream
                    .title
                    .clone()
            }),
    )
}

#[cfg(test)]
mod tests {
    use super::*;

    fn atlas_config() -> crate::Config {
        crate::Config {
            atlas_remux_patched_tenant_auth: true,
            atlas_extension_relay_origin: Some(
                "https://relay.atlas.invalid".to_string(),
            ),
            atlas_pathless_api_origin: Some("https://api.atlas.invalid".to_string()),
            ..Default::default()
        }
    }

    #[test]
    fn atlas_from_cfg_loads_only_exact_pathless_markers_before_normalization() {
        let config = atlas_config();
        let binding = Uuid::new_v4();
        for manifest_url in [
            format!(
                "https://relay.atlas.invalid/.well-known/atlas-source/{binding}/1/manifest.json"
            ),
            format!(
                "https://relay.atlas.invalid/.well-known/atlas-extension/{binding}/2/manifest.json"
            ),
        ] {
            let capabilities = StremioPreset
                .from_cfg(
                    Uuid::new_v4(),
                    &serde_json::json!({ "manifest_url": manifest_url }),
                    &config,
                )
                .expect("canonical Atlas manifest must instantiate");
            assert_eq!(
                capabilities
                    .kind
                    .as_ref()
                    .unwrap()
                    .id(),
                "stremio"
            );
            assert!(
                capabilities
                    .catalog
                    .is_some()
            );
            assert!(
                capabilities
                    .meta
                    .is_some()
            );
            assert!(
                capabilities
                    .stream
                    .is_some()
            );
            assert!(
                capabilities
                    .subtitle
                    .is_some()
            );
        }

        for rejected in [
            format!("https://relay.atlas.invalid/.well-known/atlas-source/{binding}/1"),
            format!(
                "https://relay.atlas.invalid/.well-known/atlas-source/{binding}/1/manifest.json?secret=1"
            ),
            format!(
                "https://relay.atlas.invalid/.well-known/atlas-source/{binding}/0/manifest.json"
            ),
            "https://provider.invalid/manifest.json".to_string(),
            format!(
                "https://relay.atlas.invalid/.well-known/atlas-extension/{binding}/2/manifest.json/"
            ),
        ] {
            assert!(
                StremioPreset
                    .from_cfg(
                        Uuid::new_v4(),
                        &serde_json::json!({ "manifest_url": rejected }),
                        &config,
                    )
                    .is_err()
            );
        }
    }

    #[test]
    fn atlas_streams_are_body_only_targets_without_headers_or_provider_modes() {
        let config = atlas_config();
        let extension_id = Uuid::new_v4();
        let remote_addon_id = Uuid::new_v4();
        let accepted: sdks::stremio::Stream =
            serde_json::from_value(serde_json::json!({
                "atlasTargetRef": {
                    "version": 2,
                    "kind": "stream",
                    "format": null,
                    "sealedRef": "AQID"
                },
                "name": "Owner stream",
                "atlasStreamFacts": {
                    "Version": 1,
                    "Resolution": 2160,
                    "MultiAudio": true,
                    "JunkMarker": "commentary",
                    "GroupKey": format!("agk1_{}", "A".repeat(43))
                },
                "atlasStreamQuality": {
                    "Version": 1,
                    "RelativeScore": 87
                }
            }))
            .unwrap();
        let info = atlas_stream_info(
            accepted,
            &config,
            remote_addon_id,
            Some((extension_id, 7, remote_addon_id)),
        )
        .expect("body target accepted");
        let crate::stream::StreamDescriptor::AtlasExtension(target) = info.descriptor
        else {
            panic!("Atlas stream must remain a private target");
        };
        assert_eq!(target.extension_id, extension_id);
        assert_eq!(target.generation, 7);
        assert_eq!(target.remote_addon_id, remote_addon_id);
        assert_eq!(target.sealed_ref(), "AQID");
        let facts = info
            .atlas_stream_facts
            .expect("typed stream facts carried");
        assert_eq!(
            facts.resolution,
            Some(remux_sdks::remux::AtlasStreamResolution::R2160)
        );
        assert_eq!(facts.multi_audio, Some(true));
        assert_eq!(
            info.atlas_stream_quality
                .expect("typed stream quality carried")
                .relative_score,
            87
        );

        for value in [
            serde_json::json!({"url": "https://provider.invalid/video.mp4"}),
            serde_json::json!({"externalUrl": "https://provider.invalid/video.mp4"}),
            serde_json::json!({"infoHash": "abc"}),
            serde_json::json!({"proxied": true}),
        ] {
            let stream: sdks::stremio::Stream = serde_json::from_value(value).unwrap();
            assert!(atlas_stream_info(stream, &config, Uuid::nil(), None).is_none());
        }
    }

    #[test]
    fn atlas_streams_preserve_final_formatter_name_description_and_legacy_title() {
        let config = atlas_config();
        let extension_id = Uuid::new_v4();
        let remote_addon_id = Uuid::new_v4();
        let formatted: sdks::stremio::Stream =
            serde_json::from_value(serde_json::json!({
                "atlasTargetRef": {
                    "version": 2,
                    "kind": "stream",
                    "format": null,
                    "sealedRef": "AQID"
                },
                "name": "AIOStreams 🎬\n4K",
                "description": "Cached\n\n18.4 GB"
            }))
            .unwrap();
        let info = atlas_stream_info(
            formatted,
            &config,
            remote_addon_id,
            Some((extension_id, 7, remote_addon_id)),
        )
        .expect("formatted stream accepted");
        assert_eq!(
            info.name
                .as_deref(),
            Some("AIOStreams 🎬\n4K")
        );
        assert_eq!(
            info.description
                .as_deref(),
            Some("Cached\n\n18.4 GB")
        );

        let legacy: sdks::stremio::Stream = serde_json::from_value(serde_json::json!({
            "atlasTargetRef": {
                "version": 2,
                "kind": "stream",
                "format": null,
                "sealedRef": "AQID"
            },
            "title": "Legacy formatted title"
        }))
        .unwrap();
        let info = atlas_stream_info(
            legacy,
            &config,
            remote_addon_id,
            Some((extension_id, 7, remote_addon_id)),
        )
        .expect("legacy title accepted");
        assert_eq!(info.name, None);
        assert_eq!(
            info.description
                .as_deref(),
            Some("Legacy formatted title")
        );

        let direct: sdks::stremio::Stream = serde_json::from_value(serde_json::json!({
            "url": "https://media.example/video.mp4",
            "name": "AIOStreams 🎬\n4K",
            "description": "Cached\n\n18.4 GB"
        }))
        .unwrap();
        assert_eq!(
            stremio_presentation_fields(&direct),
            (
                Some("AIOStreams 🎬\n4K".to_string()),
                Some("Cached\n\n18.4 GB".to_string())
            )
        );
    }

    #[test]
    fn atlas_metadata_retains_only_body_image_targets() {
        let mut meta: sdks::stremio::Meta = serde_json::from_value(serde_json::json!({
            "id": "atlas:movie:1",
            "type": "movie",
            "name": "Owned",
            "poster": "http://169.254.169.254/latest/meta-data",
            "background": {
                "atlasTargetRef": {
                    "version": 2,
                    "kind": "image",
                    "format": null,
                    "sealedRef": "AQID"
                }
            },
            "trailers": [{"source": "https://provider.invalid/trailer"}]
        }))
        .unwrap();
        sanitize_atlas_meta(&mut meta, &atlas_config());
        assert!(
            meta.poster
                .is_none()
        );
        let (kind, format, sealed_ref) = meta
            .background
            .as_ref()
            .and_then(sdks::stremio::StremioImage::atlas_target)
            .and_then(sdks::stremio::AtlasTargetRef::parts)
            .unwrap();
        assert_eq!(kind, sdks::stremio::AtlasTargetKind::Image);
        assert_eq!(format, None);
        assert_eq!(sealed_ref, "AQID");
        assert!(
            meta.trailers
                .is_none()
        );
    }

    #[test]
    fn atlas_relation_ids_are_addon_scoped() {
        let addon_a = Uuid::from_u128(11);
        let addon_b = Uuid::from_u128(12);
        assert_ne!(
            tenant_relation_id(&db::MediaKind::Person, "alice", Some(addon_a)),
            tenant_relation_id(&db::MediaKind::Person, "alice", Some(addon_b)),
        );
    }

    #[test]
    fn manifest_url_strips_manifest_json_with_query_string() {
        let url = StremioManifestUrl::try_new(
            "https://example.com/path/manifest.json?apikey=abc",
        )
        .unwrap();
        assert!(
            !url.as_str()
                .contains("manifest.json"),
            "manifest.json not stripped: {url}"
        );
        assert!(
            url.as_str()
                .contains("apikey=abc"),
            "query string lost: {url}"
        );
    }

    #[test]
    fn manifest_url_strips_manifest_json_without_query_string() {
        let url = StremioManifestUrl::try_new("https://example.com/path/manifest.json")
            .unwrap();
        assert!(
            !url.as_str()
                .contains("manifest.json"),
            "manifest.json not stripped: {url}"
        );
    }

    fn mock_manifest(server: &httpmock::MockServer) {
        server.mock(|when, then| {
            when.path("/manifest.json");
            then.status(200)
                .json_body(serde_json::json!({
                    "id": "fankai-test",
                    "name": "Fankai",
                    "version": "1.0.0",
                    "resources": [
                        "catalog",
                        {"name": "meta", "types": ["anime"], "idPrefixes": ["fk"]}
                    ],
                    "types": ["anime"],
                    "catalogs": []
                }));
        });
    }

    #[tokio::test]
    async fn manifest_meta_type_fallback_retries_with_addon_declared_type() {
        let server = httpmock::MockServer::start();
        mock_manifest(&server);
        let series_attempt = server.mock(|when, then| {
            when.path("/meta/series/fk:27.json");
            then.status(404);
        });
        let anime_attempt = server.mock(|when, then| {
            when.path("/meta/anime/fk:27.json");
            then.status(200)
                .json_body(serde_json::json!({
                    "meta": {"id": "fk:27", "type": "anime", "name": "Bleach Yabai"}
                }));
        });

        let svc =
            stremio_service::StremioService::from_url(&server.base_url()).unwrap();

        // Confirm the generic type really does 404 first.
        let direct = svc
            .get_meta(sdks::stremio::MediaType::Series, "fk:27".to_string())
            .await;
        assert!(direct.is_err());
        series_attempt.assert();

        let meta = manifest_meta_type_fallback(
            &svc,
            &sdks::stremio::MediaType::Series,
            "fk:27",
        )
        .await;

        assert!(
            meta.is_some(),
            "fallback must find the addon's declared \"anime\" type"
        );
        assert_eq!(
            meta.unwrap()
                .get_name(),
            Some("Bleach Yabai".to_string())
        );
        anime_attempt.assert();
    }

    #[tokio::test]
    async fn manifest_meta_type_fallback_none_when_no_type_works() {
        let server = httpmock::MockServer::start();
        mock_manifest(&server);
        server.mock(|when, then| {
            when.path("/meta/anime/fk:999.json");
            then.status(404);
        });

        let svc =
            stremio_service::StremioService::from_url(&server.base_url()).unwrap();
        let meta = manifest_meta_type_fallback(
            &svc,
            &sdks::stremio::MediaType::Series,
            "fk:999",
        )
        .await;

        assert!(meta.is_none());
    }

    #[tokio::test]
    async fn manifest_meta_type_fallback_skips_non_matching_prefix() {
        let server = httpmock::MockServer::start();
        mock_manifest(&server);
        // "tt" is not covered by fankai's declared idPrefixes (["fk"]) — the
        // fallback must not even attempt the "anime" type for it.
        let anime_attempt = server.mock(|when, then| {
            when.path("/meta/anime/tt1234567.json");
            then.status(200)
                .json_body(serde_json::json!({
                    "meta": {"id": "tt1234567", "type": "anime", "name": "Should Not Match"}
                }));
        });

        let svc =
            stremio_service::StremioService::from_url(&server.base_url()).unwrap();
        let meta = manifest_meta_type_fallback(
            &svc,
            &sdks::stremio::MediaType::Series,
            "tt1234567",
        )
        .await;

        assert!(meta.is_none());
        anime_attempt.assert_hits(0);
    }

    fn episode_media(external_ids: db::ExternalIds) -> db::Media {
        db::Media {
            kind: db::MediaKind::Episode,
            parent_idx: Some(1),
            idx: Some(1),
            external_ids,
            ..Default::default()
        }
    }

    #[tokio::test]
    async fn stremio_streams_prefers_captured_video_id_over_reconstruction() {
        let server = httpmock::MockServer::start();
        let reconstructed = server.mock(|when, then| {
            when.path("/stream/anime/fk:27:1:1.json");
            then.status(404);
        });
        let captured = server.mock(|when, then| {
            when.path("/stream/anime/fk-ep-1.json");
            then.status(200)
                .json_body(serde_json::json!({"streams": [{"url": "https://example.com/1.mp4"}]}));
        });

        let svc =
            stremio_service::StremioService::from_url(&server.base_url()).unwrap();
        let manifest_url = StremioManifestUrl::try_new(server.base_url()).unwrap();
        let grandparent = db::Media {
            kind: db::MediaKind::Series,
            external_ids: db::ExternalIds {
                custom_stremio_id: Some("fk:27".to_string()),
                custom_stremio_type: Some("anime".to_string()),
                ..Default::default()
            },
            ..Default::default()
        };
        let mut media = episode_media(db::ExternalIds {
            custom_stremio_id: Some("fk-ep-1".to_string()),
            custom_stremio_type: Some("anime".to_string()),
            ..Default::default()
        });
        media.grandparent = Some(Box::new(grandparent));

        let streams = stremio_streams(
            &svc,
            &manifest_url,
            &media,
            None,
            &crate::Config::default(),
            Uuid::nil(),
        )
        .await
        .unwrap();

        assert_eq!(streams.len(), 1);
        captured.assert();
        reconstructed.assert_hits(0);
    }

    #[tokio::test]
    async fn stremio_streams_falls_back_to_reconstructed_id_when_uncaptured() {
        let server = httpmock::MockServer::start();
        let reconstructed = server.mock(|when, then| {
            when.path("/stream/anime/fk:27:1:1.json");
            then.status(200)
                .json_body(serde_json::json!({"streams": [{"url": "https://example.com/1.mp4"}]}));
        });

        let svc =
            stremio_service::StremioService::from_url(&server.base_url()).unwrap();
        let manifest_url = StremioManifestUrl::try_new(server.base_url()).unwrap();
        let grandparent = db::Media {
            kind: db::MediaKind::Series,
            external_ids: db::ExternalIds {
                custom_stremio_id: Some("fk:27".to_string()),
                custom_stremio_type: Some("anime".to_string()),
                ..Default::default()
            },
            ..Default::default()
        };
        let mut media = episode_media(db::ExternalIds {
            custom_stremio_type: Some("anime".to_string()),
            ..Default::default()
        });
        media.grandparent = Some(Box::new(grandparent));

        let streams = stremio_streams(
            &svc,
            &manifest_url,
            &media,
            None,
            &crate::Config::default(),
            Uuid::nil(),
        )
        .await
        .unwrap();

        assert_eq!(streams.len(), 1);
        reconstructed.assert();
    }
}
