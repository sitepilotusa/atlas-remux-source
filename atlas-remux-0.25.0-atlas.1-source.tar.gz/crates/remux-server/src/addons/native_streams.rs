// Shared stream refresh implementation. Upload-only roots have a separate stable namespace.
use super::*;

impl AddonService {
    pub(crate) async fn get_streams_scoped(
        &self,
        media: &db::Media,
        ctx: &AppContext,
        user_id: Option<Uuid>,
        uploads_only: bool,
    ) -> Result<Vec<db::Media>> {
        let addons = self
            .addons_for::<dyn StreamAddon>(media, &ctx.db, user_id)
            .await;

        debug!(
            media_id = %media.id,
            media_kind = ?media.kind,
            addon_count = addons.len(),
            "resolving streams"
        );

        let tasks: Vec<_> = addons
            .into_iter()
            .filter(|addon| !uploads_only || is_upload_source(
                &ctx.config, &addon.row.preset.kind, &addon.row.preset.config))
            .map(|r| async move {
                let name = &r.row.name;
                let t = std::time::Instant::now();
                let id_prefixes = r
                    .resource_id_prefixes(&ResourceType::Stream)
                    .map(|p| p.to_vec());
                match r
                    .stream
                    .as_ref()
                    .unwrap()
                    .get_streams(media, ctx, id_prefixes.as_deref())
                    .await
                {
                    Ok(mut streams) => {
                        let elapsed = t.elapsed();
                        if streams.is_empty() {
                            debug!(addon = %name, ?elapsed, "addon: no streams");
                        } else {
                            let sf = &r.row.service_filter;
                            if !sf.is_empty() {
                                streams.retain(|s| {
                                    s.service_id
                                        .as_ref()
                                        .map(|id| sf.contains(id))
                                        .unwrap_or(true)
                                });
                            }
                            debug!(addon = %name, count = streams.len(), ?elapsed, "addon: streams found");
                            let addon_id = r.row.id;
                            for s in &mut streams {
                                s.source = Some(name.clone());
                                s.addon_id = Some(addon_id);
                            }
                        }
                        StreamSourceOutcome::Succeeded(streams)
                    }
                    Err(e) => {
                        warn!(addon = %name, error = %e, elapsed = ?t.elapsed(), "stream addon failed");
                        StreamSourceOutcome::Failed
                    }
                }
            })
            .collect();
        let all: Vec<db::Media> =
            merge_stream_source_outcomes(futures::future::join_all(tasks).await)?
                .into_iter()
                .map(db::Media::from)
                .collect();
        Ok(all)
    }

    pub(crate) async fn refresh_streams_scoped(
        &self,
        media: &mut db::Media,
        ctx: &AppContext,
        user_id: Option<Uuid>,
        uploads_only: bool,
    ) -> Result<()> {
        const STREAMS_TTL_SECS: i64 = 60;
        static STREAM_LOCKS: KeyedLock<Uuid> = KeyedLock::new();

        // Fast path: TTL not expired — skip the lock entirely.
        let is_fresh = |refreshed: Option<chrono::NaiveDateTime>| {
            refreshed.is_some_and(|r| {
                (chrono::Utc::now().naive_utc() - r).num_seconds() < STREAMS_TTL_SECS
            })
        };
        if is_fresh(media.streams_refreshed_at) {
            return Ok(());
        }

        // Acquire per-media lock to prevent concurrent refreshes.
        let _guard = STREAM_LOCKS
            .lock(media.id)
            .await;

        // Re-check after acquiring lock — another task may have just refreshed.
        let refreshed_at = sqlx::query_scalar::<_, Option<chrono::NaiveDateTime>>(
            "SELECT streams_refreshed_at FROM media WHERE id = ?",
        )
        .bind(media.id)
        .fetch_optional(&ctx.db)
        .await
        .ok()
        .flatten()
        .flatten();
        if is_fresh(refreshed_at) {
            media.streams_refreshed_at = refreshed_at;
            return Ok(());
        }

        media
            .grandparent(&ctx.db)
            .await
            .ok();

        let instant = Instant::now();
        let probe_versions_fut = external_probe_unless_atlas(
            ctx.config
                .atlas_remux_patched_tenant_auth,
            async {
                let Some(url) = ctx
                    .config
                    .remuxdb_url
                    .clone()
                else {
                    return None;
                };
                let imdb_id = if media.kind == db::MediaKind::Episode {
                    media
                        .grandparent
                        .as_deref()
                        .and_then(|gp| {
                            gp.external_ids
                                .imdb
                                .as_deref()
                        })
                        .or(media
                            .external_ids
                            .imdb
                            .as_deref())
                } else {
                    media
                        .external_ids
                        .imdb
                        .as_deref()
                };
                let Some(imdb_id) = imdb_id else {
                    return None;
                };
                let cfg = db::Settings::get_config_or_default(&ctx.db).await;
                if !cfg
                    .remuxdb_enabled
                    .unwrap_or(true)
                {
                    return None;
                }
                let (season, episode) = if media.kind == db::MediaKind::Episode {
                    (
                        media
                            .parent_idx
                            .map(|v| v as i32),
                        media
                            .idx
                            .map(|v| v as i32),
                    )
                } else {
                    (None, None)
                };
                remuxdb::fetch_probe(
                    &url,
                    cfg.remuxdb_token
                        .as_deref(),
                    Some(crate::common::server_id().as_str()),
                    imdb_id,
                    season,
                    episode,
                )
                .await
            },
        );
        let probe_t = std::time::Instant::now();
        let (raw, probe_versions) = tokio::join!(
            self.get_streams_scoped(media, ctx, user_id, uploads_only),
            tokio::time::timeout(
                std::time::Duration::from_secs(10),
                probe_versions_fut,
            )
        );
        let raw = raw?;
        let probe_versions = match probe_versions {
            Ok(v) => v,
            Err(_) => {
                debug!(remuxdb_elapsed = ?probe_t.elapsed(), "remuxdb probe timed out");
                None
            }
        };
        debug!(
            raw_count = raw.len(),
            remuxdb_elapsed = ?probe_t.elapsed(),
            "raw streams fetched"
        );

        // Dedup by descriptor content; order preserves addon priority (DB load order).
        // First occurrence wins, so higher-priority addons' streams survive.
        let mut seen = std::collections::HashSet::new();
        let mut deduped: Vec<db::Media> = raw
            .into_iter()
            .filter(|s| match Self::stream_dedup_key(s) {
                Some(key) => seen.insert(key),
                None => true,
            })
            .collect();

        // Atlas streams contain short-lived opaque relay capabilities. Keeping
        // every historical token would grow the global media table without a
        // useful replay path and would retain revoked targets. A tenant root is
        // add-on namespaced, so replacing its bounded current set cannot remove
        // another add-on's or another tenant's sources.
        if ctx
            .config
            .atlas_remux_patched_tenant_auth
        {
            const MAX_ATLAS_STREAMS_PER_MEDIA: usize = 1_024;
            deduped.truncate(MAX_ATLAS_STREAMS_PER_MEDIA);
            sqlx::query("DELETE FROM media WHERE kind = 'stream' AND parent_id = ?")
                .bind(media.id)
                .execute(&ctx.db)
                .await?;
        }

        let sources: Vec<&str> = {
            let mut seen = std::collections::HashSet::new();
            deduped
                .iter()
                .filter_map(|m| {
                    m.stream_info
                        .as_ref()?
                        .source
                        .as_deref()
                })
                .filter(|s| seen.insert(*s))
                .collect()
        };
        info!(streams = deduped.len(), ?sources, elapsed = ?instant.elapsed(), "streams synced");
        if deduped.is_empty() {
            if ctx
                .config
                .atlas_remux_patched_tenant_auth
            {
                let now = chrono::Utc::now().naive_utc();
                sqlx::query("UPDATE media SET streams_refreshed_at = ? WHERE id = ?")
                    .bind(now)
                    .bind(media.id)
                    .execute(&ctx.db)
                    .await?;
                media.streams_refreshed_at = Some(now);
            }
            return Ok(());
        }

        let now = chrono::Utc::now().naive_utc();
        sqlx::query("UPDATE media SET streams_refreshed_at = ? WHERE id = ?")
            .bind(now)
            .bind(media.id)
            .execute(&ctx.db)
            .await?;
        media.streams_refreshed_at = Some(now);
        let mut sources: Vec<db::Media> = deduped
            .into_iter()
            .enumerate()
            .map(|(idx, mut s)| {
                // Stable ID derived from content so the same stream always maps to
                // the same UUID across refreshes, enabling safe upsert semantics.
                let id_key = Self::stream_dedup_key(&s)
                    .unwrap_or_else(|| format!("source_{idx}"));
                s.id = Uuid::new_v5(&media.id, id_key.as_bytes());
                s.parent_id = Some(media.id);
                s.runtime = media.runtime;
                s.idx = Some(idx as i64);
                s.created_at = now;
                s.updated_at = now;
                s
            })
            .collect();

        if let Some(ref versions) = probe_versions {
            for source in &mut sources {
                if source
                    .probe_data
                    .is_some()
                {
                    continue;
                }
                if let Some(version) = match_probe_version(versions, source) {
                    source.probe_data = Some(version.into());
                    debug!(id = %source.id, "remuxdb: probe data applied from version");
                }
            }
        }

        db::Media::upsert(&ctx.db, &sources).await?;

        if !ctx
            .config
            .atlas_remux_patched_tenant_auth
        {
            // delete stale items
            sqlx::query(
                "DELETE FROM media WHERE kind = 'stream' AND parent_id = ? AND updated_at < datetime('now', '-7 days')",
            )
            .bind(media.id)
            .execute(&ctx.db)
            .await?;
        }
        Ok(())
    }
}

// A provider cannot opt into the upload lane through its name or stream descriptor.
fn is_upload_source(
    config: &crate::Config,
    kind: &str,
    preset: &serde_json::Value,
) -> bool {
    config.atlas_remux_patched_tenant_auth
        && kind == "stremio"
        && preset
            .get("manifest_url")
            .and_then(serde_json::Value::as_str)
            .filter(|marker| {
                db::atlas_tenant::source_manifest_target(config, marker).is_some()
            })
            .and_then(|marker| url::Url::parse(marker).ok())
            .is_some_and(|marker| {
                marker
                    .path()
                    .starts_with("/.well-known/atlas-source/")
            })
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn upload_scope_excludes_extension_and_external_addons() {
        let config = crate::Config {
            atlas_remux_patched_tenant_auth: true,
            atlas_extension_relay_origin: Some("https://relay.atlas.invalid".into()),
            ..Default::default()
        };
        let source = "https://relay.atlas.invalid/.well-known/atlas-source/11000000-0000-4000-8000-000000000001/1/manifest.json";
        let preset = serde_json::json!({"manifest_url": source});
        assert!(is_upload_source(&config, "stremio", &preset));
        assert!(!is_upload_source(&config, "torznab", &preset));
        assert!(!is_upload_source(
            &crate::Config::default(),
            "stremio",
            &preset
        ));
        for marker in [
            source.replace("atlas-source", "atlas-extension"),
            source.replace("relay.atlas.invalid", "provider.invalid"),
            format!("{source}?secret=test"),
            "https://provider.invalid/manifest.json".into(),
        ] {
            assert!(!is_upload_source(
                &config,
                "stremio",
                &serde_json::json!({"manifest_url": marker})
            ));
        }
    }
}
