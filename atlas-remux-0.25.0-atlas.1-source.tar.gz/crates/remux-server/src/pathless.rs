//! Fixed Pathless V2 backchannel transport for Atlas-mode Remux.
//!
//! This module deliberately exposes no generic URL, method, header, or redirect
//! knobs.  Callers choose one of the four compiled protocol boundaries and
//! receive only a verified status and raw JSON body.

use std::{
    collections::{HashMap, HashSet},
    fmt,
    time::{Duration, SystemTime, UNIX_EPOCH},
};

use base64::{Engine as _, engine::general_purpose::URL_SAFE_NO_PAD};
use futures_util::StreamExt;
use hmac::{Hmac, Mac};
use rand::{RngCore, rngs::OsRng};
use reqwest::{StatusCode, header};
use serde::Serialize;
use sha2::{Digest, Sha256};
use url::{Host, Url};
use zeroize::Zeroize;

use crate::Config;

const AUTH_WINDOW_SECONDS: i64 = 10;
const KEY_BYTES: usize = 32;
const NONCE_BYTES: usize = 16;
const SIGNATURE_BYTES: usize = 32;

const REQUEST_KEY_ID: &str = "x-atlas-pop-key-id";
const REQUEST_TIMESTAMP: &str = "x-atlas-pop-timestamp";
const REQUEST_NONCE: &str = "x-atlas-pop-nonce";
const REQUEST_BODY_HASH: &str = "x-atlas-pop-body-sha256";
const REQUEST_SIGNATURE: &str = "x-atlas-pop-signature";
const RESPONSE_REQUEST_NONCE: &str = "x-atlas-pop-request-nonce";
const RESPONSE_EXPIRES: &str = "x-atlas-pop-response-expires";

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum Boundary {
    Source,
    Media,
    Extension,
    Target,
}

impl Boundary {
    pub const fn domain(self) -> &'static str {
        match self {
            Self::Source => "atlas-remux-source-v2",
            Self::Media => "atlas-remux-media-v2",
            Self::Extension => "atlas-remux-extension-v2",
            Self::Target => "atlas-remux-target-v2",
        }
    }

    pub const fn path(self) -> &'static str {
        match self {
            Self::Source => "/api/cloud/v1/internal/pathless/source-json",
            Self::Media => "/api/cloud/v1/internal/pathless/media-redeem",
            Self::Extension => "/v2/extension-json",
            Self::Target => "/v2/extension-target-redeem",
        }
    }

    pub const fn request_limit(self) -> usize {
        match self {
            Self::Source | Self::Media => 4_096,
            Self::Extension | Self::Target => 8_192,
        }
    }

    pub const fn response_limit(self) -> usize {
        match self {
            Self::Source | Self::Extension => 2 * 1_024 * 1_024,
            Self::Media | Self::Target => 8_192,
        }
    }
}

/// A secret environment value. Its formatter is intentionally content-free,
/// and Config skips it during JSON serialization.
#[derive(Clone, serde::Deserialize)]
#[serde(transparent)]
pub struct SecretSetting(String);

impl SecretSetting {
    fn expose(&self) -> &str {
        &self.0
    }

    #[cfg(test)]
    pub(crate) fn test_key(byte: u8) -> Self {
        Self(format!("v1:{}", URL_SAFE_NO_PAD.encode([byte; KEY_BYTES])))
    }
}

impl fmt::Debug for SecretSetting {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter.write_str("[redacted]")
    }
}

impl Drop for SecretSetting {
    fn drop(&mut self) {
        self.0
            .zeroize();
    }
}

#[derive(Clone)]
struct Keyring {
    keys: HashMap<String, [u8; KEY_BYTES]>,
}

impl Drop for Keyring {
    fn drop(&mut self) {
        for key in self
            .keys
            .values_mut()
        {
            key.zeroize();
        }
    }
}

#[derive(Clone)]
struct BoundaryKeys {
    request: Keyring,
    response: Keyring,
    active: String,
}

#[derive(Clone)]
pub struct Client {
    api_origin: String,
    relay_origin: String,
    http: reqwest::Client,
    source: BoundaryKeys,
    media: BoundaryKeys,
    extension: BoundaryKeys,
    target: BoundaryKeys,
    r2_account_id: String,
    r2_bucket: String,
    r2_access_key_id: String,
}

pub struct SignedResponse {
    pub status: StatusCode,
    pub body: Vec<u8>,
}

#[derive(Debug)]
pub struct Error;

impl fmt::Display for Error {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter.write_str("Atlas Pathless request failed")
    }
}

impl std::error::Error for Error {}

impl Client {
    pub fn from_config(config: &Config) -> Result<Self, Error> {
        if !config.atlas_remux_patched_tenant_auth {
            return Err(Error);
        }
        let api_origin = exact_public_origin(
            config
                .atlas_pathless_api_origin
                .as_deref()
                .ok_or(Error)?,
        )?;
        let relay_origin = exact_public_origin(
            config
                .atlas_extension_relay_origin
                .as_deref()
                .ok_or(Error)?,
        )?;
        let source = boundary_keys(
            config
                .atlas_pathless_remux_source_request_keyring
                .as_ref(),
            config
                .atlas_pathless_remux_source_response_keyring
                .as_ref(),
            config
                .atlas_pathless_remux_source_active_key_id
                .as_deref(),
        )?;
        let media = boundary_keys(
            config
                .atlas_pathless_remux_media_request_keyring
                .as_ref(),
            config
                .atlas_pathless_remux_media_response_keyring
                .as_ref(),
            config
                .atlas_pathless_remux_media_active_key_id
                .as_deref(),
        )?;
        let extension = boundary_keys(
            config
                .atlas_pathless_remux_extension_request_keyring
                .as_ref(),
            config
                .atlas_pathless_remux_extension_response_keyring
                .as_ref(),
            config
                .atlas_pathless_remux_extension_active_key_id
                .as_deref(),
        )?;
        let target = boundary_keys(
            config
                .atlas_pathless_remux_target_request_keyring
                .as_ref(),
            config
                .atlas_pathless_remux_target_response_keyring
                .as_ref(),
            config
                .atlas_pathless_remux_target_active_key_id
                .as_deref(),
        )?;
        require_unique_material([&source, &media, &extension, &target])?;
        let r2_account_id = config
            .atlas_cloud_r2_account_id
            .as_deref()
            .filter(|value| {
                value.len() == 32
                    && value
                        .bytes()
                        .all(|byte| {
                            byte.is_ascii_hexdigit() && !byte.is_ascii_uppercase()
                        })
            })
            .ok_or(Error)?
            .to_string();
        let r2_bucket = config
            .atlas_cloud_r2_bucket
            .as_deref()
            .filter(|value| valid_r2_bucket(value))
            .ok_or(Error)?
            .to_string();
        let r2_access_key_id = config
            .atlas_cloud_r2_access_key_id
            .as_deref()
            .filter(|value| {
                (16..=128).contains(&value.len())
                    && value
                        .bytes()
                        .all(|byte| byte.is_ascii_alphanumeric())
            })
            .ok_or(Error)?
            .to_string();
        let http = reqwest::Client::builder()
            .redirect(reqwest::redirect::Policy::none())
            .connect_timeout(Duration::from_secs(2))
            .timeout(Duration::from_secs(8))
            .build()
            .map_err(|_| Error)?;
        Ok(Self {
            api_origin,
            relay_origin,
            http,
            source,
            media,
            extension,
            target,
            r2_account_id,
            r2_bucket,
            r2_access_key_id,
        })
    }

    pub async fn post<T: Serialize>(
        &self,
        boundary: Boundary,
        body: &T,
    ) -> Result<SignedResponse, Error> {
        self.post_inner(boundary, body, false)
            .await
    }

    pub async fn post_extension_probe<T: Serialize>(
        &self,
        body: &T,
    ) -> Result<SignedResponse, Error> {
        self.post_inner(Boundary::Extension, body, true)
            .await
    }

    async fn post_inner<T: Serialize>(
        &self,
        boundary: Boundary,
        body: &T,
        allow_probe_invalid_manifest: bool,
    ) -> Result<SignedResponse, Error> {
        let body = serde_json::to_vec(body).map_err(|_| Error)?;
        if body.is_empty() || body.len() > boundary.request_limit() {
            return Err(Error);
        }
        let origin = match boundary {
            Boundary::Source | Boundary::Media => &self.api_origin,
            Boundary::Extension | Boundary::Target => &self.relay_origin,
        };
        let keys = self.keys(boundary);
        let request_key = keys
            .request
            .keys
            .get(&keys.active)
            .ok_or(Error)?;
        let timestamp = unix_seconds()?;
        let mut nonce_bytes = [0_u8; NONCE_BYTES];
        OsRng.fill_bytes(&mut nonce_bytes);
        let nonce = URL_SAFE_NO_PAD.encode(nonce_bytes);
        nonce_bytes.zeroize();
        let body_hash = sha256_hex(&body);
        let canonical = [
            boundary.domain(),
            "v2",
            "request",
            &keys.active,
            "POST",
            boundary.path(),
            &timestamp.to_string(),
            &nonce,
            &body_hash,
        ]
        .join("\0");
        let signature = hmac_base64url(request_key, canonical.as_bytes())?;
        let response = self
            .http
            .post(format!("{origin}{}", boundary.path()))
            .header(header::CONTENT_TYPE, "application/json")
            .header("X-Atlas-PoP-Key-Id", &keys.active)
            .header("X-Atlas-PoP-Timestamp", timestamp.to_string())
            .header("X-Atlas-PoP-Nonce", &nonce)
            .header("X-Atlas-PoP-Body-SHA256", &body_hash)
            .header("X-Atlas-PoP-Signature", signature)
            .body(body)
            .send()
            .await
            .map_err(|_| Error)?;
        verify_response_surface(
            &response,
            boundary,
            allow_probe_invalid_manifest,
            boundary.response_limit(),
        )?;
        let status = response.status();
        let response_headers = response
            .headers()
            .clone();
        let mut stream = response.bytes_stream();
        let mut response_body = Vec::new();
        while let Some(chunk) = stream
            .next()
            .await
        {
            let chunk = chunk.map_err(|_| Error)?;
            if response_body
                .len()
                .saturating_add(chunk.len())
                > boundary.response_limit()
            {
                response_body.zeroize();
                return Err(Error);
            }
            response_body.extend_from_slice(&chunk);
        }
        verify_response(
            boundary,
            keys,
            &nonce,
            status,
            &response_headers,
            &response_body,
        )?;
        Ok(SignedResponse {
            status,
            body: response_body,
        })
    }

    fn keys(&self, boundary: Boundary) -> &BoundaryKeys {
        match boundary {
            Boundary::Source => &self.source,
            Boundary::Media => &self.media,
            Boundary::Extension => &self.extension,
            Boundary::Target => &self.target,
        }
    }

    pub async fn redeem_media(
        &self,
        target: &crate::stream::AtlasMediaDescriptor,
        method: &str,
        range: Option<&str>,
    ) -> Result<String, Error> {
        if !matches!(method, "GET" | "HEAD")
            || method == "HEAD" && range.is_some()
            || range.is_some_and(|value| !valid_canonical_range(value))
            || target.generation == 0
            || target.generation > i32::MAX as u32
        {
            return Err(Error);
        }
        let response = self
            .post(
                Boundary::Media,
                &MediaRequest {
                    version: 2,
                    source_binding_id: target.source_binding_id,
                    generation: target.generation,
                    remote_addon_id: target.remote_addon_id,
                    media_id: target.media_id,
                    method,
                    range,
                },
            )
            .await?;
        if response.status != StatusCode::OK {
            return Err(Error);
        }
        let parsed: SuccessEnvelope<MediaData> =
            serde_json::from_slice(&response.body).map_err(|_| Error)?;
        if parsed.version != 2
            || parsed
                .data
                .method
                != method
            || !self.valid_r2_location(
                &parsed
                    .data
                    .location,
                method,
                range,
                parsed
                    .data
                    .expires_at,
            )
        {
            return Err(Error);
        }
        Ok(parsed
            .data
            .location)
    }

    pub async fn redeem_extension_target(
        &self,
        target: &crate::stream::AtlasExtensionDescriptor,
        method: &str,
    ) -> Result<String, Error> {
        if !matches!(method, "GET" | "HEAD")
            || target.generation == 0
            || target.generation > i32::MAX as u32
        {
            return Err(Error);
        }
        let kind = target_kind(target.kind);
        let format = target
            .format
            .map(subtitle_format);
        if kind == "subtitle" && format.is_none()
            || kind != "subtitle" && format.is_some()
        {
            return Err(Error);
        }
        let response = self
            .post(
                Boundary::Target,
                &TargetRequest {
                    version: 2,
                    extension_id: target.extension_id,
                    generation: target.generation,
                    remote_addon_id: target.remote_addon_id,
                    kind,
                    format,
                    method,
                    sealed_ref: target.sealed_ref(),
                },
            )
            .await?;
        if response.status != StatusCode::OK {
            return Err(Error);
        }
        let parsed: SuccessEnvelope<TargetData> =
            serde_json::from_slice(&response.body).map_err(|_| Error)?;
        if parsed.version != 2
            || parsed
                .data
                .kind
                != kind
            || parsed
                .data
                .format
                .as_deref()
                != format
            || !self.valid_provider_location(
                &parsed
                    .data
                    .location,
                kind,
                format,
            )
        {
            return Err(Error);
        }
        Ok(parsed
            .data
            .location)
    }

    fn valid_provider_location(
        &self,
        raw: &str,
        kind: &str,
        format: Option<&str>,
    ) -> bool {
        if !(10..=2_048).contains(&raw.len()) {
            return false;
        }
        let Ok(parsed) = Url::parse(raw) else {
            return false;
        };
        let host = match parsed.host() {
            Some(Host::Domain(host)) => host.to_ascii_lowercase(),
            _ => return false,
        };
        let blocked_name = host == "localhost"
            || host.ends_with(".localhost")
            || host.ends_with(".local")
            || host.ends_with(".internal")
            || host.ends_with(".flycast")
            || host.ends_with(".r2.cloudflarestorage.com");
        let blocked_origin = [
            self.api_origin
                .as_str(),
            self.relay_origin
                .as_str(),
        ]
        .contains(
            &parsed
                .origin()
                .ascii_serialization()
                .as_str(),
        );
        if parsed.scheme() != "https"
            || parsed.username() != ""
            || parsed
                .password()
                .is_some()
            || parsed
                .port()
                .is_some()
            || parsed
                .fragment()
                .is_some()
            || parsed.as_str() != raw
            || blocked_name
            || blocked_origin
        {
            return false;
        }
        kind != "subtitle"
            || format.is_some_and(|format| {
                parsed
                    .path()
                    .to_ascii_lowercase()
                    .ends_with(&format!(".{format}"))
            })
    }

    fn valid_r2_location(
        &self,
        raw: &str,
        method: &str,
        range: Option<&str>,
        expires_at: i64,
    ) -> bool {
        if raw.len() > 4_096 || raw.contains('#') {
            return false;
        }
        let Ok(parsed) = Url::parse(raw) else {
            return false;
        };
        let expected_origin = format!(
            "https://{}.{}.r2.cloudflarestorage.com",
            self.r2_bucket, self.r2_account_id
        );
        if parsed
            .origin()
            .ascii_serialization()
            != expected_origin
            || parsed.username() != ""
            || parsed
                .password()
                .is_some()
            || parsed
                .port()
                .is_some()
            || parsed
                .fragment()
                .is_some()
            || parsed.as_str() != raw
            || parsed
                .path()
                .contains('%')
            || parsed
                .path()
                .contains("//")
            || !valid_r2_path(parsed.path())
        {
            return false;
        }
        let expected_keys: &[&str] = if method == "GET" {
            &[
                "X-Amz-Algorithm",
                "X-Amz-Content-Sha256",
                "X-Amz-Credential",
                "X-Amz-Date",
                "X-Amz-Expires",
                "X-Amz-Signature",
                "X-Amz-SignedHeaders",
                "x-amz-checksum-mode",
                "x-id",
            ]
        } else {
            &[
                "X-Amz-Algorithm",
                "X-Amz-Content-Sha256",
                "X-Amz-Credential",
                "X-Amz-Date",
                "X-Amz-Expires",
                "X-Amz-Signature",
                "X-Amz-SignedHeaders",
            ]
        };
        let raw_entries: Vec<_> = parsed
            .query()
            .unwrap_or_default()
            .split('&')
            .collect();
        if raw_entries.len() != expected_keys.len()
            || raw_entries
                .iter()
                .any(|entry| {
                    let Some((key, value)) = entry.split_once('=') else {
                        return true;
                    };
                    key.is_empty() || value.is_empty() || !expected_keys.contains(&key)
                })
        {
            return false;
        }
        let entries: Vec<_> = parsed
            .query_pairs()
            .map(|(key, value)| (key.into_owned(), value.into_owned()))
            .collect();
        let mut params = HashMap::new();
        for (key, value) in entries {
            if !expected_keys.contains(&key.as_str())
                || params
                    .insert(key, value)
                    .is_some()
            {
                return false;
            }
        }
        if params.len() != expected_keys.len() {
            return false;
        }
        let Some(date) = params.get("X-Amz-Date") else {
            return false;
        };
        let Ok(signing) = chrono::NaiveDateTime::parse_from_str(date, "%Y%m%dT%H%M%SZ")
            .map(|value| {
                value
                    .and_utc()
                    .timestamp()
            })
        else {
            return false;
        };
        let Ok(now) = unix_seconds() else {
            return false;
        };
        let scope_date = date
            .get(..8)
            .unwrap_or_default();
        let signed_headers = if method == "GET" && range.is_some() {
            "host;range"
        } else {
            "host"
        };
        signing <= now + AUTH_WINDOW_SECONDS
            && signing + 90 >= now
            && expires_at == signing + 90
            && params
                .get("X-Amz-Algorithm")
                .map(String::as_str)
                == Some("AWS4-HMAC-SHA256")
            && params
                .get("X-Amz-Content-Sha256")
                .map(String::as_str)
                == Some("UNSIGNED-PAYLOAD")
            && params.get("X-Amz-Credential")
                == Some(&format!(
                    "{}/{scope_date}/auto/s3/aws4_request",
                    self.r2_access_key_id
                ))
            && params
                .get("X-Amz-Expires")
                .map(String::as_str)
                == Some("90")
            && params
                .get("X-Amz-SignedHeaders")
                .map(String::as_str)
                == Some(signed_headers)
            && params
                .get("X-Amz-Signature")
                .is_some_and(|signature| {
                    signature.len() == 64
                        && signature
                            .bytes()
                            .all(|byte| {
                                byte.is_ascii_hexdigit() && !byte.is_ascii_uppercase()
                            })
                })
            && (method != "GET"
                || params
                    .get("x-amz-checksum-mode")
                    .map(String::as_str)
                    == Some("ENABLED")
                    && params
                        .get("x-id")
                        .map(String::as_str)
                        == Some("GetObject"))
    }
}

#[derive(Serialize)]
struct MediaRequest<'a> {
    version: u8,
    #[serde(rename = "sourceBindingId")]
    source_binding_id: uuid::Uuid,
    generation: u32,
    #[serde(rename = "remoteAddonId")]
    remote_addon_id: uuid::Uuid,
    #[serde(rename = "mediaId")]
    media_id: uuid::Uuid,
    method: &'a str,
    range: Option<&'a str>,
}

#[derive(serde::Deserialize)]
#[serde(deny_unknown_fields)]
struct SuccessEnvelope<T> {
    version: u8,
    data: T,
}

#[derive(serde::Deserialize)]
#[serde(deny_unknown_fields)]
struct MediaData {
    location: String,
    method: String,
    #[serde(rename = "expiresAt")]
    expires_at: i64,
}

#[derive(Serialize)]
struct TargetRequest<'a> {
    version: u8,
    #[serde(rename = "extensionId")]
    extension_id: uuid::Uuid,
    generation: u32,
    #[serde(rename = "remoteAddonId")]
    remote_addon_id: uuid::Uuid,
    kind: &'a str,
    format: Option<&'a str>,
    method: &'a str,
    #[serde(rename = "sealedRef")]
    sealed_ref: &'a str,
}

#[derive(serde::Deserialize)]
#[serde(deny_unknown_fields)]
struct TargetData {
    location: String,
    kind: String,
    format: Option<String>,
}

fn exact_public_origin(raw: &str) -> Result<String, Error> {
    let parsed = Url::parse(raw).map_err(|_| Error)?;
    let host = match parsed.host() {
        Some(Host::Domain(host)) => host.to_ascii_lowercase(),
        _ => return Err(Error),
    };
    if parsed.scheme() != "https"
        || parsed.username() != ""
        || parsed
            .password()
            .is_some()
        || parsed
            .port()
            .is_some()
        || parsed.path() != "/"
        || parsed
            .query()
            .is_some()
        || parsed
            .fragment()
            .is_some()
        || parsed
            .origin()
            .ascii_serialization()
            != raw
        || host == "localhost"
        || host.ends_with(".localhost")
        || host.ends_with(".local")
        || host.ends_with(".internal")
        || host.ends_with(".flycast")
    {
        return Err(Error);
    }
    Ok(raw.to_string())
}

fn boundary_keys(
    request: Option<&SecretSetting>,
    response: Option<&SecretSetting>,
    active: Option<&str>,
) -> Result<BoundaryKeys, Error> {
    let request = parse_keyring(
        request
            .ok_or(Error)?
            .expose(),
    )?;
    let response = parse_keyring(
        response
            .ok_or(Error)?
            .expose(),
    )?;
    let active = active.ok_or(Error)?;
    if !valid_key_id(active)
        || !request
            .keys
            .contains_key(active)
        || !response
            .keys
            .contains_key(active)
        || request
            .keys
            .values()
            .any(|left| {
                response
                    .keys
                    .values()
                    .any(|right| left == right)
            })
    {
        return Err(Error);
    }
    Ok(BoundaryKeys {
        request,
        response,
        active: active.to_string(),
    })
}

fn parse_keyring(raw: &str) -> Result<Keyring, Error> {
    if raw.is_empty()
        || raw.trim() != raw
        || raw
            .bytes()
            .any(|byte| byte.is_ascii_whitespace())
    {
        return Err(Error);
    }
    let entries: Vec<_> = raw
        .split(',')
        .collect();
    if !(1..=2).contains(&entries.len()) {
        return Err(Error);
    }
    let mut keys = HashMap::new();
    for entry in entries {
        let (id, encoded) = entry
            .split_once(':')
            .ok_or(Error)?;
        if !valid_key_id(id) || encoded.len() != 43 || keys.contains_key(id) {
            return Err(Error);
        }
        let decoded = URL_SAFE_NO_PAD
            .decode(encoded)
            .map_err(|_| Error)?;
        if decoded.len() != KEY_BYTES || URL_SAFE_NO_PAD.encode(&decoded) != encoded {
            return Err(Error);
        }
        let mut key = [0_u8; KEY_BYTES];
        key.copy_from_slice(&decoded);
        if keys
            .values()
            .any(|observed| observed == &key)
        {
            key.zeroize();
            return Err(Error);
        }
        keys.insert(id.to_string(), key);
    }
    Ok(Keyring { keys })
}

fn require_unique_material<'a>(
    boundaries: impl IntoIterator<Item = &'a BoundaryKeys>,
) -> Result<(), Error> {
    let mut seen = HashSet::new();
    for boundary in boundaries {
        for key in boundary
            .request
            .keys
            .values()
            .chain(
                boundary
                    .response
                    .keys
                    .values(),
            )
        {
            if !seen.insert(*key) {
                return Err(Error);
            }
        }
    }
    Ok(())
}

fn valid_key_id(value: &str) -> bool {
    let Some(digits) = value.strip_prefix('v') else {
        return false;
    };
    !digits.is_empty()
        && digits.len() <= 10
        && !digits.starts_with('0')
        && digits
            .bytes()
            .all(|byte| byte.is_ascii_digit())
}

fn verify_response_surface(
    response: &reqwest::Response,
    boundary: Boundary,
    allow_probe_invalid_manifest: bool,
    maximum_bytes: usize,
) -> Result<(), Error> {
    let status = response
        .status()
        .as_u16();
    if !response_status_allowed(boundary, allow_probe_invalid_manifest, status)
        || exact_header(response.headers(), header::CONTENT_TYPE.as_str())?
            .to_ascii_lowercase()
            != "application/json"
        || response
            .headers()
            .contains_key(header::CONTENT_ENCODING)
    {
        return Err(Error);
    }
    if let Some(length) = response.content_length()
        && usize::try_from(length).map_err(|_| Error)? > maximum_bytes
    {
        return Err(Error);
    }
    let allowed = [
        REQUEST_KEY_ID,
        RESPONSE_REQUEST_NONCE,
        RESPONSE_EXPIRES,
        REQUEST_BODY_HASH,
        REQUEST_SIGNATURE,
    ];
    for name in response
        .headers()
        .keys()
    {
        let lower = name
            .as_str()
            .to_ascii_lowercase();
        if lower.starts_with("x-atlas-pop-") && !allowed.contains(&lower.as_str()) {
            return Err(Error);
        }
    }
    Ok(())
}

fn response_status_allowed(
    boundary: Boundary,
    allow_probe_invalid_manifest: bool,
    status: u16,
) -> bool {
    matches!(status, 200 | 401 | 404 | 409 | 429 | 503)
        || boundary == Boundary::Extension
            && allow_probe_invalid_manifest
            && status == 422
}

fn verify_response(
    boundary: Boundary,
    keys: &BoundaryKeys,
    request_nonce: &str,
    status: StatusCode,
    headers: &header::HeaderMap,
    body: &[u8],
) -> Result<(), Error> {
    let key_id = exact_header(headers, REQUEST_KEY_ID)?;
    let observed_nonce = exact_header(headers, RESPONSE_REQUEST_NONCE)?;
    let expires_text = exact_header(headers, RESPONSE_EXPIRES)?;
    let body_hash = exact_header(headers, REQUEST_BODY_HASH)?;
    let signature = exact_header(headers, REQUEST_SIGNATURE)?;
    if observed_nonce != request_nonce
        || !valid_key_id(key_id)
        || body_hash.len() != 64
        || !body_hash
            .bytes()
            .all(|byte| byte.is_ascii_hexdigit() && !byte.is_ascii_uppercase())
        || sha256_hex(body) != body_hash
    {
        return Err(Error);
    }
    let expires = canonical_positive(expires_text)?;
    let now = unix_seconds()?;
    if expires < now || expires > now + AUTH_WINDOW_SECONDS {
        return Err(Error);
    }
    let key = keys
        .response
        .keys
        .get(key_id)
        .ok_or(Error)?;
    let canonical = [
        boundary.domain(),
        "v2",
        "response",
        key_id,
        request_nonce,
        &status
            .as_u16()
            .to_string(),
        &expires.to_string(),
        body_hash,
    ]
    .join("\0");
    let decoded = URL_SAFE_NO_PAD
        .decode(signature)
        .map_err(|_| Error)?;
    if decoded.len() != SIGNATURE_BYTES || URL_SAFE_NO_PAD.encode(&decoded) != signature
    {
        return Err(Error);
    }
    let mut mac = Hmac::<Sha256>::new_from_slice(key).map_err(|_| Error)?;
    mac.update(canonical.as_bytes());
    mac.verify_slice(&decoded)
        .map_err(|_| Error)
}

fn exact_header<'a>(
    headers: &'a header::HeaderMap,
    name: &str,
) -> Result<&'a str, Error> {
    let mut values = headers
        .get_all(name)
        .iter();
    let value = values
        .next()
        .ok_or(Error)?;
    if values
        .next()
        .is_some()
    {
        return Err(Error);
    }
    let value = value
        .to_str()
        .map_err(|_| Error)?;
    if value.is_empty() || value.contains(',') {
        return Err(Error);
    }
    Ok(value)
}

fn unix_seconds() -> Result<i64, Error> {
    i64::try_from(
        SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .map_err(|_| Error)?
            .as_secs(),
    )
    .map_err(|_| Error)
}

fn canonical_positive(value: &str) -> Result<i64, Error> {
    if value.is_empty()
        || value.starts_with('0')
        || !value
            .bytes()
            .all(|byte| byte.is_ascii_digit())
    {
        return Err(Error);
    }
    let parsed = value
        .parse::<i64>()
        .map_err(|_| Error)?;
    (parsed > 0)
        .then_some(parsed)
        .ok_or(Error)
}

fn sha256_hex(body: &[u8]) -> String {
    format!("{:x}", Sha256::digest(body))
}

fn hmac_base64url(key: &[u8], body: &[u8]) -> Result<String, Error> {
    let mut mac = Hmac::<Sha256>::new_from_slice(key).map_err(|_| Error)?;
    mac.update(body);
    Ok(URL_SAFE_NO_PAD.encode(
        mac.finalize()
            .into_bytes(),
    ))
}

fn valid_r2_bucket(value: &str) -> bool {
    (3..=63).contains(&value.len())
        && value
            .bytes()
            .all(|byte| {
                byte.is_ascii_lowercase()
                    || byte.is_ascii_digit()
                    || matches!(byte, b'.' | b'-')
            })
        && value
            .bytes()
            .next()
            .is_some_and(|byte| byte.is_ascii_lowercase() || byte.is_ascii_digit())
        && value
            .bytes()
            .last()
            .is_some_and(|byte| byte.is_ascii_lowercase() || byte.is_ascii_digit())
        && !value.contains("..")
}

fn valid_r2_path(path: &str) -> bool {
    let pieces: Vec<_> = path
        .split('/')
        .collect();
    if pieces.len() != 6
        || pieces[0] != ""
        || pieces[1] != "accounts"
        || pieces[3] != "media"
        || !matches!(
            pieces[5],
            "source.mp4" | "source.webm" | "source.mov" | "source.mkv"
        )
    {
        return false;
    }
    canonical_uuid(pieces[2]) && canonical_uuid(pieces[4])
}

fn canonical_uuid(value: &str) -> bool {
    uuid::Uuid::parse_str(value)
        .ok()
        .is_some_and(|parsed| {
            parsed.to_string() == value
                && parsed.get_variant() == uuid::Variant::RFC4122
                && (1..=8).contains(&parsed.get_version_num())
        })
}

pub fn valid_canonical_range(value: &str) -> bool {
    if value.len() > 64 {
        return false;
    }
    let Some(spec) = value.strip_prefix("bytes=") else {
        return false;
    };
    if spec.contains(',') {
        return false;
    }
    if let Some(suffix) = spec.strip_prefix('-') {
        return canonical_decimal(suffix) && suffix != "0";
    }
    let Some((start, end)) = spec.split_once('-') else {
        return false;
    };
    if !canonical_decimal(start) || !end.is_empty() && !canonical_decimal(end) {
        return false;
    }
    if end.is_empty() {
        return true;
    }
    let Ok(start) = start.parse::<u64>() else {
        return false;
    };
    let Ok(end) = end.parse::<u64>() else {
        return false;
    };
    start <= end
}

fn canonical_decimal(value: &str) -> bool {
    !value.is_empty()
        && value.len() <= 19
        && value
            .bytes()
            .all(|byte| byte.is_ascii_digit())
        && (value == "0" || !value.starts_with('0'))
}

fn target_kind(kind: remux_sdks::stremio::AtlasTargetKind) -> &'static str {
    match kind {
        remux_sdks::stremio::AtlasTargetKind::Image => "image",
        remux_sdks::stremio::AtlasTargetKind::Stream => "stream",
        remux_sdks::stremio::AtlasTargetKind::Subtitle => "subtitle",
    }
}

fn subtitle_format(format: remux_sdks::stremio::AtlasSubtitleFormat) -> &'static str {
    format.as_str()
}

#[cfg(test)]
mod tests {
    use super::*;

    fn client() -> Client {
        Client::from_config(&Config {
            atlas_remux_patched_tenant_auth: true,
            atlas_pathless_api_origin: Some("https://api.atlas.invalid".to_string()),
            atlas_extension_relay_origin: Some(
                "https://relay.atlas.invalid".to_string(),
            ),
            ..Default::default()
        })
        .expect("test Pathless client must instantiate")
    }

    #[test]
    fn atlas_pathless_boundaries_and_range_grammar_are_exact() {
        assert_eq!(Boundary::Source.domain(), "atlas-remux-source-v2");
        assert_eq!(
            Boundary::Source.path(),
            "/api/cloud/v1/internal/pathless/source-json"
        );
        assert_eq!(Boundary::Media.domain(), "atlas-remux-media-v2");
        assert_eq!(
            Boundary::Media.path(),
            "/api/cloud/v1/internal/pathless/media-redeem"
        );
        assert_eq!(Boundary::Extension.domain(), "atlas-remux-extension-v2");
        assert_eq!(Boundary::Extension.path(), "/v2/extension-json");
        assert_eq!(Boundary::Target.domain(), "atlas-remux-target-v2");
        assert_eq!(Boundary::Target.path(), "/v2/extension-target-redeem");
        assert_eq!(Boundary::Source.request_limit(), 4_096);
        assert_eq!(Boundary::Extension.request_limit(), 8_192);
        assert_eq!(Boundary::Media.response_limit(), 8_192);
        assert_eq!(Boundary::Extension.response_limit(), 2 * 1_024 * 1_024);
        assert!(response_status_allowed(Boundary::Extension, true, 422));
        assert!(!response_status_allowed(Boundary::Extension, false, 422));
        for boundary in [Boundary::Source, Boundary::Media, Boundary::Target] {
            assert!(!response_status_allowed(boundary, true, 422));
        }

        for accepted in ["bytes=0-0", "bytes=0-", "bytes=-1", "bytes=-999"] {
            assert!(valid_canonical_range(accepted), "{accepted}");
        }
        for rejected in [
            "Bytes=0-1",
            "bytes=01-2",
            "bytes=2-1",
            "bytes=-0",
            "bytes=0-1,2-3",
            "bytes=",
            "bytes=0",
            "bytes=0-99999999999999999999",
        ] {
            assert!(!valid_canonical_range(rejected), "{rejected}");
        }
    }

    #[test]
    fn atlas_pathless_configuration_is_unique_fixed_and_redacted() {
        let client = client();
        assert_eq!(client.api_origin, "https://api.atlas.invalid");
        assert_eq!(client.relay_origin, "https://relay.atlas.invalid");
        let secret = SecretSetting::test_key(91);
        assert_eq!(format!("{secret:?}"), "[redacted]");

        for api_origin in [
            "http://api.atlas.invalid",
            "https://api.atlas.invalid/path",
            "https://user@api.atlas.invalid",
            "https://127.0.0.1",
            "https://service.internal",
        ] {
            let config = Config {
                atlas_remux_patched_tenant_auth: true,
                atlas_pathless_api_origin: Some(api_origin.to_string()),
                atlas_extension_relay_origin: Some(
                    "https://relay.atlas.invalid".to_string(),
                ),
                ..Default::default()
            };
            assert!(Client::from_config(&config).is_err(), "{api_origin}");
        }
        assert!(Client::from_config(&Config::default()).is_err());

        let duplicate = SecretSetting::test_key(2);
        let config = Config {
            atlas_remux_patched_tenant_auth: true,
            atlas_pathless_api_origin: Some("https://api.atlas.invalid".to_string()),
            atlas_extension_relay_origin: Some(
                "https://relay.atlas.invalid".to_string(),
            ),
            atlas_pathless_remux_source_request_keyring: Some(duplicate),
            ..Default::default()
        };
        assert!(Client::from_config(&config).is_err());

        for invalid in [
            "",
            " v1:AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA",
            "v0:AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA",
            "v1:not-canonical",
        ] {
            assert!(parse_keyring(invalid).is_err(), "{invalid}");
        }
    }

    #[test]
    fn atlas_pathless_terminal_locations_are_closed_and_method_bound() {
        let client = client();
        assert!(client.valid_provider_location(
            "https://cdn.provider.invalid/video/owner.m3u8?ticket=opaque",
            "stream",
            None,
        ));
        assert!(client.valid_provider_location(
            "https://cdn.provider.invalid/subtitles/owner.srt?ticket=opaque",
            "subtitle",
            Some("srt"),
        ));
        for invalid in [
            "http://cdn.provider.invalid/video",
            "https://127.0.0.1/video",
            "https://service.internal/video",
            "https://api.atlas.invalid/private",
            "https://relay.atlas.invalid/private",
            "https://bucket.account.r2.cloudflarestorage.com/private",
            "https://user@cdn.provider.invalid/video",
            "https://cdn.provider.invalid:8443/video",
            "https://cdn.provider.invalid/video#fragment",
        ] {
            assert!(
                !client.valid_provider_location(invalid, "stream", None),
                "{invalid}"
            );
        }
        assert!(!client.valid_provider_location(
            "https://cdn.provider.invalid/subtitles/owner.srt",
            "subtitle",
            Some("vtt"),
        ));

        let now = unix_seconds().unwrap();
        let date = chrono::DateTime::from_timestamp(now, 0)
            .unwrap()
            .format("%Y%m%dT%H%M%SZ")
            .to_string();
        let scope = &date[..8];
        let path = "/accounts/11111111-1111-4111-8111-111111111111/media/22222222-2222-4222-8222-222222222222/source.mp4";
        let base = format!(
            "https://atlas-cloud-media.0123456789abcdef0123456789abcdef.r2.cloudflarestorage.com{path}"
        );
        let common = format!(
            "X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=ACCESSKEY1234567890/{scope}/auto/s3/aws4_request&X-Amz-Date={date}&X-Amz-Expires=90&X-Amz-Signature={}&X-Amz-SignedHeaders=",
            "a".repeat(64),
        );
        let get = format!(
            "{base}?{common}host%3Brange&x-amz-checksum-mode=ENABLED&x-id=GetObject"
        );
        assert!(client.valid_r2_location(&get, "GET", Some("bytes=0-99"), now + 90));
        assert!(!client.valid_r2_location(&get, "GET", None, now + 90));
        assert!(!client.valid_r2_location(&get, "HEAD", None, now + 90));
        assert!(!client.valid_r2_location(
            &get.replace("X-Amz-Expires=90", "X-Amz-Expires=91"),
            "GET",
            Some("bytes=0-99"),
            now + 90,
        ));
        assert!(!client.valid_r2_location(
            &get.replace(
                "11111111-1111-4111-8111-111111111111",
                "00000000-0000-0000-0000-000000000000",
            ),
            "GET",
            Some("bytes=0-99"),
            now + 90,
        ));
        assert!(!client.valid_r2_location(
            &get.replace("X-Amz-Date=", "X-Amz%2DDate="),
            "GET",
            Some("bytes=0-99"),
            now + 90,
        ));

        let head = format!("{base}?{common}host");
        assert!(client.valid_r2_location(&head, "HEAD", None, now + 90));
        assert!(!client.valid_r2_location(&head, "GET", None, now + 90));
    }

    #[test]
    fn atlas_pathless_response_pop_binds_nonce_status_expiry_and_raw_body() {
        let client = client();
        let boundary = Boundary::Source;
        let keys = client.keys(boundary);
        let key_id = keys
            .active
            .as_str();
        let request_nonce = URL_SAFE_NO_PAD.encode([7_u8; NONCE_BYTES]);
        let status = StatusCode::OK;
        let body = br#"{"version":2,"data":{}}"#;
        let body_hash = sha256_hex(body);
        let expires = unix_seconds().unwrap() + AUTH_WINDOW_SECONDS;
        let expires_text = expires.to_string();
        let status_text = status
            .as_u16()
            .to_string();
        let canonical = [
            boundary.domain(),
            "v2",
            "response",
            key_id,
            &request_nonce,
            &status_text,
            &expires_text,
            &body_hash,
        ]
        .join("\0");
        let signature = hmac_base64url(
            keys.response
                .keys
                .get(key_id)
                .unwrap(),
            canonical.as_bytes(),
        )
        .unwrap();
        let mut headers = header::HeaderMap::new();
        for (name, value) in [
            (REQUEST_KEY_ID, key_id),
            (RESPONSE_REQUEST_NONCE, request_nonce.as_str()),
            (RESPONSE_EXPIRES, expires_text.as_str()),
            (REQUEST_BODY_HASH, body_hash.as_str()),
            (REQUEST_SIGNATURE, signature.as_str()),
        ] {
            headers.insert(
                header::HeaderName::from_bytes(name.as_bytes()).unwrap(),
                header::HeaderValue::from_str(value).unwrap(),
            );
        }
        verify_response(boundary, keys, &request_nonce, status, &headers, body)
            .expect("exact response PoP must verify");

        let mut tampered = headers.clone();
        tampered.insert(
            REQUEST_BODY_HASH,
            header::HeaderValue::from_static(
                "0000000000000000000000000000000000000000000000000000000000000000",
            ),
        );
        assert!(
            verify_response(boundary, keys, &request_nonce, status, &tampered, body,)
                .is_err()
        );
        assert!(
            verify_response(
                boundary,
                keys,
                &URL_SAFE_NO_PAD.encode([8_u8; NONCE_BYTES]),
                status,
                &headers,
                body,
            )
            .is_err()
        );
    }
}
