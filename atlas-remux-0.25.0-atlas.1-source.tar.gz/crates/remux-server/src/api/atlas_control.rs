// Atlas modification, 2026-08-20.
//
// This is a Fly-private reconciliation endpoint.  The public gateway is the
// only component that owns the Remux administrator token and it calls this
// endpoint only after the separately signed API authorization exchange.

use std::{ops::Deref, sync::LazyLock};

use axum::{
    body::{Body, to_bytes},
    extract::{FromRequestParts, Request, State},
    http::{HeaderMap, Method, Response, StatusCode, header},
    middleware::Next,
};
use bytes::{Bytes, BytesMut};
use chrono::Utc;
use regex::Regex;
use serde::{Deserialize, Deserializer, Serialize, Serializer};
use sha2::{Digest, Sha256};
use sqlx::{Row, SqliteConnection};
use uuid::{Uuid, Variant};
use zeroize::Zeroize;

use crate::{
    AppState,
    addons::{Addon, AddonPresetRef, ResourceType},
    db::{self, auth::AdminSession},
};

const PRIVATE_PATH: &str = "/api/atlas/v2/control/reconcile";
const PRIVATE_REQUEST_BYTES: usize = 8_192;
const PRIVATE_RESPONSE_BYTES: usize = 16_384;
const PRIVATE_DIGEST_DOMAIN: &[u8] = b"atlas-remux-control-private-command-v2\0";
const ADDON_COLUMNS: &str = "id, name, preset, resources, types, enabled, priority, \
    created_at, updated_at, system, is_default, http_redirect_stream, service_filter";

static USERNAME_PATTERN: LazyLock<Regex> =
    LazyLock::new(|| Regex::new(r"^atlas_[A-Za-z0-9_-]{24}$").unwrap());
static DIGEST_PATTERN: LazyLock<Regex> =
    LazyLock::new(|| Regex::new(r"^[0-9a-f]{64}$").unwrap());
static PASSWORD_PATTERN: LazyLock<Regex> =
    LazyLock::new(|| Regex::new(r"^[A-Za-z0-9_-]{43}$").unwrap());

struct SensitiveBody(BytesMut);

impl SensitiveBody {
    fn new(bytes: Bytes) -> Self {
        Self(
            bytes
                .try_into_mut()
                .unwrap_or_else(BytesMut::from),
        )
    }
}

impl Deref for SensitiveBody {
    type Target = [u8];

    fn deref(&self) -> &Self::Target {
        self.0
            .as_ref()
    }
}

impl Drop for SensitiveBody {
    fn drop(&mut self) {
        self.0
            .as_mut()
            .zeroize();
    }
}

struct SensitiveVec(Vec<u8>);

impl Deref for SensitiveVec {
    type Target = [u8];

    fn deref(&self) -> &Self::Target {
        self.0
            .as_slice()
    }
}

impl Drop for SensitiveVec {
    fn drop(&mut self) {
        self.0
            .zeroize();
    }
}

struct SecretString(String);

impl SecretString {
    fn expose(&self) -> &str {
        &self.0
    }
}

impl Serialize for SecretString {
    fn serialize<S>(&self, serializer: S) -> Result<S::Ok, S::Error>
    where
        S: Serializer,
    {
        serializer.serialize_str(&self.0)
    }
}

impl<'de> Deserialize<'de> for SecretString {
    fn deserialize<D>(deserializer: D) -> Result<Self, D::Error>
    where
        D: Deserializer<'de>,
    {
        String::deserialize(deserializer).map(Self)
    }
}

impl Drop for SecretString {
    fn drop(&mut self) {
        self.0
            .zeroize();
    }
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(tag = "kind", rename_all = "lowercase", deny_unknown_fields)]
pub enum AtlasMarker {
    Source {
        #[serde(rename = "sourceBindingId")]
        source_binding_id: Uuid,
        generation: u32,
    },
    Extension {
        #[serde(rename = "extensionId")]
        extension_id: Uuid,
        generation: u32,
    },
}

#[derive(Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
enum ControlResource {
    Catalog,
    Meta,
    Stream,
    Subtitles,
}

impl ControlResource {
    fn as_str(self) -> &'static str {
        match self {
            Self::Catalog => "catalog",
            Self::Meta => "meta",
            Self::Stream => "stream",
            Self::Subtitles => "subtitles",
        }
    }

    fn to_remux(self) -> ResourceType {
        match self {
            Self::Catalog => ResourceType::Catalog,
            Self::Meta => ResourceType::Meta,
            Self::Stream => ResourceType::Stream,
            Self::Subtitles => ResourceType::Subtitles,
        }
    }
}

#[derive(Serialize, Deserialize)]
#[serde(tag = "action", rename_all = "snake_case", deny_unknown_fields)]
enum PrivateCommand {
    Health,
    StartupStatus,
    FindUser {
        username: String,
        #[serde(rename = "credentialSecretId")]
        credential_secret_id: Uuid,
        #[serde(rename = "credentialGeneration")]
        credential_generation: u32,
    },
    GetUser {
        #[serde(rename = "userId")]
        user_id: Uuid,
    },
    CreateUser {
        username: String,
        #[serde(rename = "credentialSecretId")]
        credential_secret_id: Uuid,
        #[serde(rename = "credentialGeneration")]
        credential_generation: u32,
        password: SecretString,
    },
    DeleteUser {
        #[serde(rename = "userId")]
        user_id: Uuid,
    },
    RevokeUserSessions {
        #[serde(rename = "userId")]
        user_id: Uuid,
    },
    FindAddon {
        marker: AtlasMarker,
        name: String,
    },
    GetAddon {
        #[serde(rename = "addonId")]
        addon_id: Uuid,
        marker: AtlasMarker,
    },
    ProbeAddon {
        #[serde(rename = "addonId")]
        addon_id: Uuid,
        marker: AtlasMarker,
        #[serde(rename = "operationId")]
        operation_id: Uuid,
        #[serde(rename = "attemptId")]
        attempt_id: Uuid,
    },
    CreateAddon {
        marker: AtlasMarker,
        name: String,
        resources: Vec<ControlResource>,
        types: Vec<String>,
    },
    UpdateAddon {
        #[serde(rename = "addonId")]
        addon_id: Uuid,
        marker: AtlasMarker,
        name: String,
        resources: Vec<ControlResource>,
        types: Vec<String>,
    },
    DeleteAddon {
        #[serde(rename = "addonId")]
        addon_id: Uuid,
        marker: AtlasMarker,
    },
    GetUserAddons {
        #[serde(rename = "userId")]
        user_id: Uuid,
    },
    SetUserAddons {
        #[serde(rename = "userId")]
        user_id: Uuid,
        #[serde(rename = "addonIds")]
        addon_ids: Vec<Uuid>,
    },
}

impl PrivateCommand {
    fn action(&self) -> &'static str {
        match self {
            Self::Health => "health",
            Self::StartupStatus => "startup_status",
            Self::FindUser { .. } => "find_user",
            Self::GetUser { .. } => "get_user",
            Self::CreateUser { .. } => "create_user",
            Self::DeleteUser { .. } => "delete_user",
            Self::RevokeUserSessions { .. } => "revoke_user_sessions",
            Self::FindAddon { .. } => "find_addon",
            Self::GetAddon { .. } => "get_addon",
            Self::ProbeAddon { .. } => "probe_addon",
            Self::CreateAddon { .. } => "create_addon",
            Self::UpdateAddon { .. } => "update_addon",
            Self::DeleteAddon { .. } => "delete_addon",
            Self::GetUserAddons { .. } => "get_user_addons",
            Self::SetUserAddons { .. } => "set_user_addons",
        }
    }

    fn reloads_addons(&self) -> bool {
        matches!(
            self,
            Self::CreateAddon { .. }
                | Self::UpdateAddon { .. }
                | Self::DeleteAddon { .. }
        )
    }
}

#[derive(Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct PrivateControlRequest {
    version: u8,
    #[serde(rename = "remuxBindingId")]
    remux_binding_id: Uuid,
    #[serde(rename = "accountRemuxBindingId")]
    account_remux_binding_id: Uuid,
    #[serde(rename = "operationId")]
    operation_id: Uuid,
    command: PrivateCommand,
    #[serde(rename = "privateCommandSHA256")]
    private_command_sha256: SecretString,
}

#[derive(Serialize)]
struct PrivateCore<'a> {
    version: u8,
    #[serde(rename = "remuxBindingId")]
    remux_binding_id: Uuid,
    #[serde(rename = "accountRemuxBindingId")]
    account_remux_binding_id: Uuid,
    #[serde(rename = "operationId")]
    operation_id: Uuid,
    command: &'a PrivateCommand,
}

#[derive(Serialize)]
struct UserResult {
    id: Uuid,
    name: String,
}

#[derive(Serialize)]
struct AddonResult {
    id: Uuid,
    kind: &'static str,
    name: String,
    marker: AtlasMarker,
    resources: Vec<ControlResource>,
    types: Vec<String>,
    enabled: bool,
    #[serde(rename = "isDefault")]
    is_default: bool,
    #[serde(rename = "httpRedirectStream")]
    http_redirect_stream: bool,
}

#[derive(Serialize)]
#[serde(untagged)]
enum ActionResult {
    Health {
        healthy: bool,
    },
    StartupStatus {
        #[serde(rename = "startupComplete")]
        startup_complete: bool,
        version: &'static str,
    },
    User {
        user: Option<UserResult>,
    },
    Addon {
        addon: Option<AddonResult>,
    },
    Completed {
        completed: bool,
    },
    AddonIds {
        #[serde(rename = "addonIds")]
        addon_ids: Vec<Uuid>,
    },
}

struct ControlSuccess {
    body: Vec<u8>,
    reload_addons: bool,
}

#[derive(Debug)]
struct ControlFailure;

fn failed(_stage: &'static str) -> ControlFailure {
    ControlFailure
}

pub async fn reconcile(
    State(state): State<AppState>,
    request: Request,
) -> Response<Body> {
    if !private_surface_is_exact(&request) {
        return empty_response(StatusCode::NOT_FOUND);
    }

    let (mut parts, body) = request.into_parts();
    if AdminSession::from_request_parts(&mut parts, &state)
        .await
        .is_err()
    {
        return empty_response(StatusCode::NOT_FOUND);
    }

    let expected_length = match canonical_content_length(&parts.headers) {
        Some(length) => length,
        None => return empty_response(StatusCode::NOT_FOUND),
    };
    let bytes = match to_bytes(body, PRIVATE_REQUEST_BYTES).await {
        Ok(bytes) if bytes.len() == expected_length => bytes,
        _ => return empty_response(StatusCode::SERVICE_UNAVAILABLE),
    };
    let raw = SensitiveBody::new(bytes);

    let outcome = execute(&state, &raw).await;
    match outcome {
        Ok(success) => {
            if success.reload_addons
                && state
                    .ctx
                    .addons
                    .reload(
                        &state
                            .ctx
                            .db,
                        &state
                            .ctx
                            .config,
                    )
                    .await
                    .is_err()
            {
                return empty_response(StatusCode::SERVICE_UNAVAILABLE);
            }
            json_response(success.body)
        }
        Err(_) => empty_response(StatusCode::SERVICE_UNAVAILABLE),
    }
}

pub async fn retired_namespace() -> Response<Body> {
    empty_response(StatusCode::NOT_FOUND)
}

pub fn has_retired_header(headers: &HeaderMap) -> bool {
    let name = ["x", "atlas", "remux", "gateway"].join("-");
    headers
        .keys()
        .any(|candidate| candidate.as_str() == name)
}

pub async fn retire_legacy_header(request: Request, next: Next) -> Response<Body> {
    let namespace = ["", "_atlas"].join("/");
    if has_retired_header(request.headers())
        || request
            .uri()
            .path()
            == namespace
        || request
            .uri()
            .path()
            .starts_with(&format!("{namespace}/"))
    {
        empty_response(StatusCode::NOT_FOUND)
    } else {
        next.run(request)
            .await
    }
}

fn private_surface_is_exact(request: &Request) -> bool {
    if request.method() != Method::POST
        || request
            .uri()
            .path()
            != PRIVATE_PATH
        || request
            .uri()
            .query()
            .is_some()
        || request
            .headers()
            .contains_key(header::TRANSFER_ENCODING)
        || request
            .headers()
            .contains_key(header::CONTENT_ENCODING)
        || request
            .headers()
            .contains_key("x-emby-authorization")
        || request
            .headers()
            .contains_key("x-emby-token")
        || request
            .headers()
            .contains_key("x-mediabrowser-token")
        || exact_header(request.headers(), header::CONTENT_TYPE)
            != Some("application/json")
    {
        return false;
    }

    canonical_content_length(request.headers()).is_some()
}

fn exact_header<'a>(
    headers: &'a HeaderMap,
    name: header::HeaderName,
) -> Option<&'a str> {
    let mut values = headers
        .get_all(name)
        .iter();
    let value = values
        .next()?
        .to_str()
        .ok()?;
    if values
        .next()
        .is_some()
        || value.is_empty()
        || value.contains(',')
    {
        return None;
    }
    Some(value)
}

fn canonical_content_length(headers: &HeaderMap) -> Option<usize> {
    let value = exact_header(headers, header::CONTENT_LENGTH)?;
    if value.is_empty()
        || !value
            .bytes()
            .all(|byte| byte.is_ascii_digit())
        || value.len() > 1 && value.starts_with('0')
    {
        return None;
    }
    let length = value
        .parse::<usize>()
        .ok()?;
    (2..=PRIVATE_REQUEST_BYTES)
        .contains(&length)
        .then_some(length)
}

fn empty_response(status: StatusCode) -> Response<Body> {
    Response::builder()
        .status(status)
        .header(header::CACHE_CONTROL, "no-store")
        .header(header::CONTENT_LENGTH, "0")
        .body(Body::empty())
        .expect("static private control response")
}

fn json_response(body: Vec<u8>) -> Response<Body> {
    Response::builder()
        .status(StatusCode::OK)
        .header(header::CONTENT_TYPE, "application/json")
        .header(
            header::CONTENT_LENGTH,
            body.len()
                .to_string(),
        )
        .header(header::CACHE_CONTROL, "no-store")
        .body(Body::from(body))
        .expect("bounded private control response")
}

async fn execute(
    state: &AppState,
    raw: &[u8],
) -> Result<ControlSuccess, ControlFailure> {
    if !state
        .ctx
        .config
        .atlas_remux_patched_tenant_auth
    {
        return Err(failed("feature"));
    }

    let request: PrivateControlRequest =
        serde_json::from_slice(raw).map_err(|_| failed("parse"))?;
    validate_request(&request).map_err(|_| failed("validate"))?;

    // Re-serialization pins top-level and command key order, rejects duplicate
    // keys, non-canonical UUIDs/numbers, whitespace variants, and alternate JSON
    // escaping before the digest is considered.
    let canonical =
        SensitiveVec(serde_json::to_vec(&request).map_err(|_| failed("canonicalize"))?);
    if &*canonical != raw {
        return Err(failed("canonical"));
    }

    let core = PrivateCore {
        version: request.version,
        remux_binding_id: request.remux_binding_id,
        account_remux_binding_id: request.account_remux_binding_id,
        operation_id: request.operation_id,
        command: &request.command,
    };
    let private_core =
        SensitiveVec(serde_json::to_vec(&core).map_err(|_| failed("core"))?);
    let mut hasher = Sha256::new();
    hasher.update(PRIVATE_DIGEST_DOMAIN);
    hasher.update(&*private_core);
    let mut observed_digest = format!("{:x}", hasher.finalize());
    let digest_matches = observed_digest
        == request
            .private_command_sha256
            .expose();
    observed_digest.zeroize();
    if !digest_matches {
        return Err(failed("digest"));
    }

    if matches!(&request.command, PrivateCommand::ProbeAddon { .. }) {
        return execute_probe(state, &request).await;
    }

    let precomputed_password_hash = match &request.command {
        PrivateCommand::CreateUser { password, .. } => Some(
            db::User::hash_password(password.expose()).map_err(|_| ControlFailure)?,
        ),
        _ => None,
    };

    let mut connection = state
        .ctx
        .db
        .acquire()
        .await
        .map_err(|_| failed("pool"))?;
    sqlx::query("BEGIN IMMEDIATE")
        .execute(&mut *connection)
        .await
        .map_err(|_| failed("begin"))?;

    let transaction_result = execute_transaction(
        &mut connection,
        &state
            .ctx
            .config,
        &request,
        precomputed_password_hash.as_deref(),
    )
    .await;

    match transaction_result {
        Ok(body) => {
            if sqlx::query("COMMIT")
                .execute(&mut *connection)
                .await
                .is_err()
            {
                let _ = sqlx::query("ROLLBACK")
                    .execute(&mut *connection)
                    .await;
                return Err(ControlFailure);
            }
            Ok(ControlSuccess {
                body,
                reload_addons: request
                    .command
                    .reloads_addons(),
            })
        }
        Err(failure) => {
            let _ = sqlx::query("ROLLBACK")
                .execute(&mut *connection)
                .await;
            Err(failure)
        }
    }
}

fn validate_request(request: &PrivateControlRequest) -> Result<(), ControlFailure> {
    if request.version != 2
        || !valid_uuid(request.remux_binding_id)
        || !valid_uuid(request.account_remux_binding_id)
        || !valid_uuid(request.operation_id)
        || !DIGEST_PATTERN.is_match(
            request
                .private_command_sha256
                .expose(),
        )
    {
        return Err(ControlFailure);
    }

    match &request.command {
        PrivateCommand::Health | PrivateCommand::StartupStatus => Ok(()),
        PrivateCommand::FindUser {
            username,
            credential_secret_id,
            credential_generation,
        } => validate_user_binding(
            username,
            *credential_secret_id,
            *credential_generation,
        ),
        PrivateCommand::CreateUser {
            username,
            credential_secret_id,
            credential_generation,
            password,
        } => {
            validate_user_binding(
                username,
                *credential_secret_id,
                *credential_generation,
            )?;
            if !PASSWORD_PATTERN.is_match(password.expose())
                || !canonical_base64url(password.expose(), 32)
            {
                return Err(ControlFailure);
            }
            Ok(())
        }
        PrivateCommand::GetUser { user_id }
        | PrivateCommand::DeleteUser { user_id }
        | PrivateCommand::RevokeUserSessions { user_id }
        | PrivateCommand::GetUserAddons { user_id } => valid_uuid(*user_id)
            .then_some(())
            .ok_or(ControlFailure),
        PrivateCommand::FindAddon { marker, name } => {
            validate_marker(marker)?;
            valid_addon_name(name)
                .then_some(())
                .ok_or(ControlFailure)
        }
        PrivateCommand::GetAddon { addon_id, marker }
        | PrivateCommand::DeleteAddon { addon_id, marker } => {
            if !valid_uuid(*addon_id) {
                return Err(ControlFailure);
            }
            validate_marker(marker)
        }
        PrivateCommand::ProbeAddon {
            addon_id,
            marker,
            operation_id,
            attempt_id,
        } => {
            if !valid_uuid(*addon_id)
                || !valid_uuid(*operation_id)
                || !valid_uuid(*attempt_id)
                || *operation_id != request.operation_id
                || !matches!(marker, AtlasMarker::Extension { .. })
            {
                return Err(ControlFailure);
            }
            validate_marker(marker)
        }
        PrivateCommand::CreateAddon {
            marker,
            name,
            resources,
            types,
        } => validate_addon_binding(marker, name, resources, types),
        PrivateCommand::UpdateAddon {
            addon_id,
            marker,
            name,
            resources,
            types,
        } => {
            if !valid_uuid(*addon_id) {
                return Err(ControlFailure);
            }
            validate_addon_binding(marker, name, resources, types)
        }
        PrivateCommand::SetUserAddons { user_id, addon_ids } => {
            if !valid_uuid(*user_id)
                || addon_ids.is_empty()
                || addon_ids.len() > 128
                || !addon_ids
                    .iter()
                    .copied()
                    .all(valid_uuid)
                || !addon_ids
                    .windows(2)
                    .all(|pair| pair[0].to_string() < pair[1].to_string())
            {
                return Err(ControlFailure);
            }
            Ok(())
        }
    }
}

fn validate_user_binding(
    username: &str,
    credential_secret_id: Uuid,
    credential_generation: u32,
) -> Result<(), ControlFailure> {
    if !USERNAME_PATTERN.is_match(username)
        || !valid_uuid(credential_secret_id)
        || !(1..=i32::MAX as u32).contains(&credential_generation)
    {
        return Err(ControlFailure);
    }
    Ok(())
}

fn validate_addon_binding(
    marker: &AtlasMarker,
    name: &str,
    resources: &[ControlResource],
    types: &[String],
) -> Result<(), ControlFailure> {
    validate_marker(marker)?;
    if !valid_addon_name(name)
        || resources.is_empty()
        || resources.len() > 4
        || !resources
            .windows(2)
            .all(|pair| pair[0].as_str() < pair[1].as_str())
        || types.is_empty()
        || types.len() > 2
        || !types
            .windows(2)
            .all(|pair| pair[0] < pair[1])
        || types
            .iter()
            .any(|value| remux_media_kind(value).is_none())
    {
        return Err(ControlFailure);
    }
    Ok(())
}

fn valid_addon_name(value: &str) -> bool {
    if value.is_empty() || value.trim() != value {
        return false;
    }
    let mut characters = 0;
    for character in value.chars() {
        characters += 1;
        if characters > 200
            || character.is_control()
            || matches!(
                character,
                '\u{202a}'..='\u{202e}' | '\u{2066}'..='\u{2069}'
            )
        {
            return false;
        }
    }
    let lower = value.to_ascii_lowercase();
    !lower.contains("://")
        && !lower.contains("token=")
        && !lower.contains("api_key=")
        && !lower.contains("access_token=")
}

fn validate_marker(marker: &AtlasMarker) -> Result<(), ControlFailure> {
    let (id, generation) = match marker {
        AtlasMarker::Source {
            source_binding_id,
            generation,
        } => (*source_binding_id, *generation),
        AtlasMarker::Extension {
            extension_id,
            generation,
        } => (*extension_id, *generation),
    };
    if !valid_uuid(id) || !(1..=i32::MAX as u32).contains(&generation) {
        return Err(ControlFailure);
    }
    Ok(())
}

fn valid_uuid(value: Uuid) -> bool {
    (1..=8).contains(&value.get_version_num())
        && value.get_variant() == Variant::RFC4122
}

fn canonical_base64url(value: &str, expected_bytes: usize) -> bool {
    use base64::{Engine as _, engine::general_purpose::URL_SAFE_NO_PAD};

    URL_SAFE_NO_PAD
        .decode(value)
        .ok()
        .is_some_and(|bytes| {
            bytes.len() == expected_bytes && URL_SAFE_NO_PAD.encode(bytes) == value
        })
}

async fn execute_probe(
    state: &AppState,
    request: &PrivateControlRequest,
) -> Result<ControlSuccess, ControlFailure> {
    let PrivateCommand::ProbeAddon {
        addon_id,
        marker,
        operation_id,
        attempt_id,
    } = &request.command
    else {
        return Err(ControlFailure);
    };
    let AtlasMarker::Extension {
        extension_id,
        generation,
    } = marker
    else {
        return Err(ControlFailure);
    };

    let mut connection = state
        .ctx
        .db
        .acquire()
        .await
        .map_err(|_| failed("probe-pool"))?;
    get_addon(
        &mut connection,
        &state
            .ctx
            .config,
        *addon_id,
        marker,
    )
    .await?
    .ok_or(ControlFailure)?;
    drop(connection);

    let healthy = crate::services::stremio::probe_pathless_extension_manifest(
        &state
            .ctx
            .config,
        *extension_id,
        *generation,
        *addon_id,
        *operation_id,
        *attempt_id,
    )
    .await
    .map_err(|_| failed("probe-extension"))?;
    let body = serde_json::to_vec(&ActionResult::Health { healthy })
        .map_err(|_| failed("probe-result-json"))?;
    if !(2..=PRIVATE_RESPONSE_BYTES).contains(&body.len()) {
        return Err(ControlFailure);
    }
    Ok(ControlSuccess {
        body,
        reload_addons: false,
    })
}

async fn execute_transaction(
    connection: &mut SqliteConnection,
    config: &crate::Config,
    request: &PrivateControlRequest,
    precomputed_password_hash: Option<&str>,
) -> Result<Vec<u8>, ControlFailure> {
    let cached = sqlx::query(
        "SELECT private_command_sha256, result_json \
         FROM atlas_pathless_control_operations \
         WHERE operation_id = ?1 AND action = ?2",
    )
    .bind(
        request
            .operation_id
            .to_string(),
    )
    .bind(
        request
            .command
            .action(),
    )
    .fetch_optional(&mut *connection)
    .await
    .map_err(|_| failed("journal-read"))?;

    if let Some(row) = cached {
        let mut digest: String = row
            .try_get(0)
            .map_err(|_| ControlFailure)?;
        let result_json: String = row
            .try_get(1)
            .map_err(|_| ControlFailure)?;
        let digest_matches = digest
            == request
                .private_command_sha256
                .expose();
        digest.zeroize();
        if !digest_matches || !(2..=PRIVATE_RESPONSE_BYTES).contains(&result_json.len())
        {
            return Err(ControlFailure);
        }
        return Ok(result_json.into_bytes());
    }

    let result = dispatch(
        connection,
        config,
        &request.command,
        precomputed_password_hash,
    )
    .await
    .map_err(|_| failed("dispatch"))?;
    let result_json = serde_json::to_vec(&result).map_err(|_| failed("result-json"))?;
    if !(2..=PRIVATE_RESPONSE_BYTES).contains(&result_json.len()) {
        return Err(ControlFailure);
    }

    sqlx::query(
        "INSERT INTO atlas_pathless_control_operations \
         (operation_id, action, private_command_sha256, result_json) \
         VALUES (?1, ?2, ?3, ?4)",
    )
    .bind(
        request
            .operation_id
            .to_string(),
    )
    .bind(
        request
            .command
            .action(),
    )
    .bind(
        request
            .private_command_sha256
            .expose(),
    )
    .bind(std::str::from_utf8(&result_json).map_err(|_| ControlFailure)?)
    .execute(&mut *connection)
    .await
    .map_err(|_| failed("journal-insert"))?;

    Ok(result_json)
}

async fn dispatch(
    connection: &mut SqliteConnection,
    config: &crate::Config,
    command: &PrivateCommand,
    precomputed_password_hash: Option<&str>,
) -> Result<ActionResult, ControlFailure> {
    match command {
        PrivateCommand::Health => Ok(ActionResult::Health { healthy: true }),
        PrivateCommand::StartupStatus => {
            let raw: Option<String> = sqlx::query_scalar(
                "SELECT value FROM settings WHERE key = 'server_configuration'",
            )
            .fetch_optional(&mut *connection)
            .await
            .map_err(|_| ControlFailure)?;
            let startup_complete = match raw {
                Some(value) => {
                    serde_json::from_str::<crate::api::ServerConfiguration>(&value)
                        .map_err(|_| ControlFailure)?
                        .is_startup_wizard_completed
                        .unwrap_or(false)
                }
                None => false,
            };
            Ok(ActionResult::StartupStatus {
                startup_complete,
                version: env!("CARGO_PKG_VERSION"),
            })
        }
        PrivateCommand::FindUser { username, .. } => Ok(ActionResult::User {
            user: find_user(connection, username).await?,
        }),
        PrivateCommand::GetUser { user_id } => Ok(ActionResult::User {
            user: get_user(connection, *user_id).await?,
        }),
        PrivateCommand::CreateUser {
            username, password, ..
        } => Ok(ActionResult::User {
            user: Some(
                create_user(
                    connection,
                    username,
                    password.expose(),
                    precomputed_password_hash.ok_or(ControlFailure)?,
                )
                .await?,
            ),
        }),
        PrivateCommand::DeleteUser { user_id } => {
            delete_user(connection, *user_id).await?;
            Ok(ActionResult::Completed { completed: true })
        }
        PrivateCommand::RevokeUserSessions { user_id } => {
            revoke_user_sessions(connection, *user_id).await?;
            Ok(ActionResult::Completed { completed: true })
        }
        PrivateCommand::FindAddon { marker, name } => Ok(ActionResult::Addon {
            addon: find_addon(connection, config, marker, name).await?,
        }),
        PrivateCommand::GetAddon { addon_id, marker } => Ok(ActionResult::Addon {
            addon: get_addon(connection, config, *addon_id, marker).await?,
        }),
        PrivateCommand::ProbeAddon { .. } => Err(ControlFailure),
        PrivateCommand::CreateAddon {
            marker,
            name,
            resources,
            types,
        } => Ok(ActionResult::Addon {
            addon: Some(
                create_addon(connection, config, marker, name, resources, types)
                    .await?,
            ),
        }),
        PrivateCommand::UpdateAddon {
            addon_id,
            marker,
            name,
            resources,
            types,
        } => Ok(ActionResult::Addon {
            addon: Some(
                update_addon(
                    connection, config, *addon_id, marker, name, resources, types,
                )
                .await?,
            ),
        }),
        PrivateCommand::DeleteAddon { addon_id, marker } => {
            delete_addon(connection, config, *addon_id, marker).await?;
            Ok(ActionResult::Completed { completed: true })
        }
        PrivateCommand::GetUserAddons { user_id } => Ok(ActionResult::AddonIds {
            addon_ids: get_user_addons(connection, *user_id).await?,
        }),
        PrivateCommand::SetUserAddons { user_id, addon_ids } => {
            set_user_addons(connection, *user_id, addon_ids).await?;
            Ok(ActionResult::Completed { completed: true })
        }
    }
}

async fn find_user(
    connection: &mut SqliteConnection,
    username: &str,
) -> Result<Option<UserResult>, ControlFailure> {
    let users =
        sqlx::query_as::<_, db::User>("SELECT * FROM users WHERE username = ?1")
            .bind(username)
            .fetch_all(&mut *connection)
            .await
            .map_err(|_| ControlFailure)?;
    match users.as_slice() {
        [] => Ok(None),
        [user] => user_result(user).map(Some),
        _ => Err(ControlFailure),
    }
}

async fn get_user(
    connection: &mut SqliteConnection,
    user_id: Uuid,
) -> Result<Option<UserResult>, ControlFailure> {
    let user = sqlx::query_as::<_, db::User>("SELECT * FROM users WHERE id = ?1")
        .bind(user_id)
        .fetch_optional(&mut *connection)
        .await
        .map_err(|_| ControlFailure)?;
    user.as_ref()
        .map(user_result)
        .transpose()
}

fn user_result(user: &db::User) -> Result<UserResult, ControlFailure> {
    if !valid_uuid(user.id)
        || !USERNAME_PATTERN.is_match(&user.username)
        || user.is_admin
    {
        return Err(ControlFailure);
    }
    Ok(UserResult {
        id: user.id,
        name: user
            .username
            .clone(),
    })
}

async fn create_user(
    connection: &mut SqliteConnection,
    username: &str,
    password: &str,
    password_hash: &str,
) -> Result<UserResult, ControlFailure> {
    let existing =
        sqlx::query_as::<_, db::User>("SELECT * FROM users WHERE username = ?1")
            .bind(username)
            .fetch_all(&mut *connection)
            .await
            .map_err(|_| failed("create-user-read-before"))?;
    match existing.as_slice() {
        [] => {
            let id = Uuid::new_v4();
            sqlx::query(
                "INSERT INTO users \
                 (id, username, password_hash, aio_url, configuration, is_admin, policy) \
                 VALUES (?1, ?2, ?3, NULL, NULL, 0, NULL)",
            )
            .bind(id)
            .bind(username)
            .bind(password_hash)
            .execute(&mut *connection)
            .await
            .map_err(|_| failed("create-user-insert"))?;
        }
        [user] => {
            if user.is_admin
                || !user
                    .verify_password(password)
                    .map_err(|_| ControlFailure)?
            {
                return Err(ControlFailure);
            }
        }
        _ => return Err(ControlFailure),
    }

    let users =
        sqlx::query_as::<_, db::User>("SELECT * FROM users WHERE username = ?1")
            .bind(username)
            .fetch_all(&mut *connection)
            .await
            .map_err(|_| failed("create-user-read-after"))?;
    match users.as_slice() {
        [user] => user_result(user),
        _ => Err(ControlFailure),
    }
}

async fn delete_user(
    connection: &mut SqliteConnection,
    user_id: Uuid,
) -> Result<(), ControlFailure> {
    if let Some(user) =
        sqlx::query_as::<_, db::User>("SELECT * FROM users WHERE id = ?1")
            .bind(user_id)
            .fetch_optional(&mut *connection)
            .await
            .map_err(|_| ControlFailure)?
    {
        user_result(&user)?;
    }
    sqlx::query("DELETE FROM devices WHERE user_id = ?1")
        .bind(user_id)
        .execute(&mut *connection)
        .await
        .map_err(|_| ControlFailure)?;
    sqlx::query("DELETE FROM users WHERE id = ?1")
        .bind(user_id)
        .execute(&mut *connection)
        .await
        .map_err(|_| ControlFailure)?;
    let remains: bool =
        sqlx::query_scalar("SELECT EXISTS(SELECT 1 FROM users WHERE id = ?1)")
            .bind(user_id)
            .fetch_one(&mut *connection)
            .await
            .map_err(|_| ControlFailure)?;
    if remains {
        return Err(ControlFailure);
    }
    Ok(())
}

async fn revoke_user_sessions(
    connection: &mut SqliteConnection,
    user_id: Uuid,
) -> Result<(), ControlFailure> {
    get_user(connection, user_id)
        .await?
        .ok_or(ControlFailure)?;
    sqlx::query("DELETE FROM devices WHERE user_id = ?1")
        .bind(user_id)
        .execute(&mut *connection)
        .await
        .map_err(|_| ControlFailure)?;
    let count: i64 =
        sqlx::query_scalar("SELECT COUNT(*) FROM devices WHERE user_id = ?1")
            .bind(user_id)
            .fetch_one(&mut *connection)
            .await
            .map_err(|_| ControlFailure)?;
    if count != 0 {
        return Err(ControlFailure);
    }
    Ok(())
}

async fn list_addons(
    connection: &mut SqliteConnection,
) -> Result<Vec<Addon>, ControlFailure> {
    sqlx::query_as::<_, Addon>(&format!(
        "SELECT {ADDON_COLUMNS} FROM addons ORDER BY created_at ASC, id ASC"
    ))
    .fetch_all(&mut *connection)
    .await
    .map_err(|_| ControlFailure)
}

async fn find_addon(
    connection: &mut SqliteConnection,
    config: &crate::Config,
    marker: &AtlasMarker,
    name: &str,
) -> Result<Option<AddonResult>, ControlFailure> {
    let mut candidates = Vec::new();
    for addon in list_addons(connection).await? {
        let observed_marker = addon_marker(config, &addon).ok();
        // Extension names are display metadata shared by unrelated tenants.
        // Only their exact marker identifies an installation.
        if observed_marker.as_ref() == Some(marker)
            || (matches!(marker, AtlasMarker::Source { .. }) && addon.name == name)
        {
            candidates.push((addon, observed_marker));
        }
    }
    match candidates.as_slice() {
        [] => Ok(None),
        [(addon, Some(observed_marker))]
            if addon.name == name && observed_marker == marker =>
        {
            addon_result(config, addon).map(Some)
        }
        _ => Err(ControlFailure),
    }
}

async fn get_addon(
    connection: &mut SqliteConnection,
    config: &crate::Config,
    addon_id: Uuid,
    marker: &AtlasMarker,
) -> Result<Option<AddonResult>, ControlFailure> {
    let addon = sqlx::query_as::<_, Addon>(&format!(
        "SELECT {ADDON_COLUMNS} FROM addons WHERE id = ?1"
    ))
    .bind(addon_id)
    .fetch_optional(&mut *connection)
    .await
    .map_err(|_| ControlFailure)?;
    match addon {
        None => Ok(None),
        Some(addon) if addon_marker(config, &addon)? == *marker => {
            addon_result(config, &addon).map(Some)
        }
        Some(_) => Err(ControlFailure),
    }
}

async fn create_addon(
    connection: &mut SqliteConnection,
    config: &crate::Config,
    marker: &AtlasMarker,
    name: &str,
    resources: &[ControlResource],
    types: &[String],
) -> Result<AddonResult, ControlFailure> {
    let mut candidates = Vec::new();
    for addon in list_addons(connection).await? {
        let observed_marker = addon_marker(config, &addon).ok();
        // Extension names are display metadata shared by unrelated tenants.
        // Only their exact marker identifies an installation.
        if observed_marker.as_ref() == Some(marker)
            || (matches!(marker, AtlasMarker::Source { .. }) && addon.name == name)
        {
            candidates.push((addon, observed_marker));
        }
    }

    match candidates.as_slice() {
        [] => {
            let id = Uuid::new_v4();
            let now = Utc::now().naive_utc();
            let preset = AddonPresetRef {
                kind: "stremio".to_string(),
                config: serde_json::json!({ "manifest_url": marker_url(config, marker)? }),
            };
            let remux_resources: Vec<ResourceType> = resources
                .iter()
                .copied()
                .map(ControlResource::to_remux)
                .collect();
            let remux_types: Vec<db::MediaKind> = types
                .iter()
                .map(|value| remux_media_kind(value).ok_or(ControlFailure))
                .collect::<Result<_, _>>()?;
            let priority: i64 = sqlx::query_scalar(
                "SELECT COALESCE(MAX(priority), -1) + 1 FROM addons",
            )
            .fetch_one(&mut *connection)
            .await
            .map_err(|_| ControlFailure)?;
            let services = Vec::<crate::sdks::remux::ServiceId>::new();
            sqlx::query(
                "INSERT INTO addons \
                 (id, name, preset, resources, types, enabled, priority, created_at, updated_at, \
                  system, is_default, http_redirect_stream, service_filter) \
                 VALUES (?1, ?2, ?3, ?4, ?5, 1, ?6, ?7, ?7, 0, 0, 1, ?8)",
            )
            .bind(id)
            .bind(name)
            .bind(sqlx::types::Json(&preset))
            .bind(sqlx::types::Json(&remux_resources))
            .bind(sqlx::types::Json(&remux_types))
            .bind(priority)
            .bind(now)
            .bind(sqlx::types::Json(&services))
            .execute(&mut *connection)
            .await
            .map_err(|_| ControlFailure)?;
        }
        [(addon, Some(observed_marker))]
            if addon.name == name && observed_marker == marker =>
        {
            let observed = addon_result(config, addon)?;
            if observed.resources != resources || observed.types != types {
                return Err(ControlFailure);
            }
        }
        _ => return Err(ControlFailure),
    }

    let matches = exact_addon_matches(connection, config, marker, name).await?;
    match matches.as_slice() {
        [addon] => {
            let observed = addon_result(config, addon)?;
            if observed.resources != resources || observed.types != types {
                return Err(ControlFailure);
            }
            Ok(observed)
        }
        _ => Err(ControlFailure),
    }
}

async fn update_addon(
    connection: &mut SqliteConnection,
    config: &crate::Config,
    addon_id: Uuid,
    marker: &AtlasMarker,
    name: &str,
    resources: &[ControlResource],
    types: &[String],
) -> Result<AddonResult, ControlFailure> {
    let current = get_addon(connection, config, addon_id, marker)
        .await?
        .ok_or(ControlFailure)?;
    let name_conflicts: i64 =
        sqlx::query_scalar("SELECT COUNT(*) FROM addons WHERE name = ?1 AND id <> ?2")
            .bind(name)
            .bind(addon_id)
            .fetch_one(&mut *connection)
            .await
            .map_err(|_| ControlFailure)?;
    if matches!(marker, AtlasMarker::Source { .. }) && name_conflicts != 0 {
        return Err(ControlFailure);
    }

    if current.name != name
        || current.resources != resources
        || current.types != types
        || !current.enabled
        || current.is_default
        || !current.http_redirect_stream
    {
        let preset = AddonPresetRef {
            kind: "stremio".to_string(),
            config: serde_json::json!({ "manifest_url": marker_url(config, marker)? }),
        };
        let remux_resources: Vec<ResourceType> = resources
            .iter()
            .copied()
            .map(ControlResource::to_remux)
            .collect();
        let remux_types: Vec<db::MediaKind> = types
            .iter()
            .map(|value| remux_media_kind(value).ok_or(ControlFailure))
            .collect::<Result<_, _>>()?;
        sqlx::query(
            "UPDATE addons SET name = ?2, preset = ?3, resources = ?4, types = ?5, \
             enabled = 1, updated_at = ?6, system = 0, is_default = 0, \
             http_redirect_stream = 1 WHERE id = ?1",
        )
        .bind(addon_id)
        .bind(name)
        .bind(sqlx::types::Json(&preset))
        .bind(sqlx::types::Json(&remux_resources))
        .bind(sqlx::types::Json(&remux_types))
        .bind(Utc::now().naive_utc())
        .execute(&mut *connection)
        .await
        .map_err(|_| ControlFailure)?;
    }

    let observed = get_addon(connection, config, addon_id, marker)
        .await?
        .ok_or(ControlFailure)?;
    if observed.name != name
        || observed.resources != resources
        || observed.types != types
    {
        return Err(ControlFailure);
    }
    Ok(observed)
}

async fn delete_addon(
    connection: &mut SqliteConnection,
    config: &crate::Config,
    addon_id: Uuid,
    marker: &AtlasMarker,
) -> Result<(), ControlFailure> {
    if let Some(addon) = sqlx::query_as::<_, Addon>(&format!(
        "SELECT {ADDON_COLUMNS} FROM addons WHERE id = ?1"
    ))
    .bind(addon_id)
    .fetch_optional(&mut *connection)
    .await
    .map_err(|_| ControlFailure)?
    {
        if addon_marker(config, &addon)? != *marker || addon.system {
            return Err(ControlFailure);
        }
        sqlx::query("DELETE FROM addons WHERE id = ?1")
            .bind(addon_id)
            .execute(&mut *connection)
            .await
            .map_err(|_| ControlFailure)?;
    }
    let remains: bool =
        sqlx::query_scalar("SELECT EXISTS(SELECT 1 FROM addons WHERE id = ?1)")
            .bind(addon_id)
            .fetch_one(&mut *connection)
            .await
            .map_err(|_| ControlFailure)?;
    if remains {
        return Err(ControlFailure);
    }
    Ok(())
}

async fn exact_addon_matches(
    connection: &mut SqliteConnection,
    config: &crate::Config,
    marker: &AtlasMarker,
    name: &str,
) -> Result<Vec<Addon>, ControlFailure> {
    let mut matches = Vec::new();
    for addon in list_addons(connection).await? {
        if addon.name == name
            && addon_marker(config, &addon)
                .ok()
                .as_ref()
                == Some(marker)
        {
            matches.push(addon);
        }
    }
    Ok(matches)
}

fn addon_result(
    config: &crate::Config,
    addon: &Addon,
) -> Result<AddonResult, ControlFailure> {
    if !valid_uuid(addon.id)
        || addon
            .preset
            .kind
            != "stremio"
        || !valid_addon_name(&addon.name)
        || !addon.enabled
        || addon.system
        || addon.is_default
        || !addon.http_redirect_stream
    {
        return Err(ControlFailure);
    }

    let mut resources: Vec<ControlResource> = addon
        .resources
        .iter()
        .map(|resource| match resource {
            ResourceType::Catalog => Ok(ControlResource::Catalog),
            ResourceType::Meta => Ok(ControlResource::Meta),
            ResourceType::Stream => Ok(ControlResource::Stream),
            ResourceType::Subtitles => Ok(ControlResource::Subtitles),
            _ => Err(ControlFailure),
        })
        .collect::<Result<_, _>>()?;
    resources.sort_by_key(|resource| resource.as_str());
    resources.dedup_by_key(|resource| resource.as_str());
    if resources.is_empty()
        || resources.len()
            != addon
                .resources
                .len()
    {
        return Err(ControlFailure);
    }

    let mut types: Vec<String> = addon
        .types
        .iter()
        .map(ToString::to_string)
        .collect();
    types.sort();
    types.dedup();
    if types.is_empty()
        || types.len()
            != addon
                .types
                .len()
    {
        return Err(ControlFailure);
    }

    Ok(AddonResult {
        id: addon.id,
        kind: "stremio",
        name: addon
            .name
            .clone(),
        marker: addon_marker(config, addon)?,
        resources,
        types,
        enabled: true,
        is_default: false,
        http_redirect_stream: true,
    })
}

fn addon_marker(
    config: &crate::Config,
    addon: &Addon,
) -> Result<AtlasMarker, ControlFailure> {
    let raw = addon
        .preset
        .config
        .get("manifest_url")
        .and_then(serde_json::Value::as_str)
        .ok_or(ControlFailure)?;
    parse_marker_url(config, raw)
}

fn marker_url(
    config: &crate::Config,
    marker: &AtlasMarker,
) -> Result<String, ControlFailure> {
    let origin = config
        .atlas_extension_relay_origin
        .as_deref()
        .ok_or(ControlFailure)?;
    db::atlas_tenant::validate_relay_origin(origin).map_err(|_| ControlFailure)?;
    let suffix = match marker {
        AtlasMarker::Source {
            source_binding_id,
            generation,
        } => format!("atlas-source/{source_binding_id}/{generation}"),
        AtlasMarker::Extension {
            extension_id,
            generation,
        } => format!("atlas-extension/{extension_id}/{generation}"),
    };
    Ok(format!("{origin}/.well-known/{suffix}/manifest.json"))
}

fn parse_marker_url(
    config: &crate::Config,
    raw: &str,
) -> Result<AtlasMarker, ControlFailure> {
    let origin = config
        .atlas_extension_relay_origin
        .as_deref()
        .ok_or(ControlFailure)?;
    let suffix = raw
        .strip_prefix(&format!("{origin}/.well-known/"))
        .and_then(|value| value.strip_suffix("/manifest.json"))
        .ok_or(ControlFailure)?;
    let pieces: Vec<&str> = suffix
        .split('/')
        .collect();
    if pieces.len() != 3 {
        return Err(ControlFailure);
    }
    let id = Uuid::parse_str(pieces[1]).map_err(|_| ControlFailure)?;
    let generation = pieces[2]
        .parse::<u32>()
        .map_err(|_| ControlFailure)?;
    if id.to_string() != pieces[1]
        || generation.to_string() != pieces[2]
        || !valid_uuid(id)
        || !(1..=i32::MAX as u32).contains(&generation)
    {
        return Err(ControlFailure);
    }
    let marker = match pieces[0] {
        "atlas-source" => AtlasMarker::Source {
            source_binding_id: id,
            generation,
        },
        "atlas-extension" => AtlasMarker::Extension {
            extension_id: id,
            generation,
        },
        _ => return Err(ControlFailure),
    };
    if marker_url(config, &marker)? != raw {
        return Err(ControlFailure);
    }
    Ok(marker)
}

fn remux_media_kind(value: &str) -> Option<db::MediaKind> {
    match value {
        "movie" => Some(db::MediaKind::Movie),
        "series" => Some(db::MediaKind::Series),
        _ => None,
    }
}

async fn get_user_addons(
    connection: &mut SqliteConnection,
    user_id: Uuid,
) -> Result<Vec<Uuid>, ControlFailure> {
    get_user(connection, user_id)
        .await?
        .ok_or(ControlFailure)?;
    let mut addon_ids: Vec<Uuid> =
        sqlx::query_scalar("SELECT addon_id FROM addon_users WHERE user_id = ?1")
            .bind(user_id)
            .fetch_all(&mut *connection)
            .await
            .map_err(|_| ControlFailure)?;
    addon_ids.sort_by_key(Uuid::to_string);
    addon_ids.dedup();
    if addon_ids.len() > 128
        || !addon_ids
            .iter()
            .copied()
            .all(valid_uuid)
    {
        return Err(ControlFailure);
    }
    Ok(addon_ids)
}

async fn set_user_addons(
    connection: &mut SqliteConnection,
    user_id: Uuid,
    addon_ids: &[Uuid],
) -> Result<(), ControlFailure> {
    get_user(connection, user_id)
        .await?
        .ok_or(ControlFailure)?;

    for addon_id in addon_ids {
        let addon_exists: bool =
            sqlx::query_scalar("SELECT EXISTS(SELECT 1 FROM addons WHERE id = ?1)")
                .bind(addon_id)
                .fetch_one(&mut *connection)
                .await
                .map_err(|_| ControlFailure)?;
        if !addon_exists {
            return Err(ControlFailure);
        }
    }

    let current = get_user_addons(connection, user_id).await?;
    if current != addon_ids {
        sqlx::query("DELETE FROM addon_users WHERE user_id = ?1")
            .bind(user_id)
            .execute(&mut *connection)
            .await
            .map_err(|_| ControlFailure)?;
        for (priority, addon_id) in addon_ids
            .iter()
            .enumerate()
        {
            sqlx::query(
                "INSERT INTO addon_users (addon_id, user_id, priority) VALUES (?1, ?2, ?3)",
            )
            .bind(addon_id)
            .bind(user_id)
            .bind(priority as i64)
            .execute(&mut *connection)
            .await
            .map_err(|_| ControlFailure)?;
        }
    }
    if get_user_addons(connection, user_id).await? != addon_ids {
        return Err(ControlFailure);
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    use axum_test::{TestResponse, TestServer};
    use base64::{Engine as _, engine::general_purpose::URL_SAFE_NO_PAD};
    use http::{HeaderName, HeaderValue};
    use serde_json::Value;

    use crate::integration_test::{
        AUTH_HEADER, TestGuard, auth_header_with_token, new_test_server_with_config,
    };

    const REMUX_BINDING_ID: &str = "11111111-1111-4111-8111-111111111111";
    const ACCOUNT_REMUX_BINDING_ID: &str = "22222222-2222-4222-8222-222222222222";
    const OPERATION_ID: &str = "33333333-3333-4333-8333-333333333333";
    const ATTEMPT_ID: &str = "55555555-5555-4555-8555-555555555555";
    const CREDENTIAL_SECRET_ID: &str = "44444444-4444-4444-8444-444444444444";
    const USERNAME: &str = "atlas_AAAAAAAAAAAAAAAAAAAAAAAA";

    #[test]
    fn marker_roundtrip_is_exact_and_addon_types_are_closed() {
        let config = atlas_config();
        for marker in [
            AtlasMarker::Source {
                source_binding_id: parse_uuid("55555555-5555-4555-8555-555555555555"),
                generation: 1,
            },
            AtlasMarker::Extension {
                extension_id: parse_uuid("66666666-6666-4666-8666-666666666666"),
                generation: i32::MAX as u32,
            },
        ] {
            let url = marker_url(&config, &marker).unwrap();
            assert_eq!(parse_marker_url(&config, &url).unwrap(), marker);
        }

        let marker = AtlasMarker::Source {
            source_binding_id: parse_uuid("55555555-5555-4555-8555-555555555555"),
            generation: 1,
        };
        let resources = [ControlResource::Stream];
        assert!(
            validate_addon_binding(
                &marker,
                "AIO Stréams",
                &resources,
                &["movie".to_string(), "series".to_string()],
            )
            .is_ok()
        );
        for rejected in [
            vec!["anime".to_string()],
            vec!["movie".to_string(), "track".to_string()],
            vec!["series".to_string(), "movie".to_string()],
        ] {
            assert!(
                validate_addon_binding(
                    &marker,
                    "Atlas Cloud AAAAAAAAAAAAAAAA",
                    &resources,
                    &rejected,
                )
                .is_err()
            );
        }
        for rejected in [
            "",
            " https://secret.invalid",
            "https://secret.invalid/?token=hidden",
            "Unsafe\u{202e}Name",
        ] {
            assert!(
                validate_addon_binding(
                    &marker,
                    rejected,
                    &resources,
                    &["movie".to_string()],
                )
                .is_err()
            );
        }
        assert!(!valid_addon_name(&"x".repeat(201)));
    }

    #[tokio::test]
    async fn private_extensions_with_shared_names_remain_independent() {
        let (server, _guard, token) = private_server().await;
        let first = AtlasMarker::Extension {
            extension_id: Uuid::new_v4(),
            generation: 1,
        };
        let second = AtlasMarker::Extension {
            extension_id: Uuid::new_v4(),
            generation: 1,
        };
        let mut ids = Vec::new();
        for marker in [&first, &second] {
            let absent = send_private(
                &server,
                &token,
                private_body(
                    PrivateCommand::FindAddon {
                        marker: marker.clone(),
                        name: "AIOStreams".into(),
                    },
                    Uuid::new_v4(),
                ),
            )
            .await;
            absent.assert_status_ok();
            assert!(absent.json::<Value>()["addon"].is_null());
            let created = send_private(
                &server,
                &token,
                private_body(
                    PrivateCommand::CreateAddon {
                        marker: marker.clone(),
                        name: "AIOStreams".into(),
                        resources: vec![ControlResource::Stream],
                        types: vec!["movie".into()],
                    },
                    Uuid::new_v4(),
                ),
            )
            .await;
            created.assert_status_ok();
            ids.push(
                Uuid::parse_str(
                    created.json::<Value>()["addon"]["id"]
                        .as_str()
                        .unwrap(),
                )
                .unwrap(),
            );
        }
        assert_ne!(ids[0], ids[1]);
        for (index, marker) in [&first, &second]
            .iter()
            .enumerate()
        {
            let found = send_private(
                &server,
                &token,
                private_body(
                    PrivateCommand::FindAddon {
                        marker: (*marker).clone(),
                        name: "AIOStreams".into(),
                    },
                    Uuid::new_v4(),
                ),
            )
            .await;
            found.assert_status_ok();
            assert_eq!(found.json::<Value>()["addon"]["id"], ids[index].to_string());
            let updated = send_private(
                &server,
                &token,
                private_body(
                    PrivateCommand::UpdateAddon {
                        addon_id: ids[index],
                        marker: (*marker).clone(),
                        name: "AIOStreams".into(),
                        resources: vec![ControlResource::Stream],
                        types: vec!["movie".into(), "series".into()],
                    },
                    Uuid::new_v4(),
                ),
            )
            .await;
            updated.assert_status_ok();
        }
        let cross = send_private_failure(
            &server,
            &token,
            private_body(
                PrivateCommand::GetAddon {
                    addon_id: ids[0],
                    marker: second,
                },
                Uuid::new_v4(),
            ),
        )
        .await;
        assert!(
            !cross
                .status_code()
                .is_success()
        );
    }

    #[tokio::test]
    async fn private_probe_is_attempt_bound_extension_only_and_never_journaled() {
        let (server, guard, token) = private_server().await;
        let operation_id = parse_uuid(OPERATION_ID);
        let attempt_id = parse_uuid(ATTEMPT_ID);
        let addon_id = parse_uuid("77777777-7777-4777-8777-777777777777");
        let marker = AtlasMarker::Extension {
            extension_id: parse_uuid("66666666-6666-4666-8666-666666666666"),
            generation: 2,
        };
        let probe = PrivateCommand::ProbeAddon {
            addon_id,
            marker: marker.clone(),
            operation_id,
            attempt_id,
        };
        assert_eq!(
            serde_json::to_string(&probe).unwrap(),
            r#"{"action":"probe_addon","addonId":"77777777-7777-4777-8777-777777777777","marker":{"kind":"extension","extensionId":"66666666-6666-4666-8666-666666666666","generation":2},"operationId":"33333333-3333-4333-8333-333333333333","attemptId":"55555555-5555-4555-8555-555555555555"}"#
        );
        assert!(!probe.reloads_addons());

        let missing =
            send_private_failure(&server, &token, private_body(probe, operation_id))
                .await;
        missing.assert_status(StatusCode::SERVICE_UNAVAILABLE);

        for invalid in [
            PrivateCommand::ProbeAddon {
                addon_id,
                marker,
                operation_id: parse_uuid("88888888-8888-4888-8888-888888888888"),
                attempt_id,
            },
            PrivateCommand::ProbeAddon {
                addon_id,
                marker: AtlasMarker::Source {
                    source_binding_id: parse_uuid(
                        "66666666-6666-4666-8666-666666666666",
                    ),
                    generation: 2,
                },
                operation_id,
                attempt_id,
            },
        ] {
            let response = send_private_failure(
                &server,
                &token,
                private_body(invalid, operation_id),
            )
            .await;
            response.assert_status(StatusCode::SERVICE_UNAVAILABLE);
        }

        let journal_count: i64 = sqlx::query_scalar(
            "SELECT COUNT(*) FROM atlas_pathless_control_operations \
             WHERE action = 'probe_addon'",
        )
        .fetch_one(
            &guard
                .0
                .db,
        )
        .await
        .unwrap();
        assert_eq!(journal_count, 0);
    }

    #[tokio::test]
    async fn private_extension_create_update_is_provider_free_and_old_marker_delete_is_strict()
     {
        let (server, guard, token) = private_server().await;
        let extension_id = parse_uuid("66666666-6666-4666-8666-666666666666");
        let installed_marker = AtlasMarker::Extension {
            extension_id,
            generation: 7,
        };
        let create_body = private_body(
            PrivateCommand::CreateAddon {
                marker: installed_marker.clone(),
                name: "AIO Stréams".to_string(),
                resources: vec![ControlResource::Catalog, ControlResource::Stream],
                types: vec!["movie".to_string(), "series".to_string()],
            },
            Uuid::new_v4(),
        );
        let create_wire = std::str::from_utf8(&create_body).unwrap();
        for forbidden in [
            "relay.atlas.invalid",
            "manifest_url",
            "\"reload\"",
            "\"attemptId\"",
        ] {
            assert!(!create_wire.contains(forbidden));
        }
        let created = send_private(&server, &token, create_body).await;
        created.assert_status_ok();
        let created_json = created.json::<Value>();
        let addon_id = Uuid::parse_str(
            created_json["addon"]["id"]
                .as_str()
                .unwrap(),
        )
        .unwrap();
        assert_eq!(created_json["addon"]["marker"]["generation"], 7);
        let runtime = guard
            .0
            .addons
            .get(addon_id)
            .unwrap();
        assert_eq!(
            runtime
                .caps
                .metadata
                .supported_resources
                .iter()
                .map(|resource| resource
                    .name
                    .clone())
                .collect::<Vec<_>>(),
            vec![ResourceType::Catalog, ResourceType::Stream]
        );
        assert_eq!(
            runtime
                .caps
                .metadata
                .supported_types,
            vec![
                crate::addons::MediaKind::Movie,
                crate::addons::MediaKind::Series
            ]
        );

        let update_body = private_body(
            PrivateCommand::UpdateAddon {
                addon_id,
                marker: installed_marker.clone(),
                name: "Debridio".to_string(),
                resources: vec![ControlResource::Meta, ControlResource::Subtitles],
                types: vec!["series".to_string()],
            },
            Uuid::new_v4(),
        );
        let update_wire = std::str::from_utf8(&update_body).unwrap();
        for forbidden in [
            "relay.atlas.invalid",
            "manifest_url",
            "\"reload\"",
            "\"attemptId\"",
        ] {
            assert!(!update_wire.contains(forbidden));
        }
        let updated = send_private(&server, &token, update_body).await;
        updated.assert_status_ok();
        assert!(
            !updated
                .text()
                .contains("relay.atlas.invalid")
        );
        assert!(
            !updated
                .text()
                .contains("manifest_url")
        );
        let runtime = guard
            .0
            .addons
            .get(addon_id)
            .unwrap();
        assert_eq!(
            runtime
                .caps
                .metadata
                .supported_resources
                .iter()
                .map(|resource| resource
                    .name
                    .clone())
                .collect::<Vec<_>>(),
            vec![ResourceType::Meta, ResourceType::Subtitles]
        );
        assert_eq!(
            runtime
                .caps
                .metadata
                .supported_types,
            vec![crate::addons::MediaKind::Series]
        );

        let wrong_marker = AtlasMarker::Extension {
            extension_id,
            generation: 8,
        };
        let rejected = send_private_failure(
            &server,
            &token,
            private_body(
                PrivateCommand::DeleteAddon {
                    addon_id,
                    marker: wrong_marker,
                },
                Uuid::new_v4(),
            ),
        )
        .await;
        rejected.assert_status(StatusCode::SERVICE_UNAVAILABLE);
        assert!(
            guard
                .0
                .addons
                .get(addon_id)
                .is_some()
        );

        for _ in 0..2 {
            let deleted = send_private(
                &server,
                &token,
                private_body(
                    PrivateCommand::DeleteAddon {
                        addon_id,
                        marker: installed_marker.clone(),
                    },
                    Uuid::new_v4(),
                ),
            )
            .await;
            deleted.assert_status_ok();
            assert_eq!(
                deleted.json::<Value>(),
                serde_json::json!({ "completed": true })
            );
        }
        let absent = send_private(
            &server,
            &token,
            private_body(
                PrivateCommand::GetAddon {
                    addon_id,
                    marker: installed_marker,
                },
                Uuid::new_v4(),
            ),
        )
        .await;
        absent.assert_status_ok();
        assert_eq!(absent.json::<Value>(), serde_json::json!({ "addon": null }));
        assert!(
            guard
                .0
                .addons
                .get(addon_id)
                .is_none()
        );
    }

    #[tokio::test]
    async fn private_create_user_is_idempotent_and_redacted() {
        let (server, guard, token) = private_server().await;
        let password = URL_SAFE_NO_PAD.encode([19_u8; 32]);
        let body = private_body(
            PrivateCommand::CreateUser {
                username: USERNAME.to_string(),
                credential_secret_id: parse_uuid(CREDENTIAL_SECRET_ID),
                credential_generation: 1,
                password: SecretString(password.clone()),
            },
            parse_uuid(OPERATION_ID),
        );

        let first = send_private(&server, &token, body.clone()).await;
        first.assert_status_ok();
        assert_eq!(
            first
                .header(header::CONTENT_TYPE)
                .to_str()
                .unwrap(),
            "application/json"
        );
        let first_bytes = first
            .as_bytes()
            .clone();
        let first_json: Value = serde_json::from_slice(&first_bytes).unwrap();
        assert_eq!(first_json["user"]["name"], USERNAME);
        assert!(
            !first
                .text()
                .contains(&password)
        );
        assert!(
            !first
                .text()
                .contains("privateCommandSHA256")
        );

        let retry = send_private(&server, &token, body).await;
        retry.assert_status_ok();
        assert_eq!(retry.as_bytes(), &first_bytes);

        let user_count: i64 =
            sqlx::query_scalar("SELECT COUNT(*) FROM users WHERE username = ?1")
                .bind(USERNAME)
                .fetch_one(
                    &guard
                        .0
                        .db,
                )
                .await
                .unwrap();
        let operation_count: i64 = sqlx::query_scalar(
            "SELECT COUNT(*) FROM atlas_pathless_control_operations \
             WHERE operation_id = ?1 AND action = 'create_user'",
        )
        .bind(OPERATION_ID)
        .fetch_one(
            &guard
                .0
                .db,
        )
        .await
        .unwrap();
        assert_eq!(user_count, 1);
        assert_eq!(operation_count, 1);

        let changed = private_body(
            PrivateCommand::CreateUser {
                username: USERNAME.to_string(),
                credential_secret_id: parse_uuid(CREDENTIAL_SECRET_ID),
                credential_generation: 1,
                password: SecretString(URL_SAFE_NO_PAD.encode([20_u8; 32])),
            },
            parse_uuid(OPERATION_ID),
        );
        let conflict = send_private_failure(&server, &token, changed).await;
        conflict.assert_status(StatusCode::SERVICE_UNAVAILABLE);
        assert!(
            conflict
                .as_bytes()
                .is_empty()
        );

        let final_count: i64 =
            sqlx::query_scalar("SELECT COUNT(*) FROM users WHERE username = ?1")
                .bind(USERNAME)
                .fetch_one(
                    &guard
                        .0
                        .db,
                )
                .await
                .unwrap();
        assert_eq!(final_count, 1);
    }

    #[tokio::test]
    async fn private_surface_and_retired_routes_are_exact_empty_failures() {
        let (server, _guard, token) = private_server().await;
        let body = private_body(PrivateCommand::Health, parse_uuid(OPERATION_ID));

        let wrong_method = server
            .get(PRIVATE_PATH)
            .add_header(header::AUTHORIZATION, admin_header(&token))
            .add_header(
                header::CONTENT_LENGTH,
                HeaderValue::from_str(
                    &body
                        .len()
                        .to_string(),
                )
                .unwrap(),
            )
            .content_type("application/json")
            .bytes(body.into())
            .expect_failure()
            .await;
        assert_empty_not_found(&wrong_method);

        let retired_path = ["", "_atlas", "control", "users"].join("/");
        let old_path = server
            .get(&retired_path)
            .expect_failure()
            .await;
        assert_empty_not_found(&old_path);

        let retired_name = HeaderName::from_bytes(
            ["x", "atlas", "remux", "gateway"]
                .join("-")
                .as_bytes(),
        )
        .unwrap();
        let old_header = server
            .get("/health")
            .add_header(retired_name, HeaderValue::from_static("retired"))
            .expect_failure()
            .await;
        assert_empty_not_found(&old_header);
    }

    #[tokio::test]
    async fn private_tenant_mutations_refuse_administrator_targets() {
        let (server, guard, token) = private_server().await;
        let admin_id: Uuid =
            sqlx::query_scalar("SELECT id FROM users WHERE username = 'test'")
                .fetch_one(
                    &guard
                        .0
                        .db,
                )
                .await
                .unwrap();
        for command in [
            PrivateCommand::DeleteUser { user_id: admin_id },
            PrivateCommand::RevokeUserSessions { user_id: admin_id },
            PrivateCommand::GetUserAddons { user_id: admin_id },
            PrivateCommand::SetUserAddons {
                user_id: admin_id,
                addon_ids: vec![parse_uuid("77777777-7777-4777-8777-777777777777")],
            },
        ] {
            let response = send_private_failure(
                &server,
                &token,
                private_body(command, Uuid::new_v4()),
            )
            .await;
            response.assert_status(StatusCode::SERVICE_UNAVAILABLE);
            assert!(
                response
                    .as_bytes()
                    .is_empty()
            );
        }

        let admin_still_exists: bool =
            sqlx::query_scalar("SELECT EXISTS(SELECT 1 FROM users WHERE id = ?1)")
                .bind(admin_id)
                .fetch_one(
                    &guard
                        .0
                        .db,
                )
                .await
                .unwrap();
        assert!(admin_still_exists);
    }

    async fn private_server() -> (TestServer, TestGuard, String) {
        let (server, guard) = new_test_server_with_config(atlas_config())
            .await
            .unwrap();
        let response = server
            .post("/users/authenticatebyname")
            .add_header(header::AUTHORIZATION, HeaderValue::from_static(AUTH_HEADER))
            .json(&serde_json::json!({ "Username": "test", "Pw": "test" }))
            .await;
        let token = response.json::<Value>()["AccessToken"]
            .as_str()
            .unwrap()
            .to_string();
        (server, guard, token)
    }

    fn atlas_config() -> crate::Config {
        crate::Config {
            database_url: Some("sqlite::memory:".to_string()),
            torrent_http_port: None,
            disable_dht: true,
            atlas_remux_patched_tenant_auth: true,
            atlas_extension_relay_origin: Some(
                "https://relay.atlas.invalid".to_string(),
            ),
            atlas_pathless_api_origin: Some("https://api.atlas.invalid".to_string()),
            ..Default::default()
        }
    }

    async fn send_private(
        server: &TestServer,
        token: &str,
        body: Vec<u8>,
    ) -> TestResponse {
        server
            .post(PRIVATE_PATH)
            .authorization(auth_header_with_token(token))
            .add_header(
                header::CONTENT_LENGTH,
                HeaderValue::from_str(
                    &body
                        .len()
                        .to_string(),
                )
                .unwrap(),
            )
            .content_type("application/json")
            .bytes(body.into())
            .await
    }

    async fn send_private_failure(
        server: &TestServer,
        token: &str,
        body: Vec<u8>,
    ) -> TestResponse {
        server
            .post(PRIVATE_PATH)
            .authorization(auth_header_with_token(token))
            .add_header(
                header::CONTENT_LENGTH,
                HeaderValue::from_str(
                    &body
                        .len()
                        .to_string(),
                )
                .unwrap(),
            )
            .content_type("application/json")
            .bytes(body.into())
            .expect_failure()
            .await
    }

    fn admin_header(token: &str) -> HeaderValue {
        HeaderValue::from_str(&auth_header_with_token(token)).unwrap()
    }

    fn private_body(command: PrivateCommand, operation_id: Uuid) -> Vec<u8> {
        let remux_binding_id = parse_uuid(REMUX_BINDING_ID);
        let account_remux_binding_id = parse_uuid(ACCOUNT_REMUX_BINDING_ID);
        let core = PrivateCore {
            version: 2,
            remux_binding_id,
            account_remux_binding_id,
            operation_id,
            command: &command,
        };
        let mut hasher = Sha256::new();
        hasher.update(PRIVATE_DIGEST_DOMAIN);
        hasher.update(serde_json::to_vec(&core).unwrap());
        let digest = format!("{:x}", hasher.finalize());
        serde_json::to_vec(&PrivateControlRequest {
            version: 2,
            remux_binding_id,
            account_remux_binding_id,
            operation_id,
            command,
            private_command_sha256: SecretString(digest),
        })
        .unwrap()
    }

    fn parse_uuid(value: &str) -> Uuid {
        Uuid::parse_str(value).unwrap()
    }

    fn assert_empty_not_found(response: &TestResponse) {
        response.assert_status_not_found();
        assert!(
            response
                .as_bytes()
                .is_empty()
        );
        assert_eq!(
            response
                .header(header::CONTENT_LENGTH)
                .to_str()
                .unwrap(),
            "0"
        );
    }
}
