// V3 keeps uploaded-file discovery on Remux while addon JSON originates on the native device.
use super::*;

#[get("/atlas/v3/items/external/playbackinfo")]
pub async fn atlas_native_upload_playbackinfo(
    State(state): State<AppState>,
    session: auth::AuthSession,
    Query(query): Query<AtlasExternalPlaybackInfoQuery>,
) -> Result<impl IntoResponse> {
    if !state
        .ctx
        .config
        .atlas_remux_patched_tenant_auth
        || !state
            .ctx
            .config
            .atlas_stream_picker_v1
    {
        return Err(anyhow!("playback unavailable")).context_not_found("not found");
    }
    let identity = atlas_external_identity(query)
        .map_err(|_| anyhow!("invalid playback identity"))
        .context_not_found("not found")?;
    let item_id = atlas_materialize_external_item(
        &state,
        session
            .user
            .id,
        identity,
        true,
    )
    .await
    .context_internal("playback materialization failed")?;
    atlas_items_playbackinfo_scoped(
        &state,
        &session,
        item_id,
        api::PlaybackInfoQuery::default(),
        true,
    )
    .await
}

pub(super) async fn atlas_items_playbackinfo_scoped(
    state: &AppState,
    session: &auth::AuthSession,
    id: Uuid,
    q: api::PlaybackInfoQuery,
    uploads_only: bool,
) -> Result<Response<Body>> {
    let mut root = db::Media::get_by_id(
        &state
            .ctx
            .db,
        &id,
    )
    .await?
    .context_not_found("not found")?;
    state
        .ctx
        .addons
        .refresh_streams_scoped(
            &mut root,
            &state.ctx,
            Some(
                session
                    .user
                    .id,
            ),
            uploads_only,
        )
        .await
        .context_internal("Atlas stream refresh failed")?;
    let mut streams = root
        .streams(
            &state
                .ctx
                .db,
        )
        .await?;
    db::atlas_tenant::retain_user_streams(
        &state
            .ctx
            .db,
        session
            .user
            .id,
        &mut streams,
    )
    .await;
    if let Some(requested) = q
        .media_source_id
        .filter(|requested| *requested != id)
    {
        streams.retain(|stream| {
            stream.id == requested || stream.group_id == Some(requested)
        });
    }

    let play_session_id = common::get_uuid()
        .as_simple()
        .to_string();
    let mut media_sources = Vec::new();
    for stream in streams {
        let Some(info) = stream
            .stream_info
            .as_ref()
        else {
            continue;
        };
        if !matches!(
            &info.descriptor,
            crate::stream::StreamDescriptor::AtlasMedia(_)
                | crate::stream::StreamDescriptor::AtlasExtension(_)
        ) {
            continue;
        }
        if uploads_only
            && !matches!(
                &info.descriptor,
                crate::stream::StreamDescriptor::AtlasMedia(_)
            )
        {
            continue;
        }
        let source_id = stream.id;
        let presentation = atlas_stream_presentation(info);
        let facts = state
            .ctx
            .config
            .atlas_stream_facts_v1
            .then(|| {
                info.atlas_stream_facts
                    .clone()
            })
            .flatten();
        let quality = state
            .ctx
            .config
            .atlas_stream_facts_v1
            .then(|| {
                info.atlas_stream_quality
                    .clone()
            })
            .flatten();
        let display_name = info
            .name
            .clone()
            .or_else(|| {
                info.description
                    .clone()
            })
            .unwrap_or_else(|| "Stream".to_string());
        media_sources.push(api::MediaSourceInfo {
            id: source_id,
            e_tag: source_id,
            name: Some(display_name),
            atlas_stream_presentation: presentation,
            atlas_stream_facts: facts,
            atlas_stream_quality: quality,
            path: Some(format!(
                "/videos/{id}/stream?Static=true&MediaSourceId={source_id}"
            )),
            protocol: api::MediaProtocol::Http,
            is_remote: false,
            supports_direct_play: true,
            supports_direct_stream: false,
            supports_transcoding: false,
            supports_probing: false,
            formats: Some(Vec::new()),
            required_http_headers: None,
            run_time_ticks: root
                .runtime
                .and_then(|seconds| seconds.to_ticks(TickUnit::Seconds)),
            media_streams: Vec::new(),
            ..Default::default()
        });
    }

    if !media_sources.is_empty() {
        let sub_langs = db::Settings::get_config_or_default(
            &state
                .ctx
                .db,
        )
        .await
        .subtitle_languages
        .unwrap_or_default();
        inject_external_subtitles(
            &state.ctx,
            &mut root,
            &mut media_sources,
            id,
            "",
            sub_langs,
            Some(
                session
                    .user
                    .id,
            ),
        )
        .await;
    }
    let info = api::PlaybackInfoResponse {
        error_code: media_sources
            .is_empty()
            .then_some(api::PlaybackErrorCode::NoCompatibleStream),
        media_sources,
        play_session_id: Some(play_session_id),
        atlas_item_id: Some(id),
    };
    Ok(Json(info).into_response())
}

pub(super) fn root_id(
    identity: &AtlasExternalIdentity,
    user_id: Uuid,
    uploads_only: bool,
) -> Uuid {
    common::stable_media_uuid(
        &identity.root_kind,
        &if uploads_only {
            format!("atlas-device-v2:{user_id}:{}", identity.canonical_id)
        } else {
            identity
                .canonical_id
                .clone()
        },
    )
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn upload_roots_cannot_reuse_another_tenants_or_legacy_stream_cache() {
        let identity = atlas_external_identity(AtlasExternalPlaybackInfoQuery {
            kind: "Movie".into(),
            imdb_id: Some("tt1254207".into()),
            tmdb_id: None,
            tvdb_id: None,
            season_number: None,
            episode_number: None,
        })
        .unwrap();
        let first = Uuid::new_v4();
        let second = Uuid::new_v4();
        assert_eq!(
            root_id(&identity, first, true),
            root_id(&identity, first, true)
        );
        assert_ne!(
            root_id(&identity, first, true),
            root_id(&identity, second, true)
        );
        assert_ne!(
            root_id(&identity, first, true),
            root_id(&identity, first, false)
        );
        assert_eq!(
            root_id(&identity, first, false),
            common::stable_media_uuid(&identity.root_kind, "tt1254207")
        );
    }
}

#[cfg(test)]
mod persisted_lookup_tests {
    use super::*;

    #[tokio::test]
    async fn scoped_lookup_http_returns_movie_and_episode_playback_info() {
        use crate::integration_test::{
            AUTH_HEADER, auth_header_with_token, new_test_server_with_config,
        };
        let (server, _guard) = new_test_server_with_config(crate::Config {
            database_url: Some("sqlite::memory:".into()),
            torrent_http_port: None,
            disable_dht: true,
            atlas_remux_patched_tenant_auth: true,
            atlas_stream_picker_v1: true,
            atlas_pathless_api_origin: Some("https://api.atlas.invalid".into()),
            atlas_extension_relay_origin: Some("https://relay.atlas.invalid".into()),
            ..Default::default()
        })
        .await
        .unwrap();
        let login: serde_json::Value = server
            .post("/users/authenticatebyname")
            .add_header(
                http::header::AUTHORIZATION,
                http::HeaderValue::from_static(AUTH_HEADER),
            )
            .json(&serde_json::json!({"Username":"test","Pw":"test"}))
            .await
            .json();
        let header = auth_header_with_token(
            login["AccessToken"]
                .as_str()
                .unwrap(),
        );
        for query in [
            "Kind=Movie&ImdbId=tt0133093",
            "Kind=Episode&ImdbId=tt0944947&SeasonNumber=1&EpisodeNumber=1",
        ] {
            for _ in 0..2 {
                let response = server
                    .get(&format!("/atlas/v3/items/external/playbackinfo?{query}"))
                    .add_header(
                        http::header::AUTHORIZATION,
                        http::HeaderValue::from_str(&header).unwrap(),
                    )
                    .await;
                response.assert_status_ok();
                let body: serde_json::Value = response.json();
                assert!(
                    body["AtlasItemId"]
                        .as_str()
                        .is_some()
                );
                assert!(
                    body["PlaySessionId"]
                        .as_str()
                        .is_some()
                );
                assert!(
                    body["MediaSources"]
                        .as_array()
                        .unwrap()
                        .is_empty()
                );
            }
        }
    }

    #[tokio::test]
    async fn scoped_lookup_persists_movie_and_series_without_relaxing_normal_validation()
     {
        let pool = db::connect("sqlite::memory:", 1000)
            .await
            .unwrap();
        db::migrate(&pool)
            .await
            .unwrap();
        for kind in [db::MediaKind::Movie, db::MediaKind::Series] {
            let owner = Uuid::new_v4();
            let canonical_id = "tt0133093";
            let mut media = db::Media {
                id: common::stable_media_uuid(
                    &kind,
                    &format!("atlas-device-v2:{owner}:{canonical_id}"),
                ),
                kind,
                title: "Atlas Stream Lookup".into(),
                external_ids: db::ExternalIds {
                    imdb: Some(
                        db::NonEmptyString::try_new(canonical_id.to_string()).unwrap(),
                    ),
                    ..Default::default()
                },
                enabled: false,
                is_locked: true,
                ..Default::default()
            };
            assert!(
                media
                    .save(&pool)
                    .await
                    .is_err()
            );
            assert!(
                media
                    .save_atlas_native_lookup(&pool, Uuid::new_v4(), canonical_id)
                    .await
                    .is_err()
            );
            media
                .save_atlas_native_lookup(&pool, owner, canonical_id)
                .await
                .unwrap();
            let mut saved = db::Media::get_by_id(&pool, &media.id)
                .await
                .unwrap()
                .unwrap();
            saved
                .save_atlas_native_lookup(&pool, owner, canonical_id)
                .await
                .unwrap();
            assert!(
                saved
                    .save(&pool)
                    .await
                    .is_err()
            );
            saved.enabled = true;
            assert!(
                saved
                    .save_atlas_native_lookup(&pool, owner, canonical_id)
                    .await
                    .is_err()
            );
        }
    }
}
