// Atlas modification, 2026-08-27.
//
// Fixed Fly-private session mint/read/revoke boundary. Only the public Atlas
// gateway holds the administrator credential required to reach this route.

use std::sync::LazyLock;

use axum::{
    body::{Body, to_bytes},
    extract::{FromRequestParts, Request, State},
    http::{HeaderMap, Method, Response, StatusCode, header},
};
use regex::Regex;
use serde::{Deserialize, Serialize};
use uuid::{Uuid, Variant};

use crate::{AppState, db, db::auth::AdminSession};

const PRIVATE_PATH: &str = "/api/atlas/v1/native/device-session";
const PRIVATE_REQUEST_BYTES: usize = 2_048;
const PRIVATE_RESPONSE_BYTES: usize = 2_048;

static DEVICE_ID_PATTERN: LazyLock<Regex> = LazyLock::new(|| {
    Regex::new(
        r"^atlas-native-[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$",
    )
    .unwrap()
});
static USERNAME_PATTERN: LazyLock<Regex> =
    LazyLock::new(|| Regex::new(r"^atlas_[A-Za-z0-9_-]{24}$").unwrap());
static SAFE_NAME_PATTERN: LazyLock<Regex> =
    LazyLock::new(|| Regex::new(r"^[^\x00-\x1f\x7f]{1,80}$").unwrap());
static VERSION_PATTERN: LazyLock<Regex> =
    LazyLock::new(|| Regex::new(r"^[A-Za-z0-9][A-Za-z0-9._+-]{0,31}$").unwrap());
static TOKEN_PATTERN: LazyLock<Regex> = LazyLock::new(|| {
    Regex::new(
        r"^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$",
    )
    .unwrap()
});

#[derive(Serialize, Deserialize)]
#[serde(tag = "action", rename_all = "snake_case", deny_unknown_fields)]
enum DeviceSessionCommand {
    IssueDeviceSession {
        #[serde(rename = "userId")]
        user_id: Uuid,
        #[serde(rename = "deviceId")]
        device_id: String,
        #[serde(rename = "deviceName")]
        device_name: String,
        #[serde(rename = "appName")]
        app_name: String,
        #[serde(rename = "appVersion")]
        app_version: String,
    },
    GetDeviceSession {
        #[serde(rename = "userId")]
        user_id: Uuid,
        #[serde(rename = "deviceId")]
        device_id: String,
    },
    RevokeDeviceSession {
        #[serde(rename = "userId")]
        user_id: Uuid,
        #[serde(rename = "deviceId")]
        device_id: String,
    },
}

#[derive(Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct DeviceSessionRequest {
    version: u8,
    #[serde(flatten)]
    command: DeviceSessionCommand,
}

#[derive(Serialize)]
struct DeviceSessionResult {
    version: u8,
    session: SessionDTO,
}

#[derive(Serialize)]
struct SessionDTO {
    #[serde(rename = "userId")]
    user_id: Uuid,
    #[serde(rename = "deviceId")]
    device_id: String,
    #[serde(rename = "accessToken")]
    access_token: String,
}

#[derive(Serialize)]
struct RevokeResult {
    version: u8,
    revoked: bool,
}

#[derive(sqlx::FromRow)]
struct PersistedSession {
    user_id: Uuid,
    id: String,
    access_token: String,
    app_name: String,
}

#[derive(sqlx::FromRow)]
struct TenantIdentity {
    username: String,
    is_admin: bool,
}

pub async fn device_session(
    State(state): State<AppState>,
    request: Request,
) -> Response<Body> {
    if !state
        .ctx
        .config
        .atlas_remux_patched_tenant_auth
        || !private_surface_is_exact(&request)
    {
        return empty_response(StatusCode::NOT_FOUND);
    }

    let (mut parts, body) = request.into_parts();
    if AdminSession::from_request_parts(&mut parts, &state)
        .await
        .is_err()
    {
        return empty_response(StatusCode::NOT_FOUND);
    }
    let expected_length = match canonical_content_length(&parts.headers) {
        Some(length) => length,
        None => return empty_response(StatusCode::NOT_FOUND),
    };
    let raw = match to_bytes(body, PRIVATE_REQUEST_BYTES).await {
        Ok(bytes) if bytes.len() == expected_length => bytes,
        _ => return empty_response(StatusCode::SERVICE_UNAVAILABLE),
    };
    let request: DeviceSessionRequest = match serde_json::from_slice(&raw) {
        Ok(value) => value,
        Err(_) => return empty_response(StatusCode::SERVICE_UNAVAILABLE),
    };
    if request.version != 1
        || serde_json::to_vec(&request)
            .ok()
            .as_deref()
            != Some(raw.as_ref())
        || !valid_command(&request.command)
    {
        return empty_response(StatusCode::SERVICE_UNAVAILABLE);
    }

    let result = match execute(&state, request.command).await {
        Ok(value) if (2..=PRIVATE_RESPONSE_BYTES).contains(&value.len()) => value,
        _ => return empty_response(StatusCode::SERVICE_UNAVAILABLE),
    };
    json_response(result)
}

async fn execute(
    state: &AppState,
    command: DeviceSessionCommand,
) -> anyhow::Result<Vec<u8>> {
    match command {
        DeviceSessionCommand::IssueDeviceSession {
            user_id,
            device_id,
            device_name,
            app_name,
            app_version,
        } => {
            require_tenant_user(state, user_id).await?;
            let device = db::auth::Device {
                id: device_id,
                access_token: crate::common::get_uuid().to_string(),
                user_id,
                name: device_name,
                app_name,
                app_version,
                ..Default::default()
            };
            device
                .save(
                    &state
                        .ctx
                        .db,
                )
                .await?;
            let persisted = get_exact_device(state, user_id, &device.id)
                .await?
                .ok_or_else(|| anyhow::anyhow!("device session missing"))?;
            serde_json::to_vec(&DeviceSessionResult {
                version: 1,
                session: session_dto(persisted)?,
            })
            .map_err(Into::into)
        }
        DeviceSessionCommand::GetDeviceSession { user_id, device_id } => {
            require_tenant_user(state, user_id).await?;
            let device = get_exact_device(state, user_id, &device_id)
                .await?
                .ok_or_else(|| anyhow::anyhow!("device session missing"))?;
            serde_json::to_vec(&DeviceSessionResult {
                version: 1,
                session: session_dto(device)?,
            })
            .map_err(Into::into)
        }
        DeviceSessionCommand::RevokeDeviceSession { user_id, device_id } => {
            require_tenant_user(state, user_id).await?;
            db::auth::Device::delete_by_id(
                &state
                    .ctx
                    .db,
                &device_id,
                &user_id,
            )
            .await?;
            if get_exact_device(state, user_id, &device_id)
                .await?
                .is_some()
            {
                anyhow::bail!("device session remains");
            }
            serde_json::to_vec(&RevokeResult {
                version: 1,
                revoked: true,
            })
            .map_err(Into::into)
        }
    }
}

async fn require_tenant_user(state: &AppState, user_id: Uuid) -> anyhow::Result<()> {
    let user = sqlx::query_as::<_, TenantIdentity>(
        "SELECT username, is_admin FROM users WHERE id = ?1",
    )
    .bind(user_id)
    .fetch_optional(
        &state
            .ctx
            .db,
    )
    .await?
    .ok_or_else(|| anyhow::anyhow!("tenant user missing"))?;
    if user.is_admin || !USERNAME_PATTERN.is_match(&user.username) {
        anyhow::bail!("invalid tenant user");
    }
    Ok(())
}

async fn get_exact_device(
    state: &AppState,
    user_id: Uuid,
    device_id: &str,
) -> anyhow::Result<Option<PersistedSession>> {
    sqlx::query_as::<_, PersistedSession>(
        "SELECT user_id, id, access_token, app_name FROM devices \
         WHERE user_id = ?1 AND id = ?2",
    )
    .bind(user_id)
    .bind(device_id)
    .fetch_optional(
        &state
            .ctx
            .db,
    )
    .await
    .map_err(Into::into)
}

fn session_dto(device: PersistedSession) -> anyhow::Result<SessionDTO> {
    if !valid_uuid(device.user_id)
        || !DEVICE_ID_PATTERN.is_match(&device.id)
        || device.app_name != "Atlas"
        || !TOKEN_PATTERN.is_match(&device.access_token)
    {
        anyhow::bail!("invalid persisted device session");
    }
    Ok(SessionDTO {
        user_id: device.user_id,
        device_id: device.id,
        access_token: device.access_token,
    })
}

fn valid_command(command: &DeviceSessionCommand) -> bool {
    match command {
        DeviceSessionCommand::IssueDeviceSession {
            user_id,
            device_id,
            device_name,
            app_name,
            app_version,
        } => {
            valid_uuid(*user_id)
                && DEVICE_ID_PATTERN.is_match(device_id)
                && SAFE_NAME_PATTERN.is_match(device_name)
                && app_name == "Atlas"
                && VERSION_PATTERN.is_match(app_version)
        }
        DeviceSessionCommand::GetDeviceSession { user_id, device_id }
        | DeviceSessionCommand::RevokeDeviceSession { user_id, device_id } => {
            valid_uuid(*user_id) && DEVICE_ID_PATTERN.is_match(device_id)
        }
    }
}

fn valid_uuid(value: Uuid) -> bool {
    (1..=8).contains(&value.get_version_num())
        && value.get_variant() == Variant::RFC4122
}

fn private_surface_is_exact(request: &Request) -> bool {
    request.method() == Method::POST
        && request
            .uri()
            .path()
            == PRIVATE_PATH
        && request
            .uri()
            .query()
            .is_none()
        && !request
            .headers()
            .contains_key(header::TRANSFER_ENCODING)
        && !request
            .headers()
            .contains_key(header::CONTENT_ENCODING)
        && !request
            .headers()
            .contains_key("x-emby-authorization")
        && !request
            .headers()
            .contains_key("x-emby-token")
        && !request
            .headers()
            .contains_key("x-mediabrowser-token")
        && exact_header(request.headers(), header::CONTENT_TYPE)
            == Some("application/json")
        && canonical_content_length(request.headers()).is_some()
}

fn exact_header(headers: &HeaderMap, name: header::HeaderName) -> Option<&str> {
    let mut values = headers
        .get_all(name)
        .iter();
    let value = values
        .next()?
        .to_str()
        .ok()?;
    if values
        .next()
        .is_some()
        || value.is_empty()
        || value.contains(',')
    {
        return None;
    }
    Some(value)
}

fn canonical_content_length(headers: &HeaderMap) -> Option<usize> {
    let value = exact_header(headers, header::CONTENT_LENGTH)?;
    if value.is_empty()
        || !value
            .bytes()
            .all(|byte| byte.is_ascii_digit())
        || value.len() > 1 && value.starts_with('0')
    {
        return None;
    }
    let length = value
        .parse::<usize>()
        .ok()?;
    (2..=PRIVATE_REQUEST_BYTES)
        .contains(&length)
        .then_some(length)
}

fn empty_response(status: StatusCode) -> Response<Body> {
    Response::builder()
        .status(status)
        .header(header::CACHE_CONTROL, "no-store")
        .header(header::CONTENT_LENGTH, "0")
        .body(Body::empty())
        .expect("static private session response")
}

fn json_response(body: Vec<u8>) -> Response<Body> {
    Response::builder()
        .status(StatusCode::OK)
        .header(header::CONTENT_TYPE, "application/json")
        .header(
            header::CONTENT_LENGTH,
            body.len()
                .to_string(),
        )
        .header(header::CACHE_CONTROL, "no-store")
        .body(Body::from(body))
        .expect("bounded private session response")
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn device_session_commands_are_closed_and_canonical() {
        let user_id = Uuid::parse_str("11111111-1111-4111-8111-111111111111").unwrap();
        let issue = DeviceSessionRequest {
            version: 1,
            command: DeviceSessionCommand::IssueDeviceSession {
                user_id,
                device_id: "atlas-native-22222222-2222-4222-8222-222222222222"
                    .to_string(),
                device_name: "Living Room".to_string(),
                app_name: "Atlas".to_string(),
                app_version: "1.0".to_string(),
            },
        };
        assert!(valid_command(&issue.command));
        assert_eq!(
            String::from_utf8(serde_json::to_vec(&issue).unwrap()).unwrap(),
            r#"{"version":1,"action":"issue_device_session","userId":"11111111-1111-4111-8111-111111111111","deviceId":"atlas-native-22222222-2222-4222-8222-222222222222","deviceName":"Living Room","appName":"Atlas","appVersion":"1.0"}"#,
        );
    }
}
