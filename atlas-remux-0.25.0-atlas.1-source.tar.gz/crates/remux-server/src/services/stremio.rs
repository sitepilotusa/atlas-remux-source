use crate::{
    pathless, sdks,
    sdks::{CachedEndpoint, ClientError, Endpoint, WithExtraQuery},
};
use anyhow::{Result, anyhow};
use futures::{
    future,
    stream::{self, Stream, StreamExt},
};
use std::{
    collections::VecDeque,
    pin::Pin,
    time::{Duration, Instant},
};
use uuid::Uuid;

use tracing::{debug, error};

/// A 404 on a paginated catalog page is the addon's normal "no more pages"
/// signal, not an error — some addons (e.g. fankai) 404 past the last page
/// instead of returning an empty array. Any other error (5xx, rate limit,
/// network blip) is a real problem and must not be conflated with reaching
/// the end of the catalog.
fn is_404(e: &ClientError) -> bool {
    matches!(
        e,
        ClientError::Http { status: 404, .. } | ClientError::Json { status: 404, .. }
    )
}

#[derive(Clone)]
pub struct StremioService {
    pub client: Option<sdks::RestClient>,
    extra_query: Vec<(String, String)>,
    redact_source_errors: bool,
    pathless: Option<PathlessStremioClient>,
}

impl StremioService {
    pub fn is_pathless(&self) -> bool {
        self.pathless
            .is_some()
    }

    pub fn from_url(url: &str) -> Result<Self> {
        Self::from_url_with_policy(url, false)
    }

    #[cfg(test)]
    pub fn from_redacted_no_redirect_url(url: &str) -> Result<Self> {
        Self::from_url_with_policy(url, true)
    }

    /// Construct the fixed Pathless backend after recognizing a non-secret
    /// source or extension marker. No part of the marker is ever fetched.
    pub fn from_atlas_marker(
        url: &str,
        remote_addon_id: Uuid,
        config: &crate::Config,
    ) -> Result<Self> {
        let pathless =
            PathlessStremioClient::from_marker(url, remote_addon_id, config)?;
        Ok(Self {
            client: None,
            extra_query: Vec::new(),
            redact_source_errors: true,
            pathless: Some(pathless),
        })
    }

    fn from_url_with_policy(url: &str, redact_source_errors: bool) -> Result<Self> {
        let parsed = url::Url::parse(url).map_err(|e| anyhow::anyhow!("{e}"))?;
        let extra_query: Vec<(String, String)> = parsed
            .query_pairs()
            .map(|(k, v)| (k.into_owned(), v.into_owned()))
            .collect();
        let mut clean = parsed.clone();
        clean.set_query(None);
        let base = clean
            .as_str()
            .trim_end_matches('/')
            .to_string()
            + "/";
        let client = sdks::stremio::client(&base)?;
        let client = if redact_source_errors {
            client.with_bounded_no_redirect_http(
                Duration::from_secs(2),
                Duration::from_secs(8),
                Duration::from_secs(30),
            )?
        } else {
            client
        };
        Ok(Self {
            client: Some(client),
            extra_query,
            redact_source_errors,
            pathless: None,
        })
    }

    async fn execute<EP>(&self, endpoint: EP) -> Result<EP::Output>
    where
        EP: Endpoint + Clone,
    {
        self.client
            .as_ref()
            .ok_or_else(|| ClientError::Other(anyhow!("Atlas source request failed")))?
            .execute(endpoint)
            .await
            .map_err(|error| redact_source_error(error, self.redact_source_errors))
            .map_err(anyhow::Error::new)
    }

    fn ep<EP: Endpoint + Clone>(&self, endpoint: EP) -> WithExtraQuery<EP> {
        WithExtraQuery {
            endpoint,
            extra: self
                .extra_query
                .clone(),
        }
    }

    pub async fn get_manifest(&self) -> Result<sdks::stremio::Manifest> {
        if let Some(pathless) = &self.pathless {
            return pathless
                .manifest()
                .await;
        }
        Ok(self
            .execute(
                self.ep(sdks::stremio::ManifestEndpoint)
                    .with_cache(Duration::from_secs(3600)),
            )
            .await?)
    }

    pub async fn get_meta(
        &self,
        media_type: sdks::stremio::MediaType,
        id: impl Into<String>,
    ) -> Result<sdks::stremio::Meta> {
        if let Some(pathless) = &self.pathless {
            return pathless
                .meta(media_type, id.into())
                .await;
        }
        let id = id.into();
        Ok(self
            .execute(
                self.ep(sdks::stremio::MetaEndpoint {
                    media_type,
                    id,
                    season: None,
                    episode: None,
                })
                .with_cache(Duration::from_secs(3600)),
            )
            .await?
            .meta)
    }

    pub async fn search(
        &self,
        media_type: sdks::stremio::MediaType,
        q: String,
    ) -> Result<Vec<sdks::stremio::Meta>> {
        if let Some(pathless) = &self.pathless {
            return pathless
                .search(media_type, q)
                .await;
        }
        let catalog = self
            .get_manifest()
            .await?
            .get_search_catalog(&media_type.to_string())
            .ok_or_else(|| anyhow!("no search catalog for type {}", media_type))?;
        Ok(self
            .execute(
                self.ep(sdks::stremio::CatalogEndpoint {
                    kind: catalog
                        .kind
                        .clone(),
                    id: catalog
                        .id
                        .clone(),
                    search: Some(q),
                    genre: None,
                    skip: None,
                })
                .with_cache(Duration::from_secs(60)),
            )
            .await?
            .metas)
    }

    pub async fn get_streams(
        &self,
        media_type: sdks::stremio::MediaType,
        id: impl Into<String>,
    ) -> Result<Vec<sdks::stremio::Stream>> {
        if let Some(pathless) = &self.pathless {
            return pathless
                .streams(media_type, id.into())
                .await;
        }
        let id = id.into();
        Ok(self
            .execute(
                self.ep(sdks::stremio::StreamEndpoint {
                    kind: media_type,
                    id,
                })
                .with_cache(Duration::from_secs(300)),
            )
            .await?
            .streams)
    }

    pub async fn get_subtitles(
        &self,
        media_type: sdks::stremio::MediaType,
        imdb_id: &str,
        season: Option<i64>,
        episode: Option<i64>,
    ) -> Result<Vec<sdks::stremio::Subtitle>> {
        if let Some(pathless) = &self.pathless {
            let id = match (season, episode) {
                (Some(season), Some(episode)) => {
                    format!("{imdb_id}:{season}:{episode}")
                }
                _ => imdb_id.to_string(),
            };
            return pathless
                .subtitles(media_type, id)
                .await;
        }
        Ok(self
            .execute(
                self.ep(sdks::stremio::SubtitlesEndpoint {
                    media_type,
                    imdb_id: imdb_id.to_string(),
                    season,
                    episode,
                })
                .with_cache(Duration::from_secs(86_400)),
            )
            .await?
            .subtitles)
    }

    pub async fn get_catalog_stream(
        &self,
        kind: String,
        id: String,
        supports_skip: bool,
    ) -> Result<Pin<Box<dyn Stream<Item = sdks::stremio::Meta> + Send>>> {
        if let Some(pathless) = &self.pathless {
            return pathless
                .catalog(kind, id, supports_skip)
                .await;
        }
        let client = self
            .client
            .as_ref()
            .expect("ordinary Stremio backend has an HTTP client")
            .clone();
        let extra_query = self
            .extra_query
            .clone();
        let redact_source_errors = self.redact_source_errors;

        let t0 = Instant::now();
        let first_page = client
            .execute(WithExtraQuery {
                endpoint: sdks::stremio::CatalogEndpoint {
                    kind: kind.clone(),
                    id: id.clone(),
                    search: None,
                    genre: None,
                    skip: None,
                },
                extra: extra_query.clone(),
            })
            .await
            .map_err(|error| redact_source_error(error, redact_source_errors))?;

        let page_size = first_page
            .metas
            .len() as u32;
        debug!(kind = %kind, id = %id, page_size, elapsed = ?t0.elapsed(), "catalog first page");
        if page_size == 0 || !supports_skip {
            return Ok(Box::pin(stream::iter(first_page.metas)));
        }

        let first = stream::once(future::ready(Ok(first_page)));

        let rest = stream::iter(1..999u32)
            .map(move |page| {
                let client = client.clone();
                let kind = kind.clone();
                let id = id.clone();
                let extra_query = extra_query.clone();
                async move {
                    let result = client
                        .execute(WithExtraQuery {
                            endpoint: sdks::stremio::CatalogEndpoint {
                                kind: kind.clone(),
                                id: id.clone(),
                                search: None,
                                genre: None,
                                skip: Some(page * page_size),
                            },
                            extra: extra_query,
                        })
                        .await
                        .map_err(|error| {
                            redact_source_error(error, redact_source_errors)
                        });
                    result
                }
            })
            .buffered(3);

        let pages = first
            .chain(rest)
            // `take_while` drops the first item it rejects rather than passing it
            // downstream, so the 404-vs-error distinction has to happen here — by
            // the time a later `filter_map`/`map` would see the `Err`, take_while
            // has already stopped the stream without it.
            .take_while(|result| {
                future::ready(match result {
                    Ok(response) => !response
                        .metas
                        .is_empty(),
                    Err(e) if is_404(e) => {
                        debug!(
                            "stopping catalog pagination: reached end of catalog (404)"
                        );
                        false
                    }
                    Err(e) => {
                        error!(
                            "stopping catalog pagination due to unexpected error: {}",
                            e
                        );
                        false
                    }
                })
            })
            .filter_map(|result| async move {
                match result {
                    Ok(response) => Some(stream::iter(response.metas)),
                    Err(_) => None,
                }
            })
            .flatten();

        Ok(Box::pin(pages))
    }

    pub fn pathless_extension_context(&self) -> Option<(Uuid, u32, Uuid)> {
        let pathless = self
            .pathless
            .as_ref()?;
        let PathlessMarker::Extension {
            extension_id,
            generation,
        } = pathless.marker
        else {
            return None;
        };
        Some((extension_id, generation, pathless.remote_addon_id))
    }

    pub fn is_pathless_source(&self) -> bool {
        self.pathless
            .as_ref()
            .is_some_and(|pathless| {
                matches!(pathless.marker, PathlessMarker::Source { .. })
            })
    }
}

#[derive(Clone)]
struct PathlessStremioClient {
    transport: pathless::Client,
    marker: PathlessMarker,
    remote_addon_id: Uuid,
}

#[derive(Clone, Copy)]
enum PathlessMarker {
    Source {
        source_binding_id: Uuid,
        generation: u32,
    },
    Extension {
        extension_id: Uuid,
        generation: u32,
    },
}

#[derive(Clone, serde::Serialize)]
#[serde(tag = "kind")]
enum PathlessRoute {
    #[serde(rename = "manifest")]
    Manifest,
    #[serde(rename = "catalog")]
    SourceCatalog {
        #[serde(rename = "type")]
        media_type: String,
        #[serde(rename = "catalogId")]
        catalog_id: String,
        skip: u32,
    },
    #[serde(rename = "meta")]
    SourceMeta {
        #[serde(rename = "type")]
        media_type: String,
        #[serde(rename = "sourceId")]
        source_id: String,
    },
    #[serde(rename = "stream")]
    SourceStream {
        #[serde(rename = "type")]
        media_type: String,
        #[serde(rename = "videoId")]
        video_id: String,
    },
    #[serde(rename = "catalog")]
    ExtensionCatalog {
        #[serde(rename = "type")]
        media_type: String,
        id: String,
        extra: Option<PathlessCatalogExtra>,
    },
    #[serde(rename = "meta")]
    ExtensionMeta {
        #[serde(rename = "type")]
        media_type: String,
        id: String,
    },
    #[serde(rename = "stream")]
    ExtensionStream {
        #[serde(rename = "type")]
        media_type: String,
        id: String,
    },
    #[serde(rename = "subtitles")]
    ExtensionSubtitles {
        #[serde(rename = "type")]
        media_type: String,
        id: String,
    },
}

#[derive(Clone, serde::Serialize)]
struct PathlessCatalogExtra {
    name: &'static str,
    value: String,
}

#[derive(serde::Serialize)]
struct SourceRequest<'a> {
    version: u8,
    #[serde(rename = "sourceBindingId")]
    source_binding_id: Uuid,
    generation: u32,
    #[serde(rename = "remoteAddonId")]
    remote_addon_id: Uuid,
    route: &'a PathlessRoute,
}

#[derive(serde::Serialize)]
struct ExtensionRequest<'a> {
    version: u8,
    #[serde(rename = "extensionId")]
    extension_id: Uuid,
    generation: u32,
    #[serde(rename = "remoteAddonId")]
    remote_addon_id: Uuid,
    route: &'a PathlessRoute,
    #[serde(skip_serializing_if = "Option::is_none")]
    probe: Option<&'a ExtensionProbe>,
}

#[derive(serde::Serialize)]
struct ExtensionProbe {
    #[serde(rename = "operationId")]
    operation_id: Uuid,
    #[serde(rename = "attemptId")]
    attempt_id: Uuid,
}

#[derive(serde::Deserialize)]
#[serde(deny_unknown_fields)]
struct SuccessEnvelope<T> {
    version: u8,
    data: T,
}

impl PathlessStremioClient {
    fn from_marker(
        raw: &str,
        remote_addon_id: Uuid,
        config: &crate::Config,
    ) -> Result<Self> {
        let relay_origin = config
            .atlas_extension_relay_origin
            .as_deref()
            .ok_or_else(pathless_error)?;
        let marker =
            parse_pathless_marker(raw, relay_origin).ok_or_else(pathless_error)?;
        Ok(Self {
            transport: pathless::Client::from_config(config)
                .map_err(|_| pathless_error())?,
            marker,
            remote_addon_id,
        })
    }

    async fn request(
        &self,
        route: &PathlessRoute,
        probe: Option<&ExtensionProbe>,
    ) -> Result<pathless::SignedResponse> {
        match self.marker {
            PathlessMarker::Source {
                source_binding_id,
                generation,
            } => {
                if probe.is_some()
                    || matches!(
                        route,
                        PathlessRoute::ExtensionCatalog { .. }
                            | PathlessRoute::ExtensionMeta { .. }
                            | PathlessRoute::ExtensionStream { .. }
                            | PathlessRoute::ExtensionSubtitles { .. }
                    )
                {
                    return Err(pathless_error());
                }
                self.transport
                    .post(
                        pathless::Boundary::Source,
                        &SourceRequest {
                            version: 2,
                            source_binding_id,
                            generation,
                            remote_addon_id: self.remote_addon_id,
                            route,
                        },
                    )
                    .await
            }
            PathlessMarker::Extension {
                extension_id,
                generation,
            } => {
                if (probe.is_some() && !matches!(route, PathlessRoute::Manifest))
                    || matches!(
                        route,
                        PathlessRoute::SourceCatalog { .. }
                            | PathlessRoute::SourceMeta { .. }
                            | PathlessRoute::SourceStream { .. }
                    )
                {
                    return Err(pathless_error());
                }
                let request = ExtensionRequest {
                    version: 2,
                    extension_id,
                    generation,
                    remote_addon_id: self.remote_addon_id,
                    route,
                    probe,
                };
                match probe {
                    Some(_) => {
                        self.transport
                            .post_extension_probe(&request)
                            .await
                    }
                    None => {
                        self.transport
                            .post(pathless::Boundary::Extension, &request)
                            .await
                    }
                }
            }
        }
        .map_err(|_| pathless_error())
    }

    fn decode<T: serde::de::DeserializeOwned>(
        route: &PathlessRoute,
        response: pathless::SignedResponse,
    ) -> Result<T> {
        if response.status != reqwest::StatusCode::OK {
            return Err(pathless_error());
        }
        let maximum_bytes = if matches!(route, PathlessRoute::Manifest) {
            262_144
        } else {
            1_048_576
        };
        if response
            .body
            .len()
            > maximum_bytes
        {
            return Err(pathless_error());
        }
        let mut envelope: serde_json::Value =
            serde_json::from_slice(&response.body).map_err(|_| pathless_error())?;
        let object = exact_object_mut(&mut envelope, &["version", "data"], &[])?;
        if object
            .get("version")
            .and_then(serde_json::Value::as_u64)
            != Some(2)
        {
            return Err(pathless_error());
        }
        let data = object
            .remove("data")
            .ok_or_else(pathless_error)?;
        validate_pathless_data(route, &data)?;
        serde_json::from_value(data).map_err(|_| pathless_error())
    }

    async fn call<T: serde::de::DeserializeOwned>(
        &self,
        route: PathlessRoute,
    ) -> Result<T> {
        let response = self
            .request(&route, None)
            .await?;
        Self::decode(&route, response)
    }

    async fn manifest(&self) -> Result<sdks::stremio::Manifest> {
        let manifest: sdks::stremio::Manifest = self
            .call(PathlessRoute::Manifest)
            .await?;
        validate_pathless_manifest(manifest)
    }

    async fn probe_manifest(&self, probe: &ExtensionProbe) -> Result<bool> {
        let route = PathlessRoute::Manifest;
        let response = self
            .request(&route, Some(probe))
            .await?;
        Self::decode_probe_manifest(response)
    }

    fn decode_probe_manifest(response: pathless::SignedResponse) -> Result<bool> {
        if response.status == reqwest::StatusCode::UNPROCESSABLE_ENTITY {
            return (response
                .body
                .as_slice()
                == br#"{"version":2,"error":{"code":"invalid_manifest"}}"#)
                .then_some(false)
                .ok_or_else(pathless_error);
        }
        let route = PathlessRoute::Manifest;
        let manifest: sdks::stremio::Manifest = Self::decode(&route, response)?;
        validate_pathless_manifest(manifest)?;
        Ok(true)
    }

    async fn meta(
        &self,
        media_type: sdks::stremio::MediaType,
        id: String,
    ) -> Result<sdks::stremio::Meta> {
        let media_type = exact_media_type(&media_type)?;
        let route = match self.marker {
            PathlessMarker::Source { .. } => {
                if !source_id(&id) {
                    return Err(pathless_error());
                }
                PathlessRoute::SourceMeta {
                    media_type: media_type.to_string(),
                    source_id: id,
                }
            }
            PathlessMarker::Extension { .. } => {
                if !safe_segment(&id, 512) {
                    return Err(pathless_error());
                }
                PathlessRoute::ExtensionMeta {
                    media_type: media_type.to_string(),
                    id,
                }
            }
        };
        let response: sdks::stremio::MetaResponse = self
            .call(route)
            .await?;
        validate_meta(&response.meta)?;
        Ok(response.meta)
    }

    async fn streams(
        &self,
        media_type: sdks::stremio::MediaType,
        id: String,
    ) -> Result<Vec<sdks::stremio::Stream>> {
        let media_type = exact_media_type(&media_type)?;
        let route = match self.marker {
            PathlessMarker::Source { .. } => {
                if !video_id(&id) {
                    return Err(pathless_error());
                }
                PathlessRoute::SourceStream {
                    media_type: media_type.to_string(),
                    video_id: id,
                }
            }
            PathlessMarker::Extension { .. } => {
                if !safe_segment(&id, 512) {
                    return Err(pathless_error());
                }
                PathlessRoute::ExtensionStream {
                    media_type: media_type.to_string(),
                    id,
                }
            }
        };
        let response: sdks::stremio::StreamsResponse = self
            .call(route)
            .await?;
        if response
            .streams
            .len()
            > 1_024
        {
            return Err(pathless_error());
        }
        if let PathlessMarker::Source {
            source_binding_id,
            generation,
        } = self.marker
            && response
                .streams
                .iter()
                .any(|stream| {
                    stream
                        .atlas_media_target
                        .as_ref()
                        .and_then(|target| target.parts())
                        .is_none_or(|(binding, observed_generation, _)| {
                            binding != source_binding_id
                                || observed_generation != generation
                        })
                        || stream
                            .url
                            .is_some()
                        || stream
                            .external_url
                            .is_some()
                        || stream
                            .atlas_target_ref
                            .is_some()
                        || !stream
                            .request_headers
                            .is_empty()
                        || !stream
                            .response_headers
                            .is_empty()
                })
        {
            return Err(pathless_error());
        }
        Ok(response.streams)
    }

    async fn subtitles(
        &self,
        media_type: sdks::stremio::MediaType,
        id: String,
    ) -> Result<Vec<sdks::stremio::Subtitle>> {
        let PathlessMarker::Extension { .. } = self.marker else {
            return Err(pathless_error());
        };
        let media_type = exact_media_type(&media_type)?;
        if !safe_segment(&id, 512) {
            return Err(pathless_error());
        }
        let response: sdks::stremio::SubtitlesResponse = self
            .call(PathlessRoute::ExtensionSubtitles {
                media_type: media_type.to_string(),
                id,
            })
            .await?;
        if response
            .subtitles
            .len()
            > 64
            || response
                .subtitles
                .iter()
                .any(|subtitle| {
                    !subtitle
                        .url
                        .is_empty()
                        || !safe_segment(&subtitle.id, 512)
                        || subtitle
                            .lang
                            .as_deref()
                            .is_none_or(|lang| !safe_text(lang, 1, 32))
                        || subtitle
                            .atlas_target_ref
                            .as_ref()
                            .and_then(|target| target.parts())
                            .is_none_or(|(kind, format, _)| {
                                kind != sdks::stremio::AtlasTargetKind::Subtitle
                                    || format.is_none()
                            })
                })
        {
            return Err(pathless_error());
        }
        Ok(response.subtitles)
    }

    async fn search(
        &self,
        media_type: sdks::stremio::MediaType,
        query: String,
    ) -> Result<Vec<sdks::stremio::Meta>> {
        let PathlessMarker::Extension { .. } = self.marker else {
            return Err(pathless_error());
        };
        let media_type = exact_media_type(&media_type)?;
        if !safe_segment(&query, 512) {
            return Err(pathless_error());
        }
        let catalog = self
            .manifest()
            .await?
            .get_search_catalog(&media_type.to_string())
            .ok_or_else(pathless_error)?;
        let response: sdks::stremio::CatalogResponse = self
            .call(PathlessRoute::ExtensionCatalog {
                media_type: media_type.to_string(),
                id: catalog.id,
                extra: Some(PathlessCatalogExtra {
                    name: "search",
                    value: query,
                }),
            })
            .await?;
        validate_catalog(response.metas)
    }

    async fn catalog(
        &self,
        kind: String,
        id: String,
        supports_skip: bool,
    ) -> Result<Pin<Box<dyn Stream<Item = sdks::stremio::Meta> + Send>>> {
        if !matches!(kind.as_str(), "movie" | "series") || !safe_segment(&id, 128) {
            return Err(pathless_error());
        }
        let first = self
            .catalog_page(kind.clone(), id.clone(), 0)
            .await?;
        let page_size = u32::try_from(first.len()).map_err(|_| pathless_error())?;
        if first.is_empty() || !supports_skip {
            return Ok(Box::pin(stream::iter(first)));
        }
        let first_stream = stream::iter(first);
        let state = CatalogState {
            client: self.clone(),
            kind,
            id,
            next_skip: page_size,
            page_size,
            pending: VecDeque::new(),
        };
        let rest = stream::unfold(state, |mut state| async move {
            if let Some(meta) = state
                .pending
                .pop_front()
            {
                return Some((meta, state));
            }
            if state.next_skip > 10_000 {
                return None;
            }
            let page = state
                .client
                .catalog_page(
                    state
                        .kind
                        .clone(),
                    state
                        .id
                        .clone(),
                    state.next_skip,
                )
                .await
                .ok()?;
            if page.is_empty() {
                return None;
            }
            state.next_skip = state
                .next_skip
                .saturating_add(state.page_size);
            state.pending = page.into();
            state
                .pending
                .pop_front()
                .map(|meta| (meta, state))
        });
        Ok(Box::pin(first_stream.chain(rest)))
    }

    async fn catalog_page(
        &self,
        kind: String,
        id: String,
        skip: u32,
    ) -> Result<Vec<sdks::stremio::Meta>> {
        if skip > 10_000 {
            return Err(pathless_error());
        }
        let route = match self.marker {
            PathlessMarker::Source { .. } => PathlessRoute::SourceCatalog {
                media_type: kind,
                catalog_id: id,
                skip,
            },
            PathlessMarker::Extension { .. } => PathlessRoute::ExtensionCatalog {
                media_type: kind,
                id,
                extra: (skip > 0).then(|| PathlessCatalogExtra {
                    name: "skip",
                    value: skip.to_string(),
                }),
            },
        };
        let response: sdks::stremio::CatalogResponse = self
            .call(route)
            .await?;
        validate_catalog(response.metas)
    }
}

fn validate_pathless_manifest(
    manifest: sdks::stremio::Manifest,
) -> Result<sdks::stremio::Manifest> {
    if manifest
        .types
        .len()
        > 2
        || manifest
            .types
            .iter()
            .any(|kind| !matches!(kind.as_str(), "movie" | "series"))
        || manifest
            .types
            .windows(2)
            .any(|pair| pair[0] >= pair[1])
        || manifest
            .catalogs
            .len()
            > 128
        || manifest
            .catalogs
            .iter()
            .any(|catalog| {
                !matches!(
                    catalog
                        .kind
                        .as_str(),
                    "movie" | "series"
                ) || !safe_segment(&catalog.id, 128)
            })
    {
        return Err(pathless_error());
    }
    Ok(manifest)
}

pub(crate) async fn probe_pathless_extension_manifest(
    config: &crate::Config,
    extension_id: Uuid,
    generation: u32,
    remote_addon_id: Uuid,
    operation_id: Uuid,
    attempt_id: Uuid,
) -> Result<bool> {
    if generation == 0
        || generation > i32::MAX as u32
        || [extension_id, remote_addon_id, operation_id, attempt_id]
            .into_iter()
            .any(|value| {
                value.get_variant() != uuid::Variant::RFC4122
                    || !(1..=8).contains(&value.get_version_num())
            })
    {
        return Err(pathless_error());
    }
    PathlessStremioClient {
        transport: pathless::Client::from_config(config)
            .map_err(|_| pathless_error())?,
        marker: PathlessMarker::Extension {
            extension_id,
            generation,
        },
        remote_addon_id,
    }
    .probe_manifest(&ExtensionProbe {
        operation_id,
        attempt_id,
    })
    .await
}

struct CatalogState {
    client: PathlessStremioClient,
    kind: String,
    id: String,
    next_skip: u32,
    page_size: u32,
    pending: VecDeque<sdks::stremio::Meta>,
}

fn parse_pathless_marker(raw: &str, relay_origin: &str) -> Option<PathlessMarker> {
    let parsed = url::Url::parse(raw).ok()?;
    if parsed
        .origin()
        .ascii_serialization()
        != relay_origin
        || parsed.username() != ""
        || parsed
            .password()
            .is_some()
        || parsed
            .port()
            .is_some()
        || parsed
            .query()
            .is_some()
        || parsed
            .fragment()
            .is_some()
        || parsed.as_str() != raw
    {
        return None;
    }
    for (prefix, source) in [
        ("/.well-known/atlas-source/", true),
        ("/.well-known/atlas-extension/", false),
    ] {
        let Some(suffix) = parsed
            .path()
            .strip_prefix(prefix)
        else {
            continue;
        };
        let Some((binding, tail)) = suffix.split_once('/') else {
            continue;
        };
        let Some(generation) = tail.strip_suffix("/manifest.json") else {
            continue;
        };
        if generation.is_empty()
            || generation.starts_with('0')
            || !generation
                .bytes()
                .all(|byte| byte.is_ascii_digit())
        {
            continue;
        }
        let generation = generation
            .parse::<u32>()
            .ok()?;
        if generation == 0 || generation > i32::MAX as u32 {
            continue;
        }
        let binding_id = Uuid::parse_str(binding).ok()?;
        if binding_id.to_string() != binding
            || binding_id.get_variant() != uuid::Variant::RFC4122
            || !(1..=8).contains(&binding_id.get_version_num())
        {
            continue;
        }
        return Some(if source {
            PathlessMarker::Source {
                source_binding_id: binding_id,
                generation,
            }
        } else {
            PathlessMarker::Extension {
                extension_id: binding_id,
                generation,
            }
        });
    }
    None
}

fn exact_media_type(media_type: &sdks::stremio::MediaType) -> Result<&'static str> {
    match media_type {
        sdks::stremio::MediaType::Movie => Ok("movie"),
        sdks::stremio::MediaType::Series => Ok("series"),
        _ => Err(pathless_error()),
    }
}

fn source_id(value: &str) -> bool {
    atlas_source_identifier(value)
}

fn video_id(value: &str) -> bool {
    atlas_source_identifier(value)
}

fn atlas_source_identifier(value: &str) -> bool {
    let Some(encoded) = value.strip_prefix("atlas:") else {
        return false;
    };
    uuid::Uuid::parse_str(encoded)
        .ok()
        .is_some_and(|parsed| {
            parsed.to_string() == encoded
                && parsed.get_variant() == uuid::Variant::RFC4122
                && (1..=8).contains(&parsed.get_version_num())
        })
}

fn safe_segment(value: &str, maximum: usize) -> bool {
    safe_text(value, 1, maximum)
        && !value
            .bytes()
            .any(|byte| matches!(byte, b'/' | b'\\'))
}

fn safe_text(value: &str, minimum: usize, maximum: usize) -> bool {
    (minimum..=maximum).contains(
        &value
            .chars()
            .count(),
    ) && !value
        .chars()
        .any(char::is_control)
}

fn validate_catalog(
    metas: Vec<sdks::stremio::Meta>,
) -> Result<Vec<sdks::stremio::Meta>> {
    if metas.len() > 256 {
        return Err(pathless_error());
    }
    for meta in &metas {
        validate_meta(meta)?;
    }
    Ok(metas)
}

fn validate_meta(meta: &sdks::stremio::Meta) -> Result<()> {
    if !matches!(
        &meta.media_type,
        sdks::stremio::MediaType::Movie | sdks::stremio::MediaType::Series
    ) || !safe_segment(&meta.id, 512)
    {
        return Err(pathless_error());
    }
    Ok(())
}

fn pathless_error() -> anyhow::Error {
    anyhow!("Atlas Pathless request failed")
}

fn validate_pathless_data(
    route: &PathlessRoute,
    data: &serde_json::Value,
) -> Result<()> {
    if contains_url_string(data, 0) {
        return Err(pathless_error());
    }
    match route {
        PathlessRoute::Manifest => validate_manifest_json(data),
        PathlessRoute::SourceCatalog { .. }
        | PathlessRoute::ExtensionCatalog { .. } => {
            let object = exact_object(data, &["metas"], &[])?;
            let metas = bounded_array(object.get("metas"), 256)?;
            for meta in metas {
                validate_meta_json(meta, false)?;
            }
            Ok(())
        }
        PathlessRoute::SourceMeta { .. } | PathlessRoute::ExtensionMeta { .. } => {
            let object = exact_object(data, &["meta"], &[])?;
            validate_meta_json(
                object
                    .get("meta")
                    .ok_or_else(pathless_error)?,
                true,
            )
        }
        PathlessRoute::SourceStream { .. } => {
            let object = exact_object(data, &["streams"], &[])?;
            for stream in bounded_array(object.get("streams"), 64)? {
                let stream = exact_object(
                    stream,
                    &["name", "title", "atlasMediaTarget"],
                    &["description"],
                )?;
                required_formatted_text(stream, "name", 1, 200)?;
                required_formatted_text(stream, "title", 1, 500)?;
                optional_formatted_text(stream, "description", 0, 2_000)?;
                validate_media_target(
                    stream
                        .get("atlasMediaTarget")
                        .ok_or_else(pathless_error)?,
                )?;
            }
            Ok(())
        }
        PathlessRoute::ExtensionStream { .. } => {
            let object = exact_object(data, &["streams"], &[])?;
            for stream in bounded_array(object.get("streams"), 1_024)? {
                let stream = exact_object(
                    stream,
                    &["atlasTargetRef"],
                    &[
                        "name",
                        "title",
                        "description",
                        "thumbnail",
                        "atlasStreamFacts",
                    ],
                )?;
                validate_target_ref(
                    stream
                        .get("atlasTargetRef")
                        .ok_or_else(pathless_error)?,
                    "stream",
                )?;
                optional_formatted_text(stream, "name", 0, 200)?;
                optional_formatted_text(stream, "title", 0, 500)?;
                optional_formatted_text(stream, "description", 0, 2_000)?;
                if let Some(thumbnail) = stream.get("thumbnail") {
                    validate_image_json(thumbnail)?;
                }
                if let Some(facts) = stream.get("atlasStreamFacts") {
                    let facts: remux_sdks::remux::AtlasStreamFacts =
                        serde_json::from_value(facts.clone())
                            .map_err(|_| pathless_error())?;
                    if !facts.is_closed_and_safe() {
                        return Err(pathless_error());
                    }
                }
            }
            Ok(())
        }
        PathlessRoute::ExtensionSubtitles { .. } => {
            let object = exact_object(data, &["subtitles"], &[])?;
            for subtitle in bounded_array(object.get("subtitles"), 64)? {
                let subtitle =
                    exact_object(subtitle, &["id", "lang", "atlasTargetRef"], &[])?;
                required_safe_segment(subtitle, "id", 512)?;
                required_text(subtitle, "lang", 1, 32)?;
                validate_target_ref(
                    subtitle
                        .get("atlasTargetRef")
                        .ok_or_else(pathless_error)?,
                    "subtitle",
                )?;
            }
            Ok(())
        }
    }
}

fn validate_manifest_json(value: &serde_json::Value) -> Result<()> {
    let object = exact_object(
        value,
        &["id", "name", "resources", "types", "catalogs"],
        &["description", "version", "idPrefixes", "logo", "background"],
    )?;
    required_safe_segment(object, "id", 128)?;
    required_text(object, "name", 1, 200)?;
    optional_text(object, "description", 0, 2_000)?;
    optional_text(object, "version", 0, 64)?;
    if let Some(logo) = object.get("logo") {
        validate_image_json(logo)?;
    }
    if let Some(background) = object.get("background") {
        validate_image_json(background)?;
    }
    let resources = bounded_array(object.get("resources"), 4)?;
    if resources.is_empty()
        || !sorted_unique_values(resources)
        || resources
            .iter()
            .any(|resource| {
                !matches!(
                    resource.as_str(),
                    Some("catalog" | "meta" | "stream" | "subtitles")
                )
            })
    {
        return Err(pathless_error());
    }

    let types = bounded_array(object.get("types"), 2)?;
    if types.is_empty()
        || !sorted_unique_values(types)
        || types
            .iter()
            .any(|kind| !matches!(kind.as_str(), Some("movie" | "series")))
    {
        return Err(pathless_error());
    }

    if let Some(prefixes) = object.get("idPrefixes") {
        let prefixes = bounded_array(Some(prefixes), 64)?;
        if !unique_text_values(prefixes, 1, 128) {
            return Err(pathless_error());
        }
    }

    let catalogs = bounded_array(object.get("catalogs"), 128)?;
    for catalog in catalogs {
        let catalog = exact_object(catalog, &["type", "id"], &["name", "extra"])?;
        required_safe_segment(catalog, "id", 128)?;
        optional_text(catalog, "name", 0, 200)?;
        if !matches!(
            catalog
                .get("type")
                .and_then(serde_json::Value::as_str),
            Some("movie" | "series")
        ) {
            return Err(pathless_error());
        }
        if let Some(extra) = catalog.get("extra") {
            let extra = bounded_array(Some(extra), 2)?;
            let mut names = std::collections::HashSet::new();
            for entry in extra {
                let entry = exact_object(entry, &["name"], &["isRequired", "options"])?;
                let name = entry
                    .get("name")
                    .and_then(serde_json::Value::as_str)
                    .ok_or_else(pathless_error)?;
                if !matches!(name, "search" | "skip") || !names.insert(name) {
                    return Err(pathless_error());
                }
                if entry
                    .get("isRequired")
                    .is_some_and(|value| !value.is_boolean())
                {
                    return Err(pathless_error());
                }
                if let Some(options) = entry.get("options") {
                    let options = bounded_array(Some(options), 64)?;
                    if !unique_catalog_options(options) {
                        return Err(pathless_error());
                    }
                }
            }
        }
    }
    Ok(())
}

fn validate_meta_json(value: &serde_json::Value, full: bool) -> Result<()> {
    const PREVIEW_OPTIONAL: &[&str] = &[
        "description",
        "releaseInfo",
        "imdbRating",
        "year",
        "genres",
        "posterShape",
        "poster",
        "background",
        "logo",
    ];
    const FULL_OPTIONAL: &[&str] = &[
        "description",
        "releaseInfo",
        "imdbRating",
        "year",
        "genres",
        "posterShape",
        "poster",
        "background",
        "logo",
        "runtime",
        "language",
        "country",
        "awards",
        "videos",
    ];
    let object = exact_object(
        value,
        &["id", "type", "name"],
        if full {
            FULL_OPTIONAL
        } else {
            PREVIEW_OPTIONAL
        },
    )?;
    required_safe_segment(object, "id", 512)?;
    required_text(object, "name", 1, 200)?;
    if !matches!(
        object
            .get("type")
            .and_then(serde_json::Value::as_str),
        Some("movie" | "series")
    ) {
        return Err(pathless_error());
    }
    optional_text(object, "description", 0, 2_000)?;
    optional_text(object, "releaseInfo", 0, 64)?;
    optional_text(object, "imdbRating", 0, 16)?;
    optional_text(object, "runtime", 0, 256)?;
    optional_text(object, "language", 0, 32)?;
    optional_text(object, "country", 0, 256)?;
    optional_text(object, "awards", 0, 256)?;
    if object
        .get("year")
        .is_some_and(|year| {
            year.as_u64()
                .is_none_or(|year| !(1..=9_999).contains(&year))
        })
    {
        return Err(pathless_error());
    }
    if object
        .get("posterShape")
        .is_some_and(|shape| {
            !matches!(shape.as_str(), Some("poster" | "landscape" | "square"))
        })
    {
        return Err(pathless_error());
    }
    if let Some(genres) = object.get("genres") {
        let genres = bounded_array(Some(genres), 32)?;
        if !unique_text_values(genres, 1, 64) {
            return Err(pathless_error());
        }
    }
    for field in ["poster", "background", "logo"] {
        if let Some(image) = object.get(field) {
            validate_image_json(image)?;
        }
    }
    if let Some(videos) = object.get("videos") {
        for video in bounded_array(Some(videos), 256)? {
            let video = exact_object(
                video,
                &["id", "title"],
                &["overview", "season", "episode", "thumbnail"],
            )?;
            required_safe_segment(video, "id", 512)?;
            required_text(video, "title", 1, 200)?;
            optional_text(video, "overview", 0, 2_000)?;
            if video
                .get("season")
                .is_some_and(|season| {
                    season
                        .as_u64()
                        .is_none_or(|season| season > 9_999)
                })
                || video
                    .get("episode")
                    .is_some_and(|episode| {
                        episode
                            .as_u64()
                            .is_none_or(|episode| episode > 999_999)
                    })
            {
                return Err(pathless_error());
            }
            if let Some(thumbnail) = video.get("thumbnail") {
                validate_image_json(thumbnail)?;
            }
        }
    }
    Ok(())
}

fn validate_image_json(value: &serde_json::Value) -> Result<()> {
    if value.is_null() {
        return Ok(());
    }
    let wrapper = exact_object(value, &["atlasTargetRef"], &[])?;
    validate_target_ref(
        wrapper
            .get("atlasTargetRef")
            .ok_or_else(pathless_error)?,
        "image",
    )
}

fn validate_target_ref(value: &serde_json::Value, expected_kind: &str) -> Result<()> {
    let target = exact_object(value, &["version", "kind", "format", "sealedRef"], &[])?;
    let format = target
        .get("format")
        .ok_or_else(pathless_error)?;
    let sealed_ref = target
        .get("sealedRef")
        .and_then(serde_json::Value::as_str)
        .ok_or_else(pathless_error)?;
    if target
        .get("version")
        .and_then(serde_json::Value::as_u64)
        != Some(2)
        || target
            .get("kind")
            .and_then(serde_json::Value::as_str)
            != Some(expected_kind)
        || expected_kind == "subtitle"
            && !matches!(format.as_str(), Some("vtt" | "srt" | "ass" | "ssa"))
        || expected_kind != "subtitle" && !format.is_null()
        || !canonical_sealed_ref(sealed_ref)
    {
        return Err(pathless_error());
    }
    Ok(())
}

fn validate_media_target(value: &serde_json::Value) -> Result<()> {
    let target = exact_object(
        value,
        &["version", "sourceBindingId", "generation", "mediaId"],
        &[],
    )?;
    if target
        .get("version")
        .and_then(serde_json::Value::as_u64)
        != Some(2)
        || target
            .get("generation")
            .and_then(serde_json::Value::as_u64)
            .is_none_or(|generation| !(1..=i32::MAX as u64).contains(&generation))
        || !target
            .get("sourceBindingId")
            .is_some_and(canonical_uuid_json)
        || !target
            .get("mediaId")
            .is_some_and(canonical_uuid_json)
    {
        return Err(pathless_error());
    }
    Ok(())
}

fn exact_object<'a>(
    value: &'a serde_json::Value,
    required: &[&str],
    optional: &[&str],
) -> Result<&'a serde_json::Map<String, serde_json::Value>> {
    let object = value
        .as_object()
        .ok_or_else(pathless_error)?;
    if required
        .iter()
        .any(|key| !object.contains_key(*key))
        || object
            .keys()
            .any(|key| {
                !required.contains(&key.as_str()) && !optional.contains(&key.as_str())
            })
    {
        return Err(pathless_error());
    }
    Ok(object)
}

fn exact_object_mut<'a>(
    value: &'a mut serde_json::Value,
    required: &[&str],
    optional: &[&str],
) -> Result<&'a mut serde_json::Map<String, serde_json::Value>> {
    let object = value
        .as_object_mut()
        .ok_or_else(pathless_error)?;
    if required
        .iter()
        .any(|key| !object.contains_key(*key))
        || object
            .keys()
            .any(|key| {
                !required.contains(&key.as_str()) && !optional.contains(&key.as_str())
            })
    {
        return Err(pathless_error());
    }
    Ok(object)
}

fn bounded_array(
    value: Option<&serde_json::Value>,
    maximum: usize,
) -> Result<&[serde_json::Value]> {
    let values = value
        .and_then(serde_json::Value::as_array)
        .ok_or_else(pathless_error)?;
    (values.len() <= maximum)
        .then_some(values.as_slice())
        .ok_or_else(pathless_error)
}

fn required_safe_segment(
    object: &serde_json::Map<String, serde_json::Value>,
    key: &str,
    maximum: usize,
) -> Result<()> {
    object
        .get(key)
        .and_then(serde_json::Value::as_str)
        .filter(|value| safe_segment(value, maximum))
        .map(|_| ())
        .ok_or_else(pathless_error)
}

fn required_text(
    object: &serde_json::Map<String, serde_json::Value>,
    key: &str,
    minimum: usize,
    maximum: usize,
) -> Result<()> {
    object
        .get(key)
        .and_then(serde_json::Value::as_str)
        .filter(|value| safe_text(value, minimum, maximum))
        .map(|_| ())
        .ok_or_else(pathless_error)
}

fn optional_text(
    object: &serde_json::Map<String, serde_json::Value>,
    key: &str,
    minimum: usize,
    maximum: usize,
) -> Result<()> {
    match object.get(key) {
        None => Ok(()),
        Some(value) => value
            .as_str()
            .filter(|value| safe_text(value, minimum, maximum))
            .map(|_| ())
            .ok_or_else(pathless_error),
    }
}

fn safe_formatted_text(value: &str, minimum: usize, maximum: usize) -> bool {
    (minimum..=maximum).contains(
        &value
            .chars()
            .count(),
    ) && value
        .split('\n')
        .count()
        <= 16
        && value
            .chars()
            .all(|character| {
                character == '\n'
                    || !character.is_control()
                        && !matches!(
                            character,
                            '\u{202a}'..='\u{202e}' | '\u{2066}'..='\u{2069}'
                        )
            })
}

fn required_formatted_text(
    object: &serde_json::Map<String, serde_json::Value>,
    key: &str,
    minimum: usize,
    maximum: usize,
) -> Result<()> {
    object
        .get(key)
        .and_then(serde_json::Value::as_str)
        .filter(|value| safe_formatted_text(value, minimum, maximum))
        .map(|_| ())
        .ok_or_else(pathless_error)
}

fn optional_formatted_text(
    object: &serde_json::Map<String, serde_json::Value>,
    key: &str,
    minimum: usize,
    maximum: usize,
) -> Result<()> {
    match object.get(key) {
        None => Ok(()),
        Some(value) => value
            .as_str()
            .filter(|value| safe_formatted_text(value, minimum, maximum))
            .map(|_| ())
            .ok_or_else(pathless_error),
    }
}

fn sorted_unique_values(values: &[serde_json::Value]) -> bool {
    values
        .windows(2)
        .all(|pair| {
            pair[0]
                .as_str()
                .zip(pair[1].as_str())
                .is_some_and(|(left, right)| left < right)
        })
}

fn unique_text_values(
    values: &[serde_json::Value],
    minimum: usize,
    maximum: usize,
) -> bool {
    let mut observed = std::collections::HashSet::new();
    values
        .iter()
        .all(|value| {
            value
                .as_str()
                .filter(|value| safe_text(value, minimum, maximum))
                .is_some_and(|value| observed.insert(value))
        })
}

fn unique_catalog_options(values: &[serde_json::Value]) -> bool {
    let mut observed = std::collections::HashSet::new();
    values
        .iter()
        .all(|value| {
            let Some(value) = value.as_str() else {
                return false;
            };
            let bytes = value.as_bytes();
            if !(1..=128).contains(&bytes.len())
                || !bytes[0].is_ascii_alphanumeric()
                || !bytes[bytes.len() - 1].is_ascii_alphanumeric()
                || bytes
                    .iter()
                    .any(|byte| {
                        !byte.is_ascii_alphanumeric()
                            && !matches!(byte, b' ' | b'.' | b'_' | b':' | b'-')
                    })
            {
                return false;
            }
            observed.insert(value)
        })
}

fn canonical_sealed_ref(value: &str) -> bool {
    use base64::{Engine as _, engine::general_purpose::URL_SAFE_NO_PAD};

    !value.is_empty()
        && value.len() <= 3_600
        && URL_SAFE_NO_PAD
            .decode(value)
            .ok()
            .is_some_and(|decoded| URL_SAFE_NO_PAD.encode(decoded) == value)
}

fn canonical_uuid_json(value: &serde_json::Value) -> bool {
    value
        .as_str()
        .is_some_and(|encoded| {
            uuid::Uuid::parse_str(encoded)
                .ok()
                .is_some_and(|parsed| {
                    parsed.to_string() == encoded
                        && parsed.get_variant() == uuid::Variant::RFC4122
                        && (1..=8).contains(&parsed.get_version_num())
                })
        })
}

fn contains_url_string(value: &serde_json::Value, depth: usize) -> bool {
    if depth > 64 {
        return true;
    }
    match value {
        serde_json::Value::String(text) => text.contains("://"),
        serde_json::Value::Array(values) => values
            .iter()
            .any(|value| contains_url_string(value, depth + 1)),
        serde_json::Value::Object(values) => values
            .values()
            .any(|value| contains_url_string(value, depth + 1)),
        _ => false,
    }
}

fn redact_source_error(error: ClientError, redact: bool) -> ClientError {
    if !redact {
        return error;
    }
    match error {
        ClientError::Unauthorized => ClientError::Unauthorized,
        ClientError::RateLimited { retry_after_secs } => {
            ClientError::RateLimited { retry_after_secs }
        }
        ClientError::Http { status, .. } | ClientError::Json { status, .. } => {
            ClientError::Http {
                status,
                message: "Atlas source request failed".to_string(),
                endpoint: None,
                body: None,
            }
        }
        ClientError::Transport(source) => match source.status() {
            Some(status) => ClientError::Http {
                status: status.as_u16(),
                message: "Atlas source request failed".to_string(),
                endpoint: None,
                body: None,
            },
            None => ClientError::Other(anyhow!("Atlas source transport failed")),
        },
        ClientError::Url(_) => ClientError::Other(anyhow!("Atlas source URL failed")),
        ClientError::UrlEncoded(_) => {
            ClientError::Other(anyhow!("Atlas source request encoding failed"))
        }
        ClientError::Other(_) => {
            ClientError::Other(anyhow!("Atlas source request failed"))
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn extension_route(kind: &'static str) -> PathlessRoute {
        match kind {
            "stream" => PathlessRoute::ExtensionStream {
                media_type: "movie".to_string(),
                id: "owner-item".to_string(),
            },
            "subtitles" => PathlessRoute::ExtensionSubtitles {
                media_type: "movie".to_string(),
                id: "owner-item".to_string(),
            },
            _ => panic!("unsupported test route"),
        }
    }

    fn target_ref(kind: &str, format: serde_json::Value) -> serde_json::Value {
        serde_json::json!({
            "version": 2,
            "kind": kind,
            "format": format,
            "sealedRef": "AQID"
        })
    }

    #[test]
    fn atlas_extension_probe_request_and_result_taxonomy_are_exact() {
        let extension_id =
            Uuid::parse_str("11111111-1111-4111-8111-111111111111").unwrap();
        let remote_addon_id =
            Uuid::parse_str("22222222-2222-4222-8222-222222222222").unwrap();
        let operation_id =
            Uuid::parse_str("33333333-3333-4333-8333-333333333333").unwrap();
        let attempt_id =
            Uuid::parse_str("44444444-4444-4444-8444-444444444444").unwrap();
        let route = PathlessRoute::Manifest;
        let probe = ExtensionProbe {
            operation_id,
            attempt_id,
        };
        let request = |probe| ExtensionRequest {
            version: 2,
            extension_id,
            generation: 7,
            remote_addon_id,
            route: &route,
            probe,
        };
        assert_eq!(
            serde_json::to_string(&request(None)).unwrap(),
            r#"{"version":2,"extensionId":"11111111-1111-4111-8111-111111111111","generation":7,"remoteAddonId":"22222222-2222-4222-8222-222222222222","route":{"kind":"manifest"}}"#
        );
        assert_eq!(
            serde_json::to_string(&request(Some(&probe))).unwrap(),
            r#"{"version":2,"extensionId":"11111111-1111-4111-8111-111111111111","generation":7,"remoteAddonId":"22222222-2222-4222-8222-222222222222","route":{"kind":"manifest"},"probe":{"operationId":"33333333-3333-4333-8333-333333333333","attemptId":"44444444-4444-4444-8444-444444444444"}}"#
        );

        let valid = pathless::SignedResponse {
            status: reqwest::StatusCode::OK,
            body: br#"{"version":2,"data":{"id":"owner-addon","name":"Owner addon","resources":["stream"],"types":["movie"],"catalogs":[]}}"#.to_vec(),
        };
        assert!(PathlessStremioClient::decode_probe_manifest(valid).unwrap());
        let invalid = pathless::SignedResponse {
            status: reqwest::StatusCode::UNPROCESSABLE_ENTITY,
            body: br#"{"version":2,"error":{"code":"invalid_manifest"}}"#.to_vec(),
        };
        assert!(!PathlessStremioClient::decode_probe_manifest(invalid).unwrap());

        for rejected in [
            pathless::SignedResponse {
                status: reqwest::StatusCode::UNPROCESSABLE_ENTITY,
                body: br#"{"version":2,"error":{"code":"unavailable"}}"#.to_vec(),
            },
            pathless::SignedResponse {
                status: reqwest::StatusCode::OK,
                body: br#"{"version":2,"data":{"id":"bad"}}"#.to_vec(),
            },
            pathless::SignedResponse {
                status: reqwest::StatusCode::UNAUTHORIZED,
                body: br#"{"version":2,"error":{"code":"unauthorized"}}"#.to_vec(),
            },
            pathless::SignedResponse {
                status: reqwest::StatusCode::NOT_FOUND,
                body: br#"{"version":2,"error":{"code":"not_found"}}"#.to_vec(),
            },
            pathless::SignedResponse {
                status: reqwest::StatusCode::CONFLICT,
                body: br#"{"version":2,"error":{"code":"replayed"}}"#.to_vec(),
            },
            pathless::SignedResponse {
                status: reqwest::StatusCode::TOO_MANY_REQUESTS,
                body: br#"{"version":2,"error":{"code":"rate_limited"}}"#.to_vec(),
            },
            pathless::SignedResponse {
                status: reqwest::StatusCode::SERVICE_UNAVAILABLE,
                body: br#"{"version":2,"error":{"code":"unavailable"}}"#.to_vec(),
            },
        ] {
            assert!(PathlessStremioClient::decode_probe_manifest(rejected).is_err());
        }
    }

    #[test]
    fn atlas_extension_validator_accepts_only_the_frozen_minimal_shapes() {
        let manifest = serde_json::json!({
            "id": "owner-addon",
            "name": "Owner addon",
            "resources": ["catalog", "meta", "stream", "subtitles"],
            "types": ["movie", "series"],
            "catalogs": [{
                "type": "movie",
                "id": "owner-catalog",
                "extra": [{
                    "name": "search",
                    "options": ["Action", "Drama: 2026"]
                }]
            }],
            "logo": null,
            "background": {"atlasTargetRef": target_ref("image", serde_json::Value::Null)}
        });
        validate_pathless_data(&PathlessRoute::Manifest, &manifest).expect(
            "version and catalog name are optional; image null/object are valid",
        );

        let stream = serde_json::json!({
            "streams": [{
                "atlasTargetRef": target_ref("stream", serde_json::Value::Null),
                "name": "Owner stream\n4K • Dolby Vision",
                "title": "Cached\n18.4 GB",
                "atlasStreamFacts": {
                    "Version": 1,
                    "Resolution": 2160,
                    "SizeBytes": 24696061952_u64,
                    "VideoCodec": "hevc",
                    "DynamicRange": ["hdr10", "dv"],
                    "AudioFormats": ["atmos"],
                    "AudioLanguages": ["en"],
                    "MultiAudio": true,
                    "ReleaseKind": "remux",
                    "Cached": true,
                    "Filename": "Owner.Movie.2160p.mkv",
                    "GroupKey": format!("agk1_{}", "A".repeat(43)),
                    "JunkMarker": "commentary"
                },
                "thumbnail": {"atlasTargetRef": target_ref("image", serde_json::Value::Null)}
            }]
        });
        validate_pathless_data(&extension_route("stream"), &stream)
            .expect("bounded multi-line formatter output must be accepted");

        for invalid_name in ["line\n".repeat(17), "safe\u{202e}unsafe".to_string()] {
            let invalid = serde_json::json!({
                "streams": [{
                    "atlasTargetRef": target_ref("stream", serde_json::Value::Null),
                    "name": invalid_name
                }]
            });
            assert!(
                validate_pathless_data(&extension_route("stream"), &invalid).is_err()
            );
        }

        let subtitles = serde_json::json!({
            "subtitles": [{
                "id": "english",
                "lang": "eng",
                "atlasTargetRef": target_ref("subtitle", serde_json::json!("vtt"))
            }]
        });
        validate_pathless_data(&extension_route("subtitles"), &subtitles)
            .expect("exact subtitle reference must be accepted");
    }

    #[test]
    fn atlas_extension_validator_rejects_unknown_types_keys_nulls_and_caps() {
        let base_manifest = || {
            serde_json::json!({
                "id": "owner-addon",
                "name": "Owner addon",
                "resources": ["catalog", "meta", "stream"],
                "types": ["movie", "series"],
                "catalogs": []
            })
        };
        for invalid in [
            {
                let mut value = base_manifest();
                value["types"] = serde_json::json!(["anime"]);
                value
            },
            {
                let mut value = base_manifest();
                value["types"] = serde_json::json!(["series", "movie"]);
                value
            },
            {
                let mut value = base_manifest();
                value["resources"] = serde_json::json!(["stream", "meta"]);
                value
            },
            {
                let mut value = base_manifest();
                value["providerUrl"] = serde_json::json!("https://provider.invalid");
                value
            },
            {
                let mut value = base_manifest();
                value["description"] = serde_json::Value::Null;
                value
            },
            {
                let mut value = base_manifest();
                value["catalogs"] = serde_json::Value::Array(
                    (0..129)
                        .map(|index| serde_json::json!({"type": "movie", "id": format!("c{index}")}))
                        .collect(),
                );
                value
            },
            {
                let mut value = base_manifest();
                value["catalogs"] = serde_json::json!([{
                    "type": "movie",
                    "id": "owner-catalog",
                    "extra": [{"name": "search", "options": [" leading"]}]
                }]);
                value
            },
            {
                let mut value = base_manifest();
                value["catalogs"] = serde_json::json!([{
                    "type": "movie",
                    "id": "owner-catalog",
                    "extra": [{"name": "search", "options": ["Café"]}]
                }]);
                value
            },
        ] {
            assert!(
                validate_pathless_data(&PathlessRoute::Manifest, &invalid).is_err()
            );
        }

        let meta_route = PathlessRoute::ExtensionMeta {
            media_type: "series".to_string(),
            id: "owner-series".to_string(),
        };
        let released = serde_json::json!({
            "meta": {
                "id": "owner-series",
                "type": "series",
                "name": "Owner series",
                "videos": [{"id": "episode-1", "title": "Episode 1", "released": "2026-08-20"}]
            }
        });
        assert!(validate_pathless_data(&meta_route, &released).is_err());

        let too_many_streams = serde_json::json!({
            "streams": (0..1_025)
                .map(|_| serde_json::json!({
                    "atlasTargetRef": target_ref("stream", serde_json::Value::Null)
                }))
                .collect::<Vec<_>>()
        });
        assert!(
            validate_pathless_data(&extension_route("stream"), &too_many_streams)
                .is_err()
        );

        for invalid in [
            serde_json::json!({"streams": [{"url": "https://provider.invalid/video"}]}),
            serde_json::json!({"streams": [{"atlasTargetRef": null}]}),
            serde_json::json!({"streams": [{
                "atlasTargetRef": target_ref("stream", serde_json::Value::Null),
                "behaviorHints": {}
            }]}),
            serde_json::json!({"streams": [{
                "atlasTargetRef": target_ref("stream", serde_json::Value::Null),
                "atlasStreamFacts": {"Version": 1, "Cached": null}
            }]}),
            serde_json::json!({"streams": [{
                "atlasTargetRef": target_ref("stream", serde_json::Value::Null),
                "atlasStreamFacts": {"Version": 1, "Unknown": true}
            }]}),
            serde_json::json!({"streams": [{
                "atlasTargetRef": target_ref("stream", serde_json::Value::Null),
                "atlasStreamFacts": {"Version": 1, "GroupKey": "agk1_bad"}
            }]}),
        ] {
            assert!(
                validate_pathless_data(&extension_route("stream"), &invalid).is_err()
            );
        }
    }

    #[test]
    fn atlas_extension_route_segments_use_the_frozen_bounds() {
        assert!(safe_segment(&"a".repeat(512), 512));
        assert!(!safe_segment(&"a".repeat(513), 512));
        assert!(!safe_segment("movie/owner", 512));
        assert!(!safe_segment("movie\\owner", 512));
        assert!(!safe_segment("movie\nowner", 512));
    }

    #[test]
    fn atlas_source_errors_preserve_status_without_url_or_body() {
        let error = redact_source_error(
            ClientError::Http {
                status: 503,
                message: "provider body secret".to_string(),
                endpoint: Some(
                    "https://provider.invalid/private/manifest.json".to_string(),
                ),
                body: Some("source response secret".to_string()),
            },
            true,
        );
        let rendered = error.to_string();
        assert!(matches!(
            error,
            ClientError::Http {
                status: 503,
                endpoint: None,
                body: None,
                ..
            }
        ));
        for private in [
            "provider.invalid",
            "provider body secret",
            "source response secret",
        ] {
            assert!(!rendered.contains(private));
        }
    }

    #[tokio::test]
    async fn atlas_source_client_never_follows_redirects_and_redacts_the_request() {
        let server = httpmock::MockServer::start();
        let private_request = "pathless-request-sentinel";
        let redirect = server.mock(|when, then| {
            when.path(format!("/{private_request}/manifest.json"));
            then.status(302)
                .header("Location", "/redirect-sentinel")
                .body("source-response-body-sentinel");
        });
        let followed = server.mock(|when, then| {
            when.path("/redirect-sentinel");
            then.status(200)
                .json_body(serde_json::json!({
                    "id": "must-not-be-fetched",
                    "name": "redirected",
                    "version": "1.0.0",
                    "resources": [],
                    "types": [],
                    "catalogs": []
                }));
        });
        let source = format!("{}/{private_request}", server.base_url());
        let service = StremioService::from_redacted_no_redirect_url(&source).unwrap();

        let error = service
            .get_manifest()
            .await
            .unwrap_err();
        let client_error = error
            .downcast_ref::<ClientError>()
            .unwrap();
        assert!(matches!(
            client_error,
            ClientError::Http {
                status: 302,
                endpoint: None,
                body: None,
                ..
            }
        ));
        let rendered = error.to_string();
        assert!(!rendered.contains(private_request));
        assert!(!rendered.contains("source-response-body-sentinel"));
        assert!(!rendered.contains(&server.base_url()));
        redirect.assert_hits(1);
        followed.assert_hits(0);
    }

    #[tokio::test]
    async fn atlas_search_requires_the_live_manifest_extra_before_catalog_io() {
        sdks::clear_http_cache();
        let server = httpmock::MockServer::start();
        let searchable_manifest = server.mock(|when, then| {
            when.path("/manifest.json");
            then.status(200)
                .json_body(serde_json::json!({
                    "id": "atlas-search",
                    "name": "Atlas search",
                    "version": "1.0.0",
                    "resources": ["catalog", "meta", "stream"],
                    "types": ["movie"],
                    "catalogs": [{
                        "id": "owner-library",
                        "type": "movie",
                        "name": "Owner library",
                        "extra": [{"name": "search", "isRequired": false}]
                    }]
                }));
        });
        let catalog = server.mock(|when, then| {
            when.path("/catalog/movie/owner-library/search=atlas.json");
            then.status(200)
                .json_body(serde_json::json!({
                    "metas": [{
                        "id": "atlas:movie:owner-only",
                        "type": "movie",
                        "name": "Owner result"
                    }]
                }));
        });
        let service =
            StremioService::from_redacted_no_redirect_url(&server.base_url()).unwrap();
        let results = service
            .search(sdks::stremio::MediaType::Movie, "atlas".to_string())
            .await
            .unwrap();
        assert_eq!(results.len(), 1);
        searchable_manifest.assert_hits(1);
        catalog.assert_hits(1);

        sdks::clear_http_cache();
        let absent = httpmock::MockServer::start();
        let plain_manifest = absent.mock(|when, then| {
            when.path("/manifest.json");
            then.status(200)
                .json_body(serde_json::json!({
                    "id": "atlas-no-search",
                    "name": "Atlas no search",
                    "version": "1.0.0",
                    "resources": ["catalog", "meta", "stream"],
                    "types": ["movie"],
                    "catalogs": [{
                        "id": "owner-library",
                        "type": "movie",
                        "name": "Owner library",
                        "extra": [{"name": "skip", "isRequired": false}]
                    }]
                }));
        });
        let forbidden_catalog = absent.mock(|when, then| {
            when.path_contains("/catalog/");
            then.status(500);
        });
        let service =
            StremioService::from_redacted_no_redirect_url(&absent.base_url()).unwrap();
        let error = service
            .search(sdks::stremio::MediaType::Movie, "atlas".to_string())
            .await
            .unwrap_err();
        assert!(
            error
                .to_string()
                .contains("no search catalog")
        );
        plain_manifest.assert_hits(1);
        forbidden_catalog.assert_hits(0);
        sdks::clear_http_cache();
    }

    #[test]
    fn is_404_matches_only_404_status() {
        assert!(is_404(&ClientError::Http {
            status: 404,
            message: "not found".to_string(),
            endpoint: None,
            body: None,
        }));
        assert!(!is_404(&ClientError::Http {
            status: 500,
            message: "server error".to_string(),
            endpoint: None,
            body: None,
        }));
        assert!(!is_404(&ClientError::RateLimited {
            retry_after_secs: 30
        }));
    }

    fn mock_page(server: &httpmock::MockServer, path: &str, names: &[&str]) {
        let metas: Vec<_> = names
            .iter()
            .map(|n| serde_json::json!({"id": n, "type": "movie", "name": n}))
            .collect();
        server.mock(|when, then| {
            when.path(path);
            then.status(200)
                .json_body(serde_json::json!({"metas": metas}));
        });
    }

    /// Regression test for the take_while/filter_map bug: take_while drops the
    /// first item it rejects instead of passing it downstream, so a 404 on page
    /// 2 must still yield page 1's items and stop cleanly there.
    #[tokio::test]
    async fn get_catalog_stream_stops_cleanly_on_404() {
        let server = httpmock::MockServer::start();
        mock_page(&server, "/catalog/movie/test.json", &["a", "b"]);
        server.mock(|when, then| {
            when.path("/catalog/movie/test/skip=2.json");
            then.status(404);
        });

        let svc = StremioService::from_url(&server.base_url()).unwrap();
        let stream = svc
            .get_catalog_stream("movie".to_string(), "test".to_string(), true)
            .await
            .unwrap();
        let names: Vec<String> = stream
            .map(|m| m.id)
            .collect()
            .await;

        assert_eq!(names, vec!["a".to_string(), "b".to_string()]);
    }

    /// Same as above but for a non-404 error (5xx) — must still stop cleanly
    /// rather than hang or panic, even though it's not the expected
    /// end-of-catalog signal.
    #[tokio::test]
    async fn get_catalog_stream_stops_cleanly_on_non_404_error() {
        let server = httpmock::MockServer::start();
        mock_page(&server, "/catalog/movie/test.json", &["a", "b"]);
        server.mock(|when, then| {
            when.path("/catalog/movie/test/skip=2.json");
            then.status(500);
        });

        let svc = StremioService::from_url(&server.base_url()).unwrap();
        let stream = svc
            .get_catalog_stream("movie".to_string(), "test".to_string(), true)
            .await
            .unwrap();
        let names: Vec<String> = stream
            .map(|m| m.id)
            .collect()
            .await;

        assert_eq!(names, vec!["a".to_string(), "b".to_string()]);
    }
}
