// Atlas modification, 2026-08-20.
//
// The upstream Remux media table is intentionally global.  Atlas runs many
// users on one Remux process, so authentication must also prove that the
// requested row came from an add-on assigned to the authenticated user.

use anyhow::{Result, bail};
use axum::{
    body::Body,
    http::{Response, StatusCode, header},
};
use sqlx::SqlitePool;
use url::{Host, Url};
use uuid::{Uuid, Variant};

use super::Media;
use crate::Config;

/// Validate the exact public relay origin used in Atlas mode. A configured
/// origin is an origin, not a URL prefix: no credentials, port, path, query, or
/// fragment are accepted. IP literals and local/private naming conventions are
/// rejected so an operator typo cannot turn the redirect boundary into Fly or
/// host-local egress.
fn validate_public_origin(raw: &str) -> Result<()> {
    let parsed =
        Url::parse(raw).map_err(|_| anyhow::anyhow!("invalid Atlas relay origin"))?;
    let host = match parsed.host() {
        Some(Host::Domain(host)) => host,
        _ => bail!("invalid Atlas relay origin"),
    };
    let blocked_name = host.eq_ignore_ascii_case("localhost")
        || host.ends_with(".localhost")
        || host.ends_with(".local")
        || host.ends_with(".internal")
        || host.ends_with(".flycast");
    if parsed.scheme() != "https"
        || parsed.username() != ""
        || parsed
            .password()
            .is_some()
        || parsed
            .port()
            .is_some()
        || parsed.path() != "/"
        || parsed
            .query()
            .is_some()
        || parsed
            .fragment()
            .is_some()
        || blocked_name
        || parsed
            .origin()
            .ascii_serialization()
            != raw
    {
        bail!("invalid Atlas relay origin");
    }
    Ok(())
}

pub fn validate_relay_origin(raw: &str) -> Result<()> {
    validate_public_origin(raw)
}

/// Atlas-mode Stremio add-ons may contain only a non-secret Pathless source or
/// extension marker. The marker is recognized before any network operation.
pub fn source_manifest_target<'a>(config: &Config, raw: &'a str) -> Option<&'a str> {
    if !config.atlas_remux_patched_tenant_auth {
        return Some(raw);
    }
    let relay_origin = config
        .atlas_extension_relay_origin
        .as_deref()?;
    validate_relay_origin(relay_origin).ok()?;
    let parsed = Url::parse(raw).ok()?;
    if parsed
        .origin()
        .ascii_serialization()
        != relay_origin
        || parsed
            .query()
            .is_some()
        || parsed
            .fragment()
            .is_some()
        || parsed.username() != ""
        || parsed
            .password()
            .is_some()
        || parsed
            .port()
            .is_some()
        || parsed.as_str() != raw
    {
        return None;
    }
    let path = parsed.path();
    let suffix = path
        .strip_prefix("/.well-known/atlas-source/")
        .or_else(|| path.strip_prefix("/.well-known/atlas-extension/"))?;
    let (binding, tail) = suffix.split_once('/')?;
    let generation = tail.strip_suffix("/manifest.json")?;
    let binding_id = Uuid::parse_str(binding).ok()?;
    if binding_id.to_string() != binding
        || binding_id.get_variant() != Variant::RFC4122
        || !(1..=8).contains(&binding_id.get_version_num())
        || generation.is_empty()
        || generation.starts_with('0')
        || !generation
            .bytes()
            .all(|byte| byte.is_ascii_digit())
    {
        return None;
    }
    let generation = generation
        .parse::<u32>()
        .ok()?;
    (generation > 0 && generation <= i32::MAX as u32).then_some(raw)
}

/// Return the exact marker only when it is the Atlas extension form.  This is
/// used by add-on activation to select persisted capabilities before any
/// manifest-capability fetch can be attempted.
pub fn extension_manifest_target<'a>(config: &Config, raw: &'a str) -> Option<&'a str> {
    if !config.atlas_remux_patched_tenant_auth {
        return None;
    }
    let target = source_manifest_target(config, raw)?;
    let parsed = Url::parse(target).ok()?;
    parsed
        .path()
        .starts_with("/.well-known/atlas-extension/")
        .then_some(target)
}

pub fn relay_redirect(location: &str) -> Response<Body> {
    Response::builder()
        .status(StatusCode::TEMPORARY_REDIRECT)
        .header(header::LOCATION, location)
        .header(header::CACHE_CONTROL, "private, no-store")
        .header(header::PRAGMA, "no-cache")
        .header(header::CONTENT_LENGTH, "0")
        .body(Body::empty())
        .expect("static Atlas relay redirect response")
}

pub async fn media_owned_by_user(
    db: &SqlitePool,
    user_id: Uuid,
    media_id: Uuid,
) -> Result<bool> {
    Ok(sqlx::query_scalar::<_, bool>(
        "SELECT EXISTS(\
           SELECT 1 FROM atlas_catalog_media_owners owner \
           JOIN addon_users assigned ON assigned.addon_id = owner.addon_id \
           WHERE assigned.user_id = ?1 AND owner.media_id = ?2\
         )",
    )
    .bind(user_id)
    .bind(media_id)
    .fetch_one(db)
    .await?)
}

pub async fn stream_owned_by_user(
    db: &SqlitePool,
    user_id: Uuid,
    stream: &Media,
) -> Result<bool> {
    let Some(parent_id) = stream.parent_id else {
        return Ok(false);
    };
    let Some(addon_id) = stream
        .stream_info
        .as_ref()
        .and_then(|info| info.addon_id)
    else {
        return Ok(false);
    };

    Ok(sqlx::query_scalar::<_, bool>(
        "SELECT EXISTS(\
           SELECT 1 FROM atlas_catalog_media_owners owner \
           JOIN addon_users assigned ON assigned.addon_id = owner.addon_id \
           WHERE assigned.user_id = ?1 \
             AND owner.addon_id = ?2 \
             AND owner.media_id = ?3\
         )",
    )
    .bind(user_id)
    .bind(addon_id)
    .bind(parent_id)
    .fetch_one(db)
    .await?)
}

pub async fn retain_user_streams(
    db: &SqlitePool,
    user_id: Uuid,
    streams: &mut Vec<Media>,
) {
    let mut retained = Vec::with_capacity(streams.len());
    for stream in streams.drain(..) {
        if stream_owned_by_user(db, user_id, &stream)
            .await
            .unwrap_or(false)
        {
            retained.push(stream);
        }
    }
    *streams = retained;
}

pub async fn record_catalog_media(
    db: &SqlitePool,
    addon_id: Uuid,
    catalog_id: Uuid,
    root_ids: &[Uuid],
) -> Result<()> {
    let mut tx = db
        .begin()
        .await?;
    for root_id in std::iter::once(&catalog_id).chain(root_ids.iter()) {
        sqlx::query(
            "WITH RECURSIVE owned(id) AS (\
               SELECT id FROM media WHERE id = ?3 \
               UNION \
               SELECT child.id FROM media child \
               JOIN owned parent \
                 ON child.parent_id = parent.id OR child.grandparent_id = parent.id \
               UNION \
               SELECT related.id FROM media_relations relation \
               JOIN owned parent ON relation.left_media_id = parent.id \
               JOIN media related ON related.id = relation.right_media_id\
             ) \
             INSERT OR IGNORE INTO atlas_catalog_media_owners(addon_id, catalog_id, media_id) \
             SELECT ?1, ?2, id FROM owned",
        )
        .bind(addon_id)
        .bind(catalog_id)
        .bind(root_id)
        .execute(&mut *tx)
        .await?;
    }
    tx.commit()
        .await?;
    Ok(())
}

pub async fn remove_catalog_media(db: &SqlitePool, catalog_id: Uuid) -> Result<()> {
    sqlx::query("DELETE FROM atlas_catalog_media_owners WHERE catalog_id = ?1")
        .bind(catalog_id)
        .execute(db)
        .await?;
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::{db, stream::StreamInfo};

    fn atlas_config() -> Config {
        Config {
            atlas_remux_patched_tenant_auth: true,
            atlas_extension_relay_origin: Some(
                "https://relay.atlas.invalid".to_string(),
            ),
            atlas_pathless_api_origin: Some("https://api.atlas.invalid".to_string()),
            ..Default::default()
        }
    }

    #[test]
    fn atlas_manifest_markers_never_accept_provider_urls() {
        let config = atlas_config();
        let binding = Uuid::new_v4();
        let source_manifest = format!(
            "https://relay.atlas.invalid/.well-known/atlas-source/{binding}/1/manifest.json"
        );
        let extension_manifest = format!(
            "https://relay.atlas.invalid/.well-known/atlas-extension/{binding}/2/manifest.json"
        );
        assert_eq!(
            source_manifest_target(&config, &source_manifest),
            Some(source_manifest.as_str())
        );
        assert_eq!(
            source_manifest_target(&config, &extension_manifest),
            Some(extension_manifest.as_str())
        );
        assert_eq!(
            extension_manifest_target(&config, &extension_manifest),
            Some(extension_manifest.as_str())
        );
        assert!(extension_manifest_target(&config, &source_manifest).is_none());
        assert!(
            source_manifest_target(&config, "https://provider.invalid/manifest.json")
                .is_none()
        );
        assert!(
            source_manifest_target(
                &config,
                "https://relay.atlas.invalid/.well-known/atlas-source/00000000-0000-0000-0000-000000000000/1/manifest.json",
            )
            .is_none()
        );
    }

    #[test]
    fn atlas_redirect_is_bodyless_private_and_temporary() {
        let response = relay_redirect("https://cdn.provider.invalid/image.webp");
        assert_eq!(response.status(), StatusCode::TEMPORARY_REDIRECT);
        assert_eq!(response.headers()[header::CONTENT_LENGTH], "0");
        assert_eq!(
            response.headers()[header::CACHE_CONTROL],
            "private, no-store"
        );
        assert_eq!(
            response.headers()[header::LOCATION],
            "https://cdn.provider.invalid/image.webp"
        );
    }

    async fn insert_media(db: &SqlitePool, id: Uuid, parent_id: Option<Uuid>) {
        sqlx::query(
            "INSERT INTO media(\
               id, title, kind, parent_id, external_ids, locked_fields, \
               promoted, enabled, created_at, updated_at\
             ) VALUES (\
               ?1, 'fixture', 'movie', ?2, '{}', '[]', \
               0, 1, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP\
             )",
        )
        .bind(id)
        .bind(parent_id)
        .execute(db)
        .await
        .unwrap();
    }

    #[tokio::test]
    async fn catalog_provenance_is_user_and_addon_scoped() {
        let db = db::connect("sqlite::memory:", 1_000)
            .await
            .unwrap();
        db::migrate(&db)
            .await
            .unwrap();
        let user_a = Uuid::new_v4();
        let user_b = Uuid::new_v4();
        let addon_a = Uuid::new_v4();
        let addon_b = Uuid::new_v4();
        let catalog = Uuid::new_v4();
        let root = Uuid::new_v4();
        let root_b = Uuid::new_v4();
        let child = Uuid::new_v4();
        let related = Uuid::new_v4();
        for (id, name) in [(user_a, "a"), (user_b, "b")] {
            sqlx::query(
                "INSERT INTO users(id, username, password_hash) VALUES (?1, ?2, 'x')",
            )
            .bind(id)
            .bind(name)
            .execute(&db)
            .await
            .unwrap();
        }
        for (id, name) in [(addon_a, "a"), (addon_b, "b")] {
            sqlx::query(
                "INSERT INTO addons(id, name, created_at, updated_at) \
                 VALUES (?1, ?2, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)",
            )
            .bind(id)
            .bind(name)
            .execute(&db)
            .await
            .unwrap();
        }
        sqlx::query("INSERT INTO addon_users(addon_id, user_id) VALUES (?1, ?2)")
            .bind(addon_a)
            .bind(user_a)
            .execute(&db)
            .await
            .unwrap();
        sqlx::query("INSERT INTO addon_users(addon_id, user_id) VALUES (?1, ?2)")
            .bind(addon_b)
            .bind(user_b)
            .execute(&db)
            .await
            .unwrap();

        insert_media(&db, root, None).await;
        insert_media(&db, root_b, None).await;
        insert_media(&db, child, Some(root)).await;
        insert_media(&db, related, None).await;
        sqlx::query(
            "INSERT INTO media_relations(relation_id, left_media_id, right_media_id, role) \
             VALUES (?1, ?2, ?3, 'genre')",
        )
        .bind(Uuid::new_v4())
        .bind(root)
        .bind(related)
        .execute(&db)
        .await
        .unwrap();

        record_catalog_media(&db, addon_a, catalog, &[root])
            .await
            .unwrap();
        record_catalog_media(&db, addon_b, Uuid::new_v4(), &[root_b])
            .await
            .unwrap();

        let visible_to_a = Media::get_by_filter(
            &db,
            &db::MediaFilter {
                kind: Some(vec![db::MediaKind::Movie]),
                tenant_user_id: Some(user_a),
                ..Default::default()
            },
        )
        .await
        .unwrap()
        .records
        .into_iter()
        .map(|media| media.id)
        .collect::<std::collections::HashSet<_>>();
        assert!(visible_to_a.contains(&root));
        assert!(!visible_to_a.contains(&root_b));
        assert!(
            media_owned_by_user(&db, user_a, root)
                .await
                .unwrap()
        );
        assert!(
            media_owned_by_user(&db, user_a, child)
                .await
                .unwrap()
        );
        assert!(
            media_owned_by_user(&db, user_a, related)
                .await
                .unwrap()
        );
        assert!(
            !media_owned_by_user(&db, user_b, root)
                .await
                .unwrap()
        );
        assert!(
            media_owned_by_user(&db, user_b, root_b)
                .await
                .unwrap()
        );

        let stream = Media {
            parent_id: Some(root),
            stream_info: Some(StreamInfo {
                addon_id: Some(addon_a),
                ..Default::default()
            }),
            ..Default::default()
        };
        assert!(
            stream_owned_by_user(&db, user_a, &stream)
                .await
                .unwrap()
        );
        assert!(
            !stream_owned_by_user(&db, user_b, &stream)
                .await
                .unwrap()
        );

        remove_catalog_media(&db, catalog)
            .await
            .unwrap();
        assert!(
            !media_owned_by_user(&db, user_a, root)
                .await
                .unwrap()
        );
    }

    #[tokio::test]
    async fn later_children_and_relations_inherit_catalog_owner() {
        let db = db::connect("sqlite::memory:", 1_000)
            .await
            .unwrap();
        db::migrate(&db)
            .await
            .unwrap();
        let user = Uuid::new_v4();
        let addon = Uuid::new_v4();
        let catalog = Uuid::new_v4();
        let root = Uuid::new_v4();
        sqlx::query(
            "INSERT INTO users(id, username, password_hash) VALUES (?1, 'a', 'x')",
        )
        .bind(user)
        .execute(&db)
        .await
        .unwrap();
        sqlx::query(
            "INSERT INTO addons(id, name, created_at, updated_at) \
             VALUES (?1, 'a', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)",
        )
        .bind(addon)
        .execute(&db)
        .await
        .unwrap();
        sqlx::query("INSERT INTO addon_users(addon_id, user_id) VALUES (?1, ?2)")
            .bind(addon)
            .bind(user)
            .execute(&db)
            .await
            .unwrap();
        insert_media(&db, root, None).await;
        record_catalog_media(&db, addon, catalog, &[root])
            .await
            .unwrap();

        let child = Uuid::new_v4();
        insert_media(&db, child, Some(root)).await;
        assert!(
            media_owned_by_user(&db, user, child)
                .await
                .unwrap()
        );

        let related = Uuid::new_v4();
        insert_media(&db, related, None).await;
        sqlx::query(
            "INSERT INTO media_relations(relation_id, left_media_id, right_media_id, role) \
             VALUES (?1, ?2, ?3, 'person')",
        )
        .bind(Uuid::new_v4())
        .bind(root)
        .bind(related)
        .execute(&db)
        .await
        .unwrap();
        assert!(
            media_owned_by_user(&db, user, related)
                .await
                .unwrap()
        );
    }
}
