-- Atlas modification, 2026-08-20.
--
-- Pathless extension images are persisted as private body-only authorization
-- state.  The public `path` remains a fixed non-URL sentinel so no provider
-- location can enter ordinary image DTOs or proxy code.
ALTER TABLE media_images ADD COLUMN atlas_extension_id TEXT;
ALTER TABLE media_images ADD COLUMN atlas_generation INTEGER;
ALTER TABLE media_images ADD COLUMN atlas_remote_addon_id TEXT;
ALTER TABLE media_images ADD COLUMN atlas_sealed_ref TEXT;
