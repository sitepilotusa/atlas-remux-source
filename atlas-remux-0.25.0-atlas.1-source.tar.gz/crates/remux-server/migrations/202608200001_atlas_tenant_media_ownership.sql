-- Atlas modification, 2026-08-20.
--
-- Remux's media index is global while add-on assignment is per user.  Preserve
-- the catalog/add-on provenance needed to authorize every indexed media row.
CREATE TABLE atlas_catalog_media_owners (
    addon_id  BLOB NOT NULL REFERENCES addons(id) ON DELETE CASCADE,
    catalog_id BLOB NOT NULL,
    media_id  TEXT NOT NULL REFERENCES media(id) ON DELETE CASCADE,
    PRIMARY KEY (addon_id, catalog_id, media_id)
);

CREATE INDEX idx_atlas_catalog_media_owners_media_addon
    ON atlas_catalog_media_owners(media_id, addon_id);

-- A later series refresh can insert seasons, episodes, or source rows after
-- the top-level catalog import.  Inherit every owning catalog from the parent.
CREATE TRIGGER atlas_media_owner_inherit_after_insert
AFTER INSERT ON media
WHEN NEW.parent_id IS NOT NULL OR NEW.grandparent_id IS NOT NULL
BEGIN
    INSERT OR IGNORE INTO atlas_catalog_media_owners(addon_id, catalog_id, media_id)
    SELECT owner.addon_id, owner.catalog_id, NEW.id
    FROM atlas_catalog_media_owners AS owner
    WHERE owner.media_id = NEW.parent_id
       OR owner.media_id = NEW.grandparent_id;
END;

-- Relations (genres, people, studios, playlist members) are part of the same
-- tenant-visible graph and otherwise remain global rows.
CREATE TRIGGER atlas_media_owner_relation_after_insert
AFTER INSERT ON media_relations
BEGIN
    INSERT OR IGNORE INTO atlas_catalog_media_owners(addon_id, catalog_id, media_id)
    SELECT owner.addon_id, owner.catalog_id, NEW.right_media_id
    FROM atlas_catalog_media_owners AS owner
    JOIN media AS related ON related.id = NEW.right_media_id
    WHERE owner.media_id = NEW.left_media_id;
END;
