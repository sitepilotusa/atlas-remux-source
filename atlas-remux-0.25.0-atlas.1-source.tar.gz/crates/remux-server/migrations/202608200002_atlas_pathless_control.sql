-- Atlas modification, 2026-08-20.
--
-- The private Pathless control endpoint serializes each operation/action pair
-- under an immediate SQLite transaction.  The private digest is deliberately
-- retained only on this Fly-internal database and is never returned or logged.
CREATE TABLE atlas_pathless_control_operations (
    operation_id          TEXT NOT NULL,
    action                TEXT NOT NULL,
    private_command_sha256 TEXT NOT NULL,
    result_json           TEXT NOT NULL,
    created_at            TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now')),
    PRIMARY KEY (operation_id, action),
    CHECK (length(operation_id) = 36),
    CHECK (length(action) BETWEEN 1 AND 32),
    CHECK (length(private_command_sha256) = 64),
    CHECK (length(result_json) BETWEEN 2 AND 16384)
);
