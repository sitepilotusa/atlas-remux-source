#!/bin/sh
set -eu

if [ "$#" -ne 2 ]; then
  echo "usage: prepare-source.sh OUTPUT_SOURCE_DIR OUTPUT_TARBALL" >&2
  exit 64
fi

output_dir=$1
output_tar=$2
script_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
patch_dir=$(CDPATH= cd -- "$script_dir/.." && pwd)

if [ -e "$output_dir" ] || [ -e "$output_tar" ]; then
  echo "refusing to overwrite an existing source directory or artifact" >&2
  exit 73
fi

# The archive deliberately embeds the reviewed prepublication lock with null
# artifact fields. Refuse a later final outer lock so the source archive cannot
# contain a digest that refers to a predecessor copy of itself.
test "$(grep -Fxc '  "patchedImage": null,' "$patch_dir/image-lock.json")" -eq 1
test "$(grep -Fxc '    "url": null,' "$patch_dir/image-lock.json")" -eq 1
test "$(grep -Fxc '    "sha256": null' "$patch_dir/image-lock.json")" -eq 1
test "$(grep -Fxc '  "releaseAttestationSha256": null' "$patch_dir/image-lock.json")" -eq 1

git clone --filter=blob:none https://github.com/lostb1t/remux.git "$output_dir"
git -C "$output_dir" checkout --detach 83bcbd98d956347c2efec63d4c7a744f87696ba9
test "$(git -C "$output_dir" rev-parse HEAD)" = "83bcbd98d956347c2efec63d4c7a744f87696ba9"
git -C "$output_dir" apply --check "$patch_dir/patches/0001-atlas-tenant-isolation.patch"
git -C "$output_dir" apply --index "$patch_dir/patches/0001-atlas-tenant-isolation.patch"
cp "$patch_dir/ATLAS-MODIFICATIONS.md" "$output_dir/ATLAS-MODIFICATIONS.md"
mkdir -p "$output_dir/atlas-release/patches" "$output_dir/atlas-release/scripts"
cp "$patch_dir/ATLAS-MODIFICATIONS.md" "$output_dir/atlas-release/ATLAS-MODIFICATIONS.md"
cp "$patch_dir/Dockerfile" "$output_dir/atlas-release/Dockerfile"
cp "$patch_dir/.dockerignore" "$output_dir/atlas-release/.dockerignore"
cp "$patch_dir/.dockerignore" "$output_dir/atlas-release/Dockerfile.dockerignore"
cp "$patch_dir/README.md" "$output_dir/atlas-release/README.md"
cp "$patch_dir/image-lock.json" "$output_dir/atlas-release/image-lock.json"
cp "$patch_dir/patches/0001-atlas-tenant-isolation.patch" \
  "$output_dir/atlas-release/patches/0001-atlas-tenant-isolation.patch"
cp "$patch_dir/scripts/prepare-source.sh" "$output_dir/atlas-release/scripts/prepare-source.sh"
cp "$patch_dir/scripts/verify-source.sh" "$output_dir/atlas-release/scripts/verify-source.sh"
"$output_dir/atlas-release/scripts/verify-source.sh" "$output_dir" --write-manifest

# GNU tar is required for deterministic ordering, ownership and timestamps.
if command -v gtar >/dev/null 2>&1; then
  tar_command=gtar
elif tar --help 2>&1 | grep -q -- '--sort'; then
  tar_command=tar
else
  echo "GNU tar is required (install gtar on macOS or run the remote Linux release job)" >&2
  exit 69
fi

"$tar_command" --sort=name \
  --mtime='2026-08-20T00:00:00Z' \
  --owner=0 --group=0 --numeric-owner \
  --exclude=.git --exclude=target \
  --use-compress-program='gzip -n' \
  -C "$output_dir" -cf "$output_tar" .
sha256sum "$output_tar"
