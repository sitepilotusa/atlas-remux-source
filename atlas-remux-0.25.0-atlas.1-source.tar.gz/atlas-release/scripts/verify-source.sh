#!/bin/sh
set -eu

if [ "$#" -lt 1 ] || [ "$#" -gt 2 ] || { [ "$#" -eq 2 ] && [ "$2" != "--write-manifest" ]; }; then
  echo "usage: verify-source.sh SOURCE_DIR [--write-manifest]" >&2
  exit 64
fi

source_dir=$1
write_manifest=0
if [ "$#" -eq 2 ]; then
  write_manifest=1
fi
script_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
patch_dir=$(CDPATH= cd -- "$script_dir/.." && pwd)
manifest=$source_dir/atlas-release/SOURCE-MANIFEST.sha256

test -f "$source_dir/LICENSE"
test -f "$source_dir/ATLAS-MODIFICATIONS.md"
test -f "$source_dir/crates/remux-server/migrations/202608200001_atlas_tenant_media_ownership.sql"
test -f "$source_dir/crates/remux-server/migrations/202608200002_atlas_pathless_control.sql"
test -f "$source_dir/crates/remux-server/migrations/202608200003_atlas_pathless_image_targets.sql"
test -f "$source_dir/atlas-release/.dockerignore"
test -f "$source_dir/atlas-release/ATLAS-MODIFICATIONS.md"
test -f "$source_dir/atlas-release/Dockerfile"
test -f "$source_dir/atlas-release/Dockerfile.dockerignore"
test -f "$source_dir/atlas-release/README.md"
test -f "$source_dir/atlas-release/image-lock.json"
test -f "$source_dir/atlas-release/patches/0001-atlas-tenant-isolation.patch"
test -f "$source_dir/atlas-release/scripts/prepare-source.sh"
test -f "$source_dir/atlas-release/scripts/verify-source.sh"
test "$(sha256sum "$source_dir/LICENSE" | cut -d ' ' -f 1)" = \
  "20b067f86de375aae6db0f283ab2e65de24d537733b89bd58432c101259d84cf"
actual_patch_sha=$(sha256sum "$patch_dir/patches/0001-atlas-tenant-isolation.patch" | cut -d ' ' -f 1)
lock_patch_sha=$(sed -n \
  '/^[[:space:]]*"patch":[[:space:]]*{[[:space:]]*$/,/^[[:space:]]*}[,]*[[:space:]]*$/ {
    s/^[[:space:]]*"sha256":[[:space:]]*"\([a-f0-9]\{64\}\)",*$/\1/p
  }' "$patch_dir/image-lock.json")
test "$(printf '%s\n' "$lock_patch_sha" | grep -Ec '^[a-f0-9]{64}$')" -eq 1
test "$actual_patch_sha" = "$lock_patch_sha"
test "$(grep -Fxc \
  "      io.atlas.remux.patch.sha256=\"$lock_patch_sha\" \\" \
  "$patch_dir/Dockerfile")" -eq 1
patch_revision=$(printf '%.16s' "$lock_patch_sha")
test "$(grep -Fxc \
  "      org.opencontainers.image.revision=\"83bcbd98d956347c2efec63d4c7a744f87696ba9+atlas.patch.$patch_revision\" \\" \
  "$patch_dir/Dockerfile")" -eq 1
cmp "$patch_dir/ATLAS-MODIFICATIONS.md" "$source_dir/ATLAS-MODIFICATIONS.md"
cmp "$patch_dir/ATLAS-MODIFICATIONS.md" "$source_dir/atlas-release/ATLAS-MODIFICATIONS.md"
cmp "$patch_dir/Dockerfile" "$source_dir/atlas-release/Dockerfile"
cmp "$patch_dir/.dockerignore" "$source_dir/atlas-release/.dockerignore"
cmp "$patch_dir/.dockerignore" "$source_dir/atlas-release/Dockerfile.dockerignore"
cmp "$patch_dir/README.md" "$source_dir/atlas-release/README.md"
cmp "$patch_dir/image-lock.json" "$source_dir/atlas-release/image-lock.json"
cmp "$patch_dir/patches/0001-atlas-tenant-isolation.patch" \
  "$source_dir/atlas-release/patches/0001-atlas-tenant-isolation.patch"
cmp "$patch_dir/scripts/prepare-source.sh" "$source_dir/atlas-release/scripts/prepare-source.sh"
cmp "$patch_dir/scripts/verify-source.sh" "$source_dir/atlas-release/scripts/verify-source.sh"

actual_patch=$(mktemp)
actual_untracked=$(mktemp)
actual_files=$(mktemp)
expected_files=$(mktemp)
trap 'rm -f "$actual_patch" "$actual_untracked" "$actual_files" "$expected_files"' EXIT HUP INT TERM

verify_git_index() {
  git -C "$source_dir" diff --cached --binary --no-ext-diff > "$actual_patch"
  cmp "$patch_dir/patches/0001-atlas-tenant-isolation.patch" "$actual_patch"
  git -C "$source_dir" diff --cached --check
  git -C "$source_dir" diff --quiet
  git -C "$source_dir" ls-files --others --exclude-standard | LC_ALL=C sort > "$actual_untracked"
  {
    printf '%s\n' \
      'ATLAS-MODIFICATIONS.md' \
      'atlas-release/.dockerignore' \
      'atlas-release/ATLAS-MODIFICATIONS.md' \
      'atlas-release/Dockerfile' \
      'atlas-release/Dockerfile.dockerignore' \
      'atlas-release/README.md' \
      'atlas-release/image-lock.json' \
      'atlas-release/patches/0001-atlas-tenant-isolation.patch' \
      'atlas-release/scripts/prepare-source.sh' \
      'atlas-release/scripts/verify-source.sh'
    if [ -f "$manifest" ]; then
      printf '%s\n' 'atlas-release/SOURCE-MANIFEST.sha256'
    fi
  } | LC_ALL=C sort > "$expected_files"
  cmp "$expected_files" "$actual_untracked"
}

write_source_manifest() {
  (
    cd "$source_dir"
    find . -type f \
      ! -path './.git/*' \
      ! -path './target/*' \
      ! -path './atlas-release/SOURCE-MANIFEST.sha256' \
      -print0 \
      | LC_ALL=C sort -z \
      | xargs -0 sha256sum
  ) > "$manifest"
}

verify_source_manifest() {
  (
    cd "$source_dir"
    sha256sum -c atlas-release/SOURCE-MANIFEST.sha256 >/dev/null
    find . -type f \
      ! -path './.git/*' \
      ! -path './target/*' \
      ! -path './atlas-release/SOURCE-MANIFEST.sha256' \
      -print0 \
      | LC_ALL=C sort -z \
      | xargs -0 -n 1 printf '%s\n' \
      > "$actual_files"
    sed -E 's/^[a-f0-9]{64}  //' atlas-release/SOURCE-MANIFEST.sha256 \
      | LC_ALL=C sort > "$expected_files"
  )
  cmp "$expected_files" "$actual_files"
}

if [ -d "$source_dir/.git" ]; then
  test "$(git -C "$source_dir" rev-parse HEAD)" = \
    "83bcbd98d956347c2efec63d4c7a744f87696ba9"
  verify_git_index
elif [ "$write_manifest" -eq 1 ]; then
  echo "--write-manifest requires the exact prepared Git checkout" >&2
  exit 65
elif [ ! -f "$manifest" ]; then
  echo "source archive is missing SOURCE-MANIFEST.sha256" >&2
  exit 65
fi

if [ "$write_manifest" -eq 1 ]; then
  write_source_manifest
  verify_git_index
fi
if [ -f "$manifest" ]; then
  verify_source_manifest
fi
