# Atlas-patched Remux v0.25.0

This directory is the reproducible release boundary for the Atlas tenant-ownership
and Pathless V2 patch. It does not contain, fetch, or reference customer extension
URLs.

The upstream release commit is `83bcbd98d956347c2efec63d4c7a744f87696ba9`.
The immutable upstream OCI index is
`ghcr.io/lostb1t/remux@sha256:90e7652a46a1d8c3718c3f4431ed9713bfbb36832b187c7bf7bbcea2c72b71ce`.
The release tag commit only changes `CHANGELOG.md` from the attested image-build input
`1949908d1dc4f506e5d4af89da2206bbf59d1714`; both are recorded, not conflated.

## Prepare and build the complete source

Use a clean Linux builder with Docker Buildx, GNU tar 1.35, GNU gzip 1.12,
Git, and network access. The preparation script rejects other tar or gzip
implementations because their compressed bytes are not the canonical release
artifact. Do not put runtime secrets in the build context or build arguments.

The build keeps Cargo's registry, Git checkout, and compiled target directories in
BuildKit cache mounts. The compiled server is copied out of the target cache before
the build step ends, so an empty or garbage-collected cache produces the same image.
Target caches are namespaced by architecture, and compilation remains limited to four
jobs with test debug information disabled to stay within the default builder's memory.
The production GitHub release builder is ephemeral and still requests a no-cache
build; these mounts accelerate persistent development/Depot builders without turning
the cache into a release input.

1. From this checked-in directory, run
   `scripts/prepare-source.sh source atlas-remux-0.25.0-atlas.1-source.tar.gz`.
   It checks out the exact upstream commit, applies the locked patch into the
   Git index, verifies the complete staged diff plus exact release-file
   allowlist, and creates a deterministic GNU-tar archive. Preparation requires
   the reviewed prepublication `image-lock.json` with `patchedImage` and both
   `patchedSourceArtifact` fields plus `releaseAttestationSha256` still null.
2. Run `source/atlas-release/scripts/verify-source.sh source`. The archive
   embeds this verifier, a complete SHA-256 file manifest, patch, notice,
   Dockerfile, ignore file, lock, and preparation script. After extraction the
   same verifier uses the manifest without requiring Git history or the Atlas
   API repository.
3. In `source`, run the pinned formatting gate `cargo fmt --all -- --check`,
   then both Rust gates:
   `SQLX_OFFLINE=true CARGO_PROFILE_TEST_DEBUG=0 cargo test --locked -p remux-server atlas_ -- --test-threads=1`
   and `SQLX_OFFLINE=true CARGO_PROFILE_TEST_DEBUG=0 cargo test --locked -p remux-server -- --test-threads=1`.
   The release workflow builds the Dockerfile's `test` target with the complete
   second command on native `linux/amd64`, without cache or an exported image,
   before registry login. The default runtime graph does not depend on that
   target: its separate `build` stage repeats the formatting check and runs the
   exact `cargo build --locked --release -p remux-server` command for both
   release architectures. The test-only `CARGO_PROFILE_TEST_DEBUG=0` removes
   linker debug symbols but leaves the test profile, debug assertions, package,
   test inventory, lock enforcement, and serialized execution unchanged. This
   preserves the full test gate without compiling the test feature graph under
   arm64 emulation or exhausting runner memory while linking its test binary.
4. Host the complete source tarball at a durable public HTTPS URL with anonymous
   no-charge download. This publication is an authorization-requiring release
   action and is a launch blocker until complete.
   The archive contains the modified source, upstream license, dated modification
   notice, exact patch, content manifest, image/source lock, Dockerfile, and
   these build instructions.
5. Compute the archive SHA-256. The authorized release workflow builds the two
   architectures natively, pushes by digest into the private fixed
   `ghcr.io/sitepilotusa/atlas-remux` package, combines only those immutable
   children, and signs/attests the private GHCR index. Do not substitute a local
   registry login, generic repository, mutable staging tag, or multiarchitecture
   emulation.
6. Resolve the private-GHCR multi-platform digest and create the exact private
   GitHub Actions OCI-layout handoff, then populate both outer image locks and
   `infra/remux-release/release-attestation.v1.json` as one reviewed published
   state. The patched lock uses the digest-only GHCR image, the already
   built archive's durable URL and SHA-256, and the canonical attestation byte
   SHA-256. Do not rerun preparation and do not
   replace the archive's embedded null prepublication lock; either would create
   a self-reference or make the recorded source digest describe a predecessor
   archive. Verify the extracted archive with its embedded
   `atlas-release/scripts/verify-source.sh`. Separately, the repository release
   gate validates the final outer locks and attestation against that immutable
   archive digest, patch, image labels, signatures, SBOM, provenance, platform
   children, and versioned access-explicit final readbacks. The anonymous source
   fetch, authenticated private-GHCR evidence with exact anonymous tag/digest
   denial proofs, private one-day OCI-layout artifacts, and the separate same-
   interface Gateway observation are independently bound. Each OCI handoff
   binds the GitHub run/artifact IDs, release head, exact artifact/TAR digest and
   size equality, the private GHCR root index, and the complete canonical
   config/layer closure inventory. It stores no credentials, headers, response
   bodies, tag inventories, or private configuration. Runtime-registry transfer
   and deployment evidence are later operator boundaries and are not claims in
   the release attestation. Review the release metadata change before deployment.

The checked-in Dockerfile inherits the pinned upstream UI/runtime and replaces only
the server binary. Its Debian build packages come from the fixed 2025-08-15 Bookworm
snapshot at exact versions. It installs the upstream GNU AGPL v3 license and dated Atlas
modification notice in `/usr/share/doc/remux` and labels the image with the complete-
source URL, source SHA-256, and patch SHA-256. Preserve upstream notices. If Atlas changes the patch, mark the date and
scope, rebuild the complete source artifact, and publish it at no charge to all remote
users before exposing the service. Legal review remains required for release.

The OCI source label is not, by itself, the user-visible source offer. Before
public ingress, exact Gateway `GET`/`HEAD /source-information` and the relative
`rel="source"` Link must expose the reviewed durable source URL, and the source
must be anonymously downloadable at no charge. Capture the source fetch and
same-interface GET/HEAD as separate evidence. The latter is required to record
`legalSufficiency: false`; legal review must explicitly approve prominence and
AGPL section-13 sufficiency. The endpoint, labels, and validator do not
establish or claim compliance. Those
external actions require separate authorization and are not done here.

## Audited gateway and Pathless boundaries

The gateway exposes discovery, clock, branding, localization, auth-provider, and web-
manifest routes without tenant media. Public password login is removed. A native
device instead redeems one device-bound Atlas Cloud ticket at exact
`POST /api/atlas/v1/native/session/redeem`; the gateway returns only an Atlas gateway
session token and retains the Remux token behind its private boundary. It never exposes add-on enumeration
or mutation through the ordinary Remux API. The sole control surface is exact public
`POST /api/atlas/v2/control/reconcile` at the gateway. After public PoP verification
and a separately signed API authorization, the gateway sends one exact private
Flycast HTTP POST to the same path on Remux and injects the gateway-only administrator
credential. Remux accepts the closed 15-action DTO under its normal authenticated
administrator boundary, journals the other 14 commands by
`(operationId, action, privateCommandSHA256)`, and returns an exact bounded readback.
The public lease `attemptId` is authorization-only for those commands and never
enters their private body, digest, or journal identity. The read-only `probe_addon`
command instead copies its signed operation and current attempt into one fixed
Remux-to-Worker manifest request after exact add-on ownership readback. It runs outside
the mutation transaction and journal and returns only `{healthy:boolean}`. The retired
underscore-prefixed control namespace and legacy credential header return the same
empty `404` as any unknown surface.

Pathless source- and extension-marker `create_addon` and `update_addon` rebuild the runtime only
from the exact stored marker and the closed, sorted `resources`/`types` in the
authorized command. Runtime loading returns before Stremio `available_info`, so these
control actions make no Worker/provider request and produce no fallback warning or
identifier/provider-state log. Their wire shape, private digest, mutation journal, and
readback are unchanged. Disable/remove get and delete continue to require the exact
persisted installed marker generation; once the row is absent, repeat delete and
strict get-null are idempotent.

Every public route that can touch tenant state has two layers: gateway session
preverification and this source patch. `/Users/me` and `/Users/:owner/...` bind the
authenticated user and reject a different path user. `/Items`, `/Items/Latest`,
`/Persons`, `/Search/Hints`, and both resume forms overwrite submitted `UserId` and
apply catalog/add-on provenance in the database query. `/UserViews`, user views,
`/Studios`, `/Years`, and `/Genres` use the same owner predicate; a genre parent is
also owner-checked. Show seasons/episodes check the parent and use the scoped item
query; both single-series and all-series `/Shows/NextUp` queries include the owner
predicate. Item detail, playback info, images, static video/audio, and playback-
session events require the exact owned media row. Static playback additionally
requires the selected stream's add-on to be assigned to that user. Image URLs cannot
be supplied through `tag`.

All item/playback DTO paths clear raw provider data, headers, local paths, live/open
tokens, and credentials embedded in follow-up URLs. The gateway applies a second
bounded JSON denylist before returning any tenant DTO. Keep the gateway allowlist and
this audit in lockstep; a new public route is a fail-closed security review event.
The sole source join exception is `ProviderIds.AtlasSourceRef`, exactly
`atlas:<UUID>`, on first-party movie, series, and episode rows. It is absent on
seasons and extension rows.

Atlas stores only fixed non-secret source and extension markers. Remux recognizes them
before normal URL handling and uses four compiled POST boundaries: source JSON and
uploaded-media redemption at the fixed API origin, and extension JSON and target
redemption at the fixed Worker origin. Each boundary has a distinct request/response
PoP keyring, domain, route, byte cap, timeout, and no-redirect client. Unknown media
types fail closed; launch accepts only sorted unique `movie | series`.

Sanitized extension JSON is validated against closed manifest, catalog, meta, stream,
subtitle, image, and target-reference schemas. Raw target URLs, external URLs,
info-hashes, arbitrary headers, and proxy controls are rejected. The relay consumes
only validated filename/size/grouping hints and emits a closed typed facts sibling;
raw behavior hints and structured provider metadata are still rejected at this boundary.
Opaque target state is consumed into private descriptors and never serialized or
debug-logged. After ownership checks, Remux redeems those descriptors and emits an
empty `307`; it never fetches or proxies provider media. Uploaded media accepts only
method-bound, 90-second, exact R2 SigV4 locations. Atlas mode does not call RemuxDB or
segment-provider probes, even if stale configuration enables one.

Runtime topology is non-secret `ATLAS_PATHLESS_API_ORIGIN`,
`ATLAS_EXTENSION_RELAY_ORIGIN`, `ATLAS_CLOUD_R2_ACCOUNT_ID`,
`ATLAS_CLOUD_R2_BUCKET`, and `ATLAS_CLOUD_R2_ACCESS_KEY_ID`. Supply these secrets only
through the runtime secret store, never this tree or image layers:
`ATLAS_PATHLESS_REMUX_{SOURCE,MEDIA,EXTENSION,TARGET}_{REQUEST,RESPONSE}_KEYRING`,
plus the distinct native gateway API/control rings documented in the gateway.
Each corresponding `..._ACTIVE_KEY_ID` is non-secret. Rings contain one active key and
at most one predecessor, and key material is unique across all eight rings.

## Runtime proof gate

Do not set `ATLAS_REMUX_PATCHED_TENANT_AUTH=1` based on a successful build. Against a
private disposable deployment, create two users with distinct non-default add-ons and
catalogs, then run the gateway tenant-isolation probe. It must prove both positive owner
access and denial of cross-user list, detail, image, subtitle, playback, session, and extension
access, the DTO denylist, exact control retry/readback, and identical legacy `404`
surfaces. Record the immutable image digest and probe evidence.
Only then may both the patched-Remux and public-gateway copies of the flag change
from their fail-closed defaults of `0`.

`ATLAS_STREAM_FACTS_V1` is an independent cloud-only flag that also defaults to
false. It controls public facts emission and `atlas-stream-facts-v1` advertising;
it does not enable tenant mode or the stream picker. Direct Remux cannot enable it,
and AC-WP8 must complete a fresh image/source/legal/probe gate before the cloud
runtime may set it alongside the gateway's separate facts and quality flags. The
same Remux gate carries the separately typed `AtlasStreamQuality` v1 DTO and
advertises `atlas-stream-quality-v1`; the gateway still validates that sibling
behind its own exact flag.
